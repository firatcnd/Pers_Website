import styled from 'styled-components';

const Spacer = styled.hr`
  width: 100%;
  border-color: currentColor;
`;

export default Spacer;
