import originalMedia from 'css-in-js-media';

export const media = originalMedia;
