"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[372],{94382:function(a,b,c){c.d(b,{Kkx:function(){return Wc},dtP:function(){return Q},zMQ:function(){return Ca},pCK:function(){return ni},Uns:function(){return R},NiS:function(){return S},EL5:function(){return T},QSS:function(){return ie},VaG:function(){return ao},i6Q:function(){return gj},S6J:function(){return hj},mY4:function(){return ea},HVU:function(){return Eo},Tof:function(){return uo},Mr_:function(){return zo},Acx:function(){return Co},zxk:function(){return Fc},Fm0:function(){return af},lh4:function(){return um},t3t:function(){return vm},if1:function(){return Sa},cOn:function(){return Je},csZ:function(){return qm},Yqy:function(){return rm},v4q:function(){return Y},wyc:function(){return $},XCv:function(){return _},g8U:function(){return Z},Cdc:function(){return Ja},yGk:function(){return Ka},Two:function(){return U},dNJ:function(){return fa},SGL:function(){return ij},X8T:function(){return jj},zH8:function(){return te},r9b:function(){return Jm},HcM:function(){return Ne},Nnh:function(){return nm},wIr:function(){return pm},wAQ:function(){return Ue},FRx:function(){return Rc},DUz:function(){return Xi},Vni:function(){return ba},V92:function(){return Cg},NAN:function(){return aa},ASJ:function(){return Ra},dY8:function(){return X},zGg:function(){return V},Pz_:function(){return Fa},Ndp:function(){return jg},iz5:function(){return ga},"DE$":function(){return ab},cp7:function(){return bb},Qyk:function(){return _a},hfx:function(){return Za},n2V:function(){return $a},g6G:function(){return wc},H_J:function(){return yc},"$BE":function(){return Ia},gt0:function(){return Ha},JfN:function(){return Hc},l09:function(){return sb},qbs:function(){return Tc},quP:function(){return gd},SkI:function(){return Bc},"_pg":function(){return Yo},heb:function(){return Oc},PXv:function(){return hd},n51:function(){return id},OWb:function(){return Na},PHR:function(){return Am},ZAu:function(){return Ld},Ngj:function(){return Qd},sNi:function(){return Rd},iGZ:function(){return Ui},L7U:function(){return Yi},q1h:function(){return Zi},"_7A":function(){return Pd},Uq7:function(){return W},bHp:function(){return ha},SWv:function(){return wm},"$FD":function(){return xm},hU:function(){return Gc},Mkw:function(){return nj},Tdy:function(){return oj},Urx:function(){return Te},szr:function(){return Da},IIB:function(){return Ke},h32:function(){return ia},Gvc:function(){return Ti},ItB:function(){return Wi},sDB:function(){return Vi},qg:function(){return ca},xPt:function(){return wa},NJp:function(){return lj},XvI:function(){return mj},xgg:function(){return Kc},DrE:function(){return _n},mBM:function(){return xa},BuP:function(){return Ba},EX8:function(){return Zf},Pl1:function(){return $f},g4X:function(){return ja},qlk:function(){return Uh},bae:function(){return Hh},u_l:function(){return N},nK9:function(){return O},fef:function(){return P},Sb7:function(){return Oa},xBx:function(){return La},ZAr:function(){return M},ah7:function(){return Qa},DYV:function(){return J},JL8:function(){return po},Ki0:function(){return pj},gbx:function(){return qj},Y2U:function(){return Le},GXq:function(){return ka},PQB:function(){return Jc},Nak:function(){return Od},V9q:function(){return Nd},pdg:function(){return Pa},ppW:function(){return Ga},PEf:function(){return ya},Eep:function(){return Ge},ofH:function(){return tj},OWT:function(){return uj},qpW:function(){return om},zGS:function(){return ra},s30:function(){return _e},je2:function(){return sm},P45:function(){return tm},qnd:function(){return sa},PaJ:function(){return ta},z1H:function(){return Pc},X5P:function(){return va},ADv:function(){return da},PhF:function(){return De},mgC:function(){return rj},L8C:function(){return sj},ewm:function(){return la},dwl:function(){return Aa},wRo:function(){return oo},"$eq":function(){return ma},Lu6:function(){return Bj},h2h:function(){return Dj},Kx8:function(){return je},nvn:function(){return xj},c9v:function(){return yj},XLE:function(){return vj},rkX:function(){return wj},Dtb:function(){return Pn},GRk:function(){return fn},dwG:function(){return zn},BgQ:function(){return Ec},QMD:function(){return Dc},AsI:function(){return na},"$z_":function(){return Eg},H1r:function(){return On},OIE:function(){return Nn},ZDl:function(){return ue},gEl:function(){return zj},gIn:function(){return Aj},XHJ:function(){return oa},Adg:function(){return za},UEU:function(){return qa},JZr:function(){return pa},rG2:function(){return ua},aNP:function(){return Ea},AKq:function(){return Ic},Mgf:function(){return yo},zTE:function(){return Ao},ngV:function(){return Ce},LsZ:function(){return he},Kz5:function(){return vo},kNL:function(){return Me},fMb:function(){return Ua},bZA:function(){return Sc},cIP:function(){return nc},vqF:function(){return Nc},OPS:function(){return Fm},t7j:function(){return Em},YL_:function(){return mc},"_aR":function(){return $o},vz0:function(){return L},j7J:function(){return kc},"_m2":function(){return lc},qS6:function(){return Ji},eMv:function(){return sc},ws8:function(){return tc},rWp:function(){return vc},ABh:function(){return uc},QQK:function(){return Qn},On:function(){return Ya},ZeD:function(){return Xa}});var d=c(67294),e=c(73935),f=c(72588),g=c(19604),h=c(92764),i=c(79829),j=c(17106),k=c(46515),l=c(28368),m=c(72510),n=c(77493),o=c(73342),p=c(37303),q=c(52286),r=c(94149),s=c(98366),t=c.n(s),u=c(15948),v=c(18156),w=c(713),x=c(19818);c.n(x);var y=c(55162),z=c(5005),A=c(28894),B=c(30381),C=c.n(B),D=c(58949),E=c(33680),F=c(65440),G=Object.defineProperty,H=(a,b,c)=>b in a?G(a,b,{enumerable:!0,configurable:!0,writable:!0,value:c}):a[b]=c,I=(a,b,c)=>(H(a,"symbol"!=typeof b?b+"":b,c),c);const J=({children:a})=>{const[b,c]=(0,d.useState)(null),e=(0,d.useCallback)(a=>{null!==a&&c(a)},[]);return d.createElement(d.Fragment,null,d.createElement("div",{id:"modal-root",className:"tina-tailwind",ref:e}),d.createElement(K.Provider,{value:{portalNode:b}},a))},K=d.createContext(null);function L(){const a=d.useContext(K);if(!a)throw new Error("No Modal Container context provided");return a}const M=({children:a})=>d.createElement("div",{className:"fixed inset-0 z-modal w-screen h-screen overflow-y-auto"},a,d.createElement("div",{className:"fixed -z-1 inset-0 opacity-80 bg-gradient-to-br from-gray-800 via-gray-900 to-black"})),N=a=>{const{portalNode:b}=L();return b?(0,e.createPortal)(d.createElement(M,null,d.createElement("div",{...a})),b):null},O=({children:a})=>d.createElement("div",{className:"w-full flex justify-between gap-4 items-center px-5 pb-5 rounded-b-md"},a),P=({className:a="",padded:b=!1,...c})=>d.createElement("div",{className:`${b?"p-5":"p-0"} m-0 overflow-hidden flex flex-col min-h-[160px] [&:last-child]:rounded-[0_0_5px_5px] ${a}`,...c}),Q=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M14.9524 4.89689L14.9524 26.8016H16.7461L16.7461 4.89689H14.9524Z"}),d.createElement("path",{d:"M4.8969 16.7461H26.8016L26.8016 14.9523H4.89689L4.8969 16.7461Z"})),R=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M9.125 24H22.875V26H9.125V24ZM5 18H27V20H5V18ZM5 6H27V8H5V6ZM9.125 12H22.875V14H9.125V12Z",fill:"inherit"})),S=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M5 24H20.125V26H5V24ZM5 18H27V20H5V18ZM5 6H27V8H5V6ZM5 12H20.125V14H5V12Z",fill:"inherit"})),T=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M11.875 24H27V26H11.875V24ZM5 18H27V20H5V18ZM5 6H27V8H5V6ZM11.875 12H27V14H11.875V12Z",fill:"inherit"})),U=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M5 6.2684L24.7316 26L26 24.7316L6.2684 5L5 6.2684Z"}),d.createElement("path",{d:"M6.2684 26L26 6.2684L24.7316 5L5 24.7316L6.2684 26Z"})),V=({...a})=>d.createElement("svg",{viewBox:"0 0 4 14",fill:"#828282",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M2 5.5C1.5625 5.5 1.21875 5.65625 0.9375 5.9375C0.625 6.25 0.5 6.59375 0.5 7C0.5 7.4375 0.625 7.78125 0.9375 8.0625C1.21875 8.375 1.5625 8.5 2 8.5C2.40625 8.5 2.75 8.375 3.0625 8.0625C3.34375 7.78125 3.5 7.4375 3.5 7C3.5 6.59375 3.34375 6.25 3.0625 5.9375C2.75 5.65625 2.40625 5.5 2 5.5ZM0.5 2.25C0.5 1.84375 0.625 1.5 0.9375 1.1875C1.21875 0.90625 1.5625 0.75 2 0.75C2.40625 0.75 2.75 0.90625 3.0625 1.1875C3.34375 1.5 3.5 1.84375 3.5 2.25C3.5 2.6875 3.34375 3.03125 3.0625 3.3125C2.75 3.625 2.40625 3.75 2 3.75C1.5625 3.75 1.21875 3.625 0.9375 3.3125C0.625 3.03125 0.5 2.6875 0.5 2.25ZM0.5 11.75C0.5 11.3438 0.625 11 0.9375 10.6875C1.21875 10.4062 1.5625 10.25 2 10.25C2.40625 10.25 2.75 10.4062 3.0625 10.6875C3.34375 11 3.5 11.3438 3.5 11.75C3.5 12.1875 3.34375 12.5312 3.0625 12.8125C2.75 13.125 2.40625 13.25 2 13.25C1.5625 13.25 1.21875 13.125 0.9375 12.8125C0.625 12.5312 0.5 12.1875 0.5 11.75Z"})),W=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M4 10H28V8H4V10Z"}),d.createElement("path",{d:"M4 17H28V15H4V17Z"}),d.createElement("path",{d:"M4 24H28V22H4V24Z"})),X=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M24.3324 8.96875C24.754 9.42578 25 9.95312 25 10.5859C25 11.2188 24.754 11.7461 24.3324 12.168L11.9634 24.543L7.85212 25C7.57101 25 7.36018 24.9297 7.21962 24.7188C7.04392 24.543 6.97365 24.332 7.00878 24.0508L7.46559 20.043L19.8346 7.66797C20.2562 7.24609 20.7833 7 21.4158 7C22.0483 7 22.5754 7.24609 23.0322 7.66797L24.3324 8.96875ZM11.1903 22.9258L20.3968 13.7148L18.2884 11.6055L9.08199 20.8164L8.80088 23.207L11.1903 22.9258ZM23.1376 10.9727C23.243 10.8672 23.3133 10.7266 23.3133 10.5859C23.3133 10.4453 23.243 10.3047 23.1376 10.1641L21.8375 8.86328C21.6969 8.75781 21.5564 8.6875 21.4158 8.6875C21.2753 8.6875 21.1347 8.75781 21.0293 8.86328L19.4832 10.4102L21.5915 12.5195L23.1376 10.9727Z"})),Y=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M6.708 10.5L5.5 11.7654L14.2939 20.9773C14.9597 21.6747 16.0412 21.6737 16.7061 20.9773L25.5 11.7654L24.292 10.5L15.5 19.7098L6.708 10.5Z"})),Z=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M25.292 21.5L26.5 20.2346L17.7061 11.0227C17.0403 10.3253 15.9588 10.3263 15.2939 11.0227L6.5 20.2346L7.708 21.5L16.5 12.2901L25.292 21.5Z"})),$=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M21 7.208L19.7346 6L10.5227 14.7939C9.82527 15.4597 9.82626 16.5412 10.5227 17.2061L19.7346 26L21 24.792L11.7901 16L21 7.208Z"})),_=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M11 24.792L12.2654 26L21.4773 17.2061C22.1747 16.5403 22.1737 15.4588 21.4773 14.7939L12.2654 6L11 7.208L20.2099 16L11 24.792Z"})),aa=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M24.95,25.85H13.01c-0.5,0-0.9-0.4-0.9-0.9V13.01c0-0.5,0.4-0.9,0.9-0.9h11.94c0.5,0,0.9,0.4,0.9,0.9v11.94\n      C25.85,25.45,25.45,25.85,24.95,25.85z M13.91,24.05h10.14V13.91H13.91V24.05z"}),d.createElement("path",{d:"M9.93,19.89H7.05c-0.5,0-0.9-0.4-0.9-0.9V7.05c0-0.5,0.4-0.9,0.9-0.9h11.94c0.5,0,0.9,0.4,0.9,0.9v2.89h-1.8V7.95H7.95\n      v10.14h1.99V19.89z"})),ba=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M15 22C15 23.1 14.1 24 13 24C11.9 24 11 23.1 11 22C11 20.9 11.9 20 13 20C14.1 20 15 20.9 15 22ZM13 14C11.9 14 11 14.9 11 16C11 17.1 11.9 18 13 18C14.1 18 15 17.1 15 16C15 14.9 14.1 14 13 14ZM13 8C11.9 8 11 8.9 11 10C11 11.1 11.9 12 13 12C14.1 12 15 11.1 15 10C15 8.9 14.1 8 13 8ZM19 12C20.1 12 21 11.1 21 10C21 8.9 20.1 8 19 8C17.9 8 17 8.9 17 10C17 11.1 17.9 12 19 12ZM19 14C17.9 14 17 14.9 17 16C17 17.1 17.9 18 19 18C20.1 18 21 17.1 21 16C21 14.9 20.1 14 19 14ZM19 20C17.9 20 17 20.9 17 22C17 23.1 17.9 24 19 24C20.1 24 21 23.1 21 22C21 20.9 20.1 20 19 20Z"})),ca=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M21 7.208L19.7346 6L10.5227 14.7939C9.82527 15.4597 9.82626 16.5412 10.5227 17.2061L19.7346 26L21 24.792L11.7901 16L21 7.208Z"})),da=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M11 24.792L12.2654 26L21.4773 17.2061C22.1747 16.5403 22.1737 15.4588 21.4773 14.7939L12.2654 6L11 7.20799L20.2099 16L11 24.792Z"})),ea=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M20.8 14.3867C22.0933 13.4933 23 12.0267 23 10.6667C23 7.65334 20.6667 5.33334 17.6667 5.33334H9.33333V24H18.72C21.5067 24 23.6667 21.7333 23.6667 18.9467C23.6667 16.92 22.52 15.1867 20.8 14.3867V14.3867ZM13.3333 8.66667H17.3333C18.44 8.66667 19.3333 9.56 19.3333 10.6667C19.3333 11.7733 18.44 12.6667 17.3333 12.6667H13.3333V8.66667ZM18 20.6667H13.3333V16.6667H18C19.1067 16.6667 20 17.56 20 18.6667C20 19.7733 19.1067 20.6667 18 20.6667Z"})),fa=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M12.5333 22.1333L6.40001 16L12.5333 9.86667L10.6667 8L2.66667 16L10.6667 24L12.5333 22.1333ZM19.4667 22.1333L25.6 16L19.4667 9.86667L21.3333 8L29.3333 16L21.3333 24L19.4667 22.1333V22.1333Z"})),ga=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M15.5 23.0129L8.88889 23.0129L8.88889 9.10324L15.5 9.10324L15.5 7.11615L8.88889 7.11615C7.85 7.11615 7 8.01034 7 9.10324L7 23.0129C7 24.1058 7.85 25 8.88889 25L15.5 25L15.5 23.0129Z"}),d.createElement("path",{d:"M18.6961 12.4912L21.1328 15.0645L12 15.0645L12 17.0516L21.1328 17.0516L18.6961 19.6249L20.0278 21.0258L24.75 16.0581L20.0278 11.0903L18.6961 12.4912Z"})),ha=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M12 5.33334V9.33334H18.6667V25.3333H22.6667V9.33334H29.3333V5.33334H12ZM4 16H8V25.3333H12V16H16V12H4V16Z"})),ia=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M13.3333 5.33334V9.33334H16.28L11.72 20H8V24H18.6667V20H15.72L20.28 9.33334H24V5.33334H13.3333Z"})),ja=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"currentColor",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M26 20V8C26 6.9 25.1 6 24 6H12C10.9 6 10 6.9 10 8V20C10 21.1 10.9 22 12 22H24C25.1 22 26 21.1 26 20ZM15 16L17.03 18.71L20 15L24 20H12L15 16ZM6 10V24C6 25.1 6.9 26 8 26H22V24H8V10H6Z"})),ka=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M2.66667 22.6667H5.33333V23.3333H4V24.6667H5.33333V25.3333H2.66667V26.6667H6.66667V21.3333H2.66667V22.6667ZM4 10.6667H5.33333V5.33334H2.66667V6.66667H4V10.6667ZM2.66667 14.6667H5.06667L2.66667 17.4667V18.6667H6.66667V17.3333H4.26667L6.66667 14.5333V13.3333H2.66667V14.6667ZM9.33333 6.66667V9.33334H28V6.66667H9.33333ZM9.33333 25.3333H28V22.6667H9.33333V25.3333ZM9.33333 17.3333H28V14.6667H9.33333V17.3333Z"})),la=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"currentColor",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M24.7021 13.8628L24.0959 12.4533C24.0959 12.4533 25.5063 9.34049 25.3804 9.22033L23.5152 7.43748C23.3853 7.3142 20.2046 8.73502 20.2046 8.73502L18.7364 8.1553C18.7364 8.1553 17.4403 5 17.2622 5H14.629C14.4469 5 13.2457 8.16271 13.2457 8.16271L11.7807 8.74321C11.7807 8.74321 8.53338 7.393 8.40784 7.51277L6.54507 9.29875C6.41594 9.42125 7.89851 12.4724 7.89851 12.4724L7.29273 13.8788C7.29273 13.8788 4 15.1209 4 15.2883V17.8143C4 17.9903 7.3003 19.1415 7.3003 19.1415L7.90608 20.5467C7.90608 20.5467 6.49724 23.6572 6.62079 23.7765L8.48595 25.5641C8.61189 25.6854 11.795 24.265 11.795 24.265L13.264 24.847C13.264 24.847 14.5601 28 14.739 28H17.373C17.5551 28 18.7555 24.8373 18.7555 24.8373L20.2257 24.2552C20.2257 24.2552 23.467 25.607 23.5922 25.4888L25.4581 23.7028C25.5872 23.5788 24.1015 20.5292 24.1015 20.5292L24.7057 19.1228C24.7057 19.1228 28 17.8791 28 17.7094V15.1841C28.0008 15.0105 24.7021 13.8628 24.7021 13.8628ZM19.8479 16.4984C19.8479 18.5306 18.1222 20.1855 16.0012 20.1855C13.8818 20.1855 12.1537 18.5306 12.1537 16.4984C12.1537 14.4679 13.8818 12.8161 16.0012 12.8161C18.123 12.8169 19.8479 14.4679 19.8479 16.4984Z"})),ma=({...a})=>d.createElement("svg",{viewBox:"0 0 24 24",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M4 21h15.893c1.103 0 2-.897 2-2V5c0-1.103-.897-2-2-2H4c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2zm0-2v-5h4v5H4zM14 7v5h-4V7h4zM8 7v5H4V7h4zm2 12v-5h4v5h-4zm6 0v-5h3.894v5H16zm3.893-7H16V7h3.893v5z"})),na=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"currentColor",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M18.6466 14.5553C19.9018 13.5141 20.458 7.36086 21.0014 5.14903C21.5447 2.9372 23.7919 3.04938 23.7919 3.04938C23.7919 3.04938 23.2085 4.06764 23.4464 4.82751C23.6844 5.58738 25.3145 6.26662 25.3145 6.26662L24.9629 7.19622C24.9629 7.19622 24.2288 7.10204 23.7919 7.9785C23.355 8.85496 24.3392 17.4442 24.3392 17.4442C24.3392 17.4442 21.4469 22.7275 21.4469 24.9206C21.4469 27.1136 22.4819 28.9515 22.4819 28.9515H21.0296C21.0296 28.9515 18.899 26.4086 18.462 25.1378C18.0251 23.8669 18.1998 22.596 18.1998 22.596C18.1998 22.596 15.8839 22.4646 13.8303 22.596C11.7767 22.7275 10.4072 24.498 10.16 25.4884C9.91287 26.4787 9.81048 28.9515 9.81048 28.9515H8.66211C7.96315 26.7882 7.40803 26.0129 7.70918 24.9206C8.54334 21.8949 8.37949 20.1788 8.18635 19.4145C7.99321 18.6501 6.68552 17.983 6.68552 17.983C7.32609 16.6741 7.97996 16.0452 10.7926 15.9796C13.6052 15.914 17.3915 15.5965 18.6466 14.5553Z"}),d.createElement("path",{d:"M11.1268 24.7939C11.1268 24.7939 11.4236 27.5481 13.0001 28.9516H14.3511C13.0001 27.4166 12.8527 23.4155 12.8527 23.4155C12.1656 23.6399 11.3045 24.3846 11.1268 24.7939Z"})),oa=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M16.9 4.2V6.9H25V8.7H7V6.9H15.1V4.2H16.9ZM7.77201 10.5H24.2279L22.4102 24.1332C22.2853 25.0698 21.4406 25.8 20.4977 25.8H11.5022C10.5561 25.8 9.71404 25.0653 9.58977 24.1332L7.77201 10.5ZM22.172 12.3H9.82791L11.3739 23.8953C11.3788 23.9318 11.4569 24 11.5022 24H20.4977C20.5432 24 20.6209 23.9328 20.6259 23.8953L22.172 12.3Z"})),pa=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M5.33333 14C4.22667 14 3.33333 14.8933 3.33333 16C3.33333 17.1067 4.22667 18 5.33333 18C6.44 18 7.33333 17.1067 7.33333 16C7.33333 14.8933 6.44 14 5.33333 14ZM5.33333 6C4.22667 6 3.33333 6.89333 3.33333 8C3.33333 9.10667 4.22667 10 5.33333 10C6.44 10 7.33333 9.10667 7.33333 8C7.33333 6.89333 6.44 6 5.33333 6ZM5.33333 22C4.22667 22 3.33333 22.9067 3.33333 24C3.33333 25.0933 4.24 26 5.33333 26C6.42667 26 7.33333 25.0933 7.33333 24C7.33333 22.9067 6.44 22 5.33333 22ZM9.33333 25.3333H28V22.6667H9.33333V25.3333ZM9.33333 17.3333H28V14.6667H9.33333V17.3333ZM9.33333 6.66667V9.33333H28V6.66667H9.33333Z"})),qa=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M16.6667 10.6667C13.1333 10.6667 9.93333 11.9867 7.46667 14.1333L2.66667 9.33334V21.3333H14.6667L9.84 16.5067C11.6933 14.96 14.0533 14 16.6667 14C21.3867 14 25.4 17.08 26.8 21.3333L29.96 20.2933C28.1067 14.7067 22.8667 10.6667 16.6667 10.6667Z"})),ra=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M24.5333 14.1333C22.0667 11.9867 18.8667 10.6667 15.3333 10.6667C9.13333 10.6667 3.89333 14.7067 2.05333 20.2933L5.2 21.3333C6.6 17.08 10.6 14 15.3333 14C17.9333 14 20.3067 14.96 22.16 16.5067L17.3333 21.3333H29.3333V9.33334L24.5333 14.1333Z"})),sa=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M15.3012 6.23952L11.0607 10.4801L10 9.41943L14.2406 5.17886C14.9213 4.49816 16.0233 4.48258 16.7196 5.17886L20.9602 9.41943L19.8995 10.4801L15.6589 6.23952C15.5561 6.13671 15.4039 6.13689 15.3012 6.23952Z"}),d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M15.6988 25.8732L19.9393 21.6326L21 22.6933L16.7594 26.9339C16.0787 27.6146 14.9767 27.6301 14.2804 26.9339L10.0398 22.6933L11.1005 21.6326L15.3411 25.8732C15.4439 25.976 15.5961 25.9758 15.6988 25.8732Z"}),d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M14.6569 27.1127V17.799L16.1569 17.799V27.1127L14.6569 27.1127Z"}),d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M14.6569 14.3137V5L16.1569 5V14.3137L14.6569 14.3137Z"})),ta=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M25.7605 15.3012L21.5199 11.0607L22.5806 10L26.8211 14.2406C27.5018 14.9213 27.5174 16.0233 26.8211 16.7196L22.5806 20.9602L21.5199 19.8995L25.7605 15.6589C25.8633 15.5561 25.8631 15.4039 25.7605 15.3012Z"}),d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M6.12679 15.6988L10.3674 19.9393L9.3067 21L5.06613 16.7594C4.38543 16.0787 4.36985 14.9767 5.06613 14.2804L9.3067 10.0398L10.3674 11.1005L6.12679 15.3411C6.02398 15.4439 6.02416 15.5961 6.12679 15.6988Z"}),d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M4.88727 14.6569L14.201 14.6569L14.201 16.1569L4.88727 16.1569L4.88727 14.6569Z"}),d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M17.6863 14.6569L27 14.6569L27 16.1569L17.6863 16.1569L17.6863 14.6569Z"})),ua=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"currentColor",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M17.3 25.1V19.9H21.2L16 13.4L10.8 19.9H14.7V25.1H17.3Z"}),d.createElement("path",{d:"M9.5 25.1H12.1V22.5H9.5C7.3498 22.5 5.6 20.7502 5.6 18.6C5.6 16.7748 7.1587 15.0172 9.0749 14.6805L9.8302 14.5479L10.0798 13.8225C10.9937 11.1562 13.2635 9.49996 16 9.49996C19.5841 9.49996 22.5 12.4159 22.5 16V17.3H23.8C25.2339 17.3 26.4 18.4661 26.4 19.9C26.4 21.3339 25.2339 22.5 23.8 22.5H19.9V25.1H23.8C26.6678 25.1 29 22.7678 29 19.9C28.998 18.7347 28.6056 17.6036 27.8855 16.6874C27.1654 15.7713 26.1591 15.1228 25.0272 14.8456C24.4591 10.371 20.628 6.89996 16 6.89996C12.4172 6.89996 9.305 8.99426 7.8841 12.295C5.0917 13.1296 3 15.766 3 18.6C3 22.1841 5.9159 25.1 9.5 25.1Z"})),va=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"none",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M12.625 13.3846H19.375C21.2358 13.3846 22.75 14.8342 22.75 16.6154C22.75 18.3966 21.2358 19.8462 19.375 19.8462H16V22H19.375C22.4766 22 25 19.5845 25 16.6154C25 13.6463 22.4766 11.2308 19.375 11.2308H12.625V8L7 12.3077L12.625 16.6154V13.3846Z",fill:"inherit"})),wa=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M5.2 16C5.2 13.72 7.05333 11.8667 9.33333 11.8667H14.6667V9.33334H9.33333C5.65333 9.33334 2.66666 12.32 2.66666 16C2.66666 19.68 5.65333 22.6667 9.33333 22.6667H14.6667V20.1333H9.33333C7.05333 20.1333 5.2 18.28 5.2 16ZM10.6667 17.3333H21.3333V14.6667H10.6667V17.3333ZM22.6667 9.33334H17.3333V11.8667H22.6667C24.9467 11.8667 26.8 13.72 26.8 16C26.8 18.28 24.9467 20.1333 22.6667 20.1333H17.3333V22.6667H22.6667C26.3467 22.6667 29.3333 19.68 29.3333 16C29.3333 12.32 26.3467 9.33334 22.6667 9.33334Z"})),xa=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M25 16.5C25 15.3419 23.9909 14.4 22.75 14.4H21.625V10.25C21.625 7.35515 19.1016 5 16 5C12.8984 5 10.375 7.35515 10.375 10.25V14.4H9.25C8.00912 14.4 7 15.3419 7 16.5V23.9C7 25.0581 8.00912 26 9.25 26H22.75C23.9909 26 25 25.0581 25 23.9V16.5ZM12.625 10.25C12.625 8.5133 14.1392 7.1 16 7.1C17.8608 7.1 19.375 8.5133 19.375 10.25V14.4H12.625V10.25Z",fill:"inherit"})),ya=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M8.00001 22.6667H12L14.6667 17.3333V9.33334H6.66667V17.3333H10.6667L8.00001 22.6667ZM18.6667 22.6667H22.6667L25.3333 17.3333V9.33334H17.3333V17.3333H21.3333L18.6667 22.6667Z"})),za=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M16 22.6667C20.4133 22.6667 24 19.08 24 14.6667V4H20.6667V14.6667C20.6667 17.24 18.5733 19.3333 16 19.3333C13.4267 19.3333 11.3333 17.24 11.3333 14.6667V4H8.00001V14.6667C8.00001 19.08 11.5867 22.6667 16 22.6667ZM6.66667 25.3333V28H25.3333V25.3333H6.66667Z"})),Aa=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M16.578 26a14.1 14.1 0 01-4.535-.75A12.299 12.299 0 018 22.889l2.628-3.028a13.437 13.437 0 002.83 1.722c.982.426 2.051.64 3.206.64.924 0 1.637-.158 2.137-.473.52-.333.78-.787.78-1.361v-.056c0-.117-.01-.228-.03-.333H24c-.003.952-.186 1.804-.549 2.556a5.478 5.478 0 01-1.53 1.888c-.655.5-1.435.89-2.34 1.167-.905.26-1.906.389-3.003.389zm-3.993-9H29v-3H17.265a71.646 71.646 0 01-1.843-.5c-.558-.167-1-.343-1.328-.528-.327-.185-.558-.389-.693-.61a1.905 1.905 0 01-.174-.834v-.056c0-.481.212-.88.636-1.194.443-.334 1.097-.5 1.964-.5.866 0 1.733.176 2.599.528a14.16 14.16 0 012.657 1.388l2.31-3.222a11.94 11.94 0 00-3.436-1.833C18.724 6.213 17.367 6 15.884 6c-1.04 0-1.992.139-2.859.417-.866.277-1.617.676-2.252 1.194a5.537 5.537 0 00-1.444 1.861c-.347.704-.52 1.5-.52 2.39v.055c0 .804.107 1.498.322 2.083H4v3h8.585z"})),Ba=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M28.0035 7H4.01374C2.91056 7 2 7.988 2 9.185V23.796C2 25.012 2.91056 26 4.01374 26H27.986C29.1067 26 29.9998 25.012 29.9998 23.815V9.185C30.0173 7.988 29.1067 7 28.0035 7ZM17.7597 22.2H14.2576V16.5L11.6309 20.148L9.00432 16.5V22.2H5.50216V10.8H9.00432L11.6309 14.6L14.2576 10.8H17.7597V22.2ZM22.9954 23.15L18.6352 16.5H21.2619V10.8H24.764V16.5H27.3906L22.9954 23.15Z"})),Ca=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M16 29.3333C17.4666 29.3333 18.6666 28.1333 18.6666 26.6666H13.3333C13.3333 27.3739 13.6143 28.0522 14.1144 28.5523C14.6145 29.0524 15.2927 29.3333 16 29.3333ZM24 21.3333V14.6666C24 10.5733 21.8133 7.14665 18 6.23998V5.33331C18 4.22665 17.1066 3.33331 16 3.33331C14.8933 3.33331 14 4.22665 14 5.33331V6.23998C10.1733 7.14665 7.99998 10.56 7.99998 14.6666V21.3333L5.33331 24V25.3333H26.6666V24L24 21.3333Z",fill:"inherit"})),Da=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M16 2.66669C8.64802 2.66669 2.66669 8.64802 2.66669 16C2.66669 23.352 8.64802 29.3334 16 29.3334C23.352 29.3334 29.3334 23.352 29.3334 16C29.3334 8.64802 23.352 2.66669 16 2.66669ZM17.3334 22.6667H14.6667V14.6667H17.3334V22.6667ZM17.3334 12H14.6667V9.33335H17.3334V12Z",fill:"inherit"})),Ea=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M31.2176 28.768L16.9664 2.1568C16.8686 1.98698 16.7278 1.84593 16.5581 1.74786C16.3884 1.64978 16.1959 1.59814 16 1.59814C15.804 1.59814 15.6115 1.64978 15.4419 1.74786C15.2722 1.84593 15.1314 1.98698 15.0336 2.1568L0.783977 28.768C0.688907 28.9338 0.639554 29.1219 0.640959 29.3131C0.642365 29.5042 0.694478 29.6916 0.791977 29.856C0.991977 30.1936 1.35518 30.4 1.74878 30.4H30.2512C30.4442 30.4003 30.6339 30.3503 30.8017 30.2549C30.9695 30.1595 31.1095 30.022 31.208 29.856C31.3054 29.6916 31.3576 29.5044 31.3593 29.3133C31.361 29.1222 31.3121 28.9341 31.2176 28.768V28.768ZM17.6 27.2H14.4V24H17.6V27.2ZM17.6 21.6H14.4V11.2H17.6V21.6Z",fill:"inherit"})),Fa=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"inherit",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M22.276 3.05736C22.1524 2.9333 22.0055 2.83491 21.8437 2.76787C21.6819 2.70082 21.5085 2.66643 21.3334 2.66669H10.6667C10.4916 2.66643 10.3181 2.70082 10.1563 2.76787C9.99455 2.83491 9.84763 2.9333 9.72402 3.05736L3.05736 9.72402C2.9333 9.84763 2.83491 9.99455 2.76787 10.1563C2.70082 10.3181 2.66643 10.4916 2.66669 10.6667V21.3334C2.66669 21.688 2.80669 22.0267 3.05736 22.276L9.72402 28.9427C9.84763 29.0667 9.99455 29.1651 10.1563 29.2322C10.3181 29.2992 10.4916 29.3336 10.6667 29.3334H21.3334C21.688 29.3334 22.0267 29.1934 22.276 28.9427L28.9427 22.276C29.0667 22.1524 29.1651 22.0055 29.2322 21.8437C29.2992 21.6819 29.3336 21.5085 29.3334 21.3334V10.6667C29.3336 10.4916 29.2992 10.3181 29.2322 10.1563C29.1651 9.99455 29.0667 9.84763 28.9427 9.72402L22.276 3.05736ZM17.3334 22.6667H14.6667V20H17.3334V22.6667ZM17.3334 17.3334H14.6667V9.33336H17.3334V17.3334Z",fill:"inherit"})),Ga=({...a})=>d.createElement("svg",{viewBox:"0 0 32 32",fill:"currentColor",xmlns:"http://www.w3.org/2000/svg",...a},d.createElement("path",{d:"M22.6328 19.163V11.997C22.6281 10.391 21.613 8 18.8359 8V6L15.0484 9L18.8359 12V10C20.5677 10 20.7306 11.539 20.7391 12V19.163C19.3756 19.597 18.3719 20.92 18.3719 22.5C18.3719 24.43 19.8585 26 21.686 26C23.5134 26 25 24.43 25 22.5C25 20.92 23.9963 19.597 22.6328 19.163ZM21.686 24C20.9029 24 20.2656 23.327 20.2656 22.5C20.2656 21.673 20.9029 21 21.686 21C22.469 21 23.1063 21.673 23.1063 22.5C23.1063 23.327 22.469 24 21.686 24ZM13.6281 9.5C13.6281 7.57 12.1415 6 10.314 6C8.48659 6 7 7.57 7 9.5C7 11.08 8.00368 12.403 9.36718 12.837V19.163C8.00368 19.597 7 20.92 7 22.5C7 24.43 8.48659 26 10.314 26C12.1415 26 13.6281 24.43 13.6281 22.5C13.6281 20.92 12.6244 19.597 11.2609 19.163V12.837C12.6244 12.403 13.6281 11.08 13.6281 9.5ZM8.89374 9.5C8.89374 8.673 9.53098 8 10.314 8C11.0971 8 11.7344 8.673 11.7344 9.5C11.7344 10.327 11.0971 11 10.314 11C9.53098 11 8.89374 10.327 8.89374 9.5ZM11.7344 22.5C11.7344 23.327 11.0971 24 10.314 24C9.53098 24 8.89374 23.327 8.89374 22.5C8.89374 21.673 9.53098 21 10.314 21C11.0971 21 11.7344 21.673 11.7344 22.5Z"})),Ha=({...a})=>d.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"2 2 20 20",...a},d.createElement("path",{d:"M20,5h-8.586L9.707,3.293C9.52,3.105,9.265,3,9,3H4C2.897,3,2,3.897,2,5v14c0,1.103,0.897,2,2,2h16c1.103,0,2-0.897,2-2V7 C22,5.897,21.103,5,20,5z M4,19V7h7h1h8l0.002,12H4z"})),Ia=({...a})=>d.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"2 2 20 20",...a},d.createElement("path",{d:"M19.903,8.586c-0.049-0.106-0.11-0.207-0.196-0.293l-6-6c-0.086-0.086-0.187-0.147-0.293-0.196 c-0.03-0.014-0.062-0.022-0.094-0.033c-0.084-0.028-0.17-0.046-0.259-0.051C13.04,2.011,13.021,2,13,2H6C4.897,2,4,2.897,4,4v16 c0,1.103,0.897,2,2,2h12c1.103,0,2-0.897,2-2V9c0-0.021-0.011-0.04-0.013-0.062c-0.005-0.089-0.022-0.175-0.051-0.259 C19.926,8.647,19.917,8.616,19.903,8.586z M16.586,8H14V5.414L16.586,8z M6,20V4h6v5c0,0.553,0.447,1,1,1h5l0.002,10H6z"}),d.createElement("path",{d:"M8 12H16V14H8zM8 16H16V18H8zM8 8H10V10H8z"})),Ja=({...a})=>d.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",fill:"currentColor",className:"bi bi-circle",viewBox:"0 0 16 16",...a},d.createElement("path",{d:"M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"})),Ka=({...a})=>d.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",fill:"currentColor",className:"bi bi-check-circle-fill",viewBox:"0 0 16 16",...a},d.createElement("path",{d:"M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"})),La=({children:a,close:b})=>d.createElement("div",{className:"h-14 flex items-center justify-between px-5 border-b border-gray-200 m-0"},d.createElement(Ma,null,a),b&&d.createElement("div",{onClick:b,className:"flex items-center fill-gray-400 cursor-pointer transition-colors duration-100 ease-out hover:fill-gray-700"},d.createElement(U,{className:"w-6 h-auto"}))),Ma=({children:a})=>d.createElement("h2",{className:"text-gray-600 font-sans font-medium text-base leading-none m-0 block truncate"},a),Na=({className:a="",style:b={},...c})=>d.createElement("div",{className:`flex flex-col z-0 overflow-visible bg-white rounded-none absolute top-0 left-0 w-full max-w-[1500px] h-full ${a} md:w-[calc(100%-170px)]`,style:{animation:"popup-right 150ms ease-out 1",...b},...c}),Oa=Na,Pa=({className:a="",style:b={},...c})=>d.createElement("div",{className:`block z-0 overflow-visible bg-gray-50 rounded-[5px] my-10 mx-auto w-[460px] max-w-[90%] ${a}`,style:{animation:"popup-down 150ms ease-out 1",...b},...c}),Qa=Pa,Ra="useCMS could not find an instance of CMS",Sa=d.createContext(null);function Ta(){const{cms:a,dispatch:b,state:c}=d.useContext(Sa);if(!a)throw new Error(Ra);const[,e]=d.useState(a.enabled);return a.dispatch=b,a.state=c,d.useEffect(()=>a.events.subscribe("cms",()=>{e(a.enabled)}),[a]),a}function Ua(a,b,c){const e=Ta();d.useEffect(function(){return e.events.subscribe(a,b)},c)}const Va=Ua;function Wa(a){const b=Ta();return{dispatch:c=>b.events.dispatch({...c,type:a}),subscribe:c=>b.events.subscribe(a,c)}}function Xa(a){return b=>d.createElement(Za,{name:b.input.name,label:b.field.label,description:b.field.description,error:b.meta.error,index:b.index,tinaForm:b.tinaForm},d.createElement(a,{...b}))}function Ya(a){return b=>d.createElement(Za,{name:b.input.name,label:!1,description:b.field.description,error:b.meta.error,index:b.index,tinaForm:b.tinaForm},d.createElement(a,{...b}))}const Za=({name:a,label:b,description:c,error:e,margin:f=!0,children:g,index:h,tinaForm:i,...j})=>{const{dispatch:k}=Wa("field:hover"),{dispatch:l}=Wa("field:focus");return d.createElement($a,{margin:f,onMouseOver:()=>k({id:i.id,fieldName:a}),onMouseOut:()=>k({id:null,fieldName:null}),onClick:()=>l({id:i.id,fieldName:a}),style:{zIndex:h?1e3-h:void 0},...j},(!1!==b||c)&&d.createElement(_a,{name:a},!1!==b&&d.createElement(d.Fragment,null,b||a),c&&d.createElement(ab,null,c)),g,e&&"string"==typeof e&&d.createElement(bb,null,e))},$a=({margin:a,children:b,...c})=>d.createElement("div",{className:`relative ${a?"mb-5 last:mb-0":""}`,...c},b),_a=({children:a,className:b,name:c,...e})=>d.createElement("label",{htmlFor:c,className:`block font-sans text-xs font-semibold text-gray-700 whitespace-normal mb-2 ${b}`,...e},a),ab=({children:a,className:b,...c})=>d.createElement("span",{className:`block font-sans text-xs italic font-light text-gray-400 pt-0.5 whitespace-normal m-0 ${b}`,...c},a),bb=({children:a,className:b,...c})=>d.createElement("span",{className:`block font-sans text-xs font-normal text-red-500 pt-3 animate-slide-in whitespace-normal m-0  ${b}`,...c},a);function cb(...a){return a.filter(Boolean).join(" ")}const db=()=>"10000000-1000-4000-8000-100000000000".replace(/[018]/g,a=>(a^crypto.getRandomValues(new Uint8Array(1))[0]&15>>a/4).toString(16)),eb=d.forwardRef(function(a,b){return d.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"currentColor","aria-hidden":"true",ref:b},a),d.createElement("path",{fillRule:"evenodd",d:"M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z",clipRule:"evenodd"}))});var fb=eb;const gb=({value:a,onChange:b,defaultQuery:c,items:e})=>{const[f,g]=d.useState(null!=c?c:""),h=d.useMemo(()=>{try{const a=new RegExp(f,"i"),b=e.filter(b=>a.test(b.label));if(0===b.length)return e;return b}catch(c){return e}},[e,f]);return d.createElement(i.h,{value:a,onChange:b,as:"div",className:"relative inline-block text-left z-20"},d.createElement("div",{className:"mt-1"},d.createElement("div",{className:"relative w-full cursor-default overflow-hidden rounded-lg bg-white text-left shadow-md sm:text-sm"},d.createElement(i.h.Input,{className:"w-full border-none py-2 pl-3 pr-10 text-sm leading-5 text-gray-900 focus:ring-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75 focus-visible:ring-offset-2 focus-visible:ring-offset-teal-300",displayValue:a=>{var b;return null!=(b=null==a?void 0:a.label)?b:"Plain Text"},onChange:a=>g(a.target.value),onClick:a=>a.stopPropagation()}),d.createElement(i.h.Button,{className:"absolute inset-y-0 right-0 flex items-center pr-2"},d.createElement(fb,{className:"h-5 w-5 text-gray-400","aria-hidden":"true"})))),d.createElement(j.u,{as:d.Fragment,enter:"transition ease-out duration-100",enterFrom:"transform opacity-0 scale-95",enterTo:"transform opacity-100 scale-100",leave:"transition ease-in duration-75",leaveFrom:"transform opacity-100 scale-100",leaveTo:"transform opacity-0 scale-95"},d.createElement(i.h.Options,{className:"origin-top-right absolute right-0 mt-1 w-full max-h-[300px] overflow-y-auto rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none"},h.map(a=>d.createElement(i.h.Option,{key:a.key,value:a},({active:b})=>d.createElement("button",{className:cb(b?"bg-gray-100 text-gray-900":"text-gray-700","block px-4 py-2 text-xs w-full text-right")},a.render(a)))))))};g.loader.config({paths:{vs:"https://cdn.jsdelivr.net/npm/monaco-editor@0.31.1/min/vs"}});let hb=0;const ib=a=>{a.current?a.current.focus():hb<30&&setTimeout(()=>{hb+=1,ib(a)},100)},jb=({attributes:a,editor:b,element:c,language:e,...i})=>{const[j,k]=d.useState(null),l=(0,g.useMonaco)(),m=d.useRef(null),n=(0,h.useSelected)(),[o,p]=d.useState(28);d.useEffect(()=>{n&&(0,f.isCollapsed)(b.selection)&&ib(m)},[n,m.current]);const q=c.value||"";if("string"!=typeof q)throw new Error("Element must be of type string for code block");const r=e||c.lang,s=d.useMemo(()=>db(),[]),t=d.useMemo(()=>{const a={"":"plain text"};return l?l.languages.getLanguages().reduce((a,b)=>"plaintext"===b.id?a:{...a,[b.id]:b.id},a):a},[l]);d.useEffect(()=>{l&&(l.languages.typescript.typescriptDefaults.setEagerModelSync(!0),l.languages.typescript.typescriptDefaults.setDiagnosticsOptions({noSemanticValidation:!0,noSyntaxValidation:!0}))},[l]);const u=Object.entries(t).map(([a,b])=>({key:a,label:b,render:a=>a.label})),v=d.useMemo(()=>{var a;return null!=(a=u.find(a=>a.key===r))?a:{key:"",label:"Plain Text"}},[u,r]);return d.useEffect(()=>{if(j)switch(k(null),j){case"remove":(0,f.focusEditor)(b),(0,f.setNodes)(b,{type:"p",children:[{text:""}],lang:void 0,value:void 0},{match:a=>{if((0,f.isElement)(a)&&a.type===c.type)return!0}});break;case"insertNext":(0,f.insertNodes)(b,[{type:f.ELEMENT_DEFAULT,children:[{text:""}],lang:void 0,value:void 0}],{select:!0}),(0,f.focusEditor)(b);break;case"up":{const a=(0,f.findNodePath)(b,c);if(!a)return;const d=(0,f.getPointBefore)(b,a);if(!d){(0,f.focusEditor)(b),(0,f.insertNodes)(b,[{type:f.ELEMENT_DEFAULT,children:[{text:""}],lang:void 0,value:void 0}],{at:a,select:!0});return}(0,f.focusEditor)(b,d)}break;case"down":{const e=(0,f.findNodePath)(b,c);if(!e)return;const g=(0,f.getPointAfter)(b,e);g?(0,f.focusEditor)(b,g):((0,f.insertNodes)(b,[{type:f.ELEMENT_DEFAULT,children:[{text:""}],lang:void 0,value:void 0}],{select:!0}),(0,f.focusEditor)(b));break}}},[j]),d.createElement("div",{...a,className:"relative mb-2 mt-0.5 rounded-lg shadow-md p-2 border-gray-200 border"},d.createElement("style",null,`.tina-tailwind .monaco-editor .editor-widget {
          display: none !important;
          visibility: hidden !important;
        }`),i.children,d.createElement("div",{contentEditable:!1},!e&&d.createElement("div",{className:"flex justify-between pb-2"},d.createElement("div",null),d.createElement(gb,{items:u,value:v,defaultQuery:"plaintext",onChange:a=>(0,f.setNodes)(b,{lang:a.key})})),d.createElement("div",{style:{height:`${o}px`}},d.createElement(g.default,{path:s,onMount:function(a,b){m.current=a,a.onDidContentSizeChange(()=>{p(a.getContentHeight()),a.layout()}),a.addCommand(b.KeyMod.Shift|b.KeyCode.Enter,()=>{a.hasTextFocus()&&k("insertNext")}),a.onKeyDown(b=>{if("ArrowUp"===b.code){const c=a.getSelection();1===c.endLineNumber&&1===c.startLineNumber&&k("up")}if("ArrowDown"===b.code){const d=a.getSelection(),e=a.getModel().getLineCount();d.endLineNumber===e&&d.startLineNumber===e&&k("down")}if("Backspace"===b.code){const f=a.getSelection();1===f.endColumn&&1===f.endLineNumber&&1===f.positionColumn&&1===f.positionLineNumber&&1===f.selectionStartColumn&&1===f.selectionStartLineNumber&&1===f.startColumn&&1===f.startLineNumber&&k("remove")}})},options:{scrollBeyondLastLine:!1,tabSize:2,disableLayerHinting:!0,accessibilitySupport:"off",codeLens:!1,wordWrap:"on",minimap:{enabled:!1},fontSize:14,lineHeight:2,formatOnPaste:!0,lineNumbers:"off",formatOnType:!0,fixedOverflowWidgets:!0,folding:!1,renderLineHighlight:"none",scrollbar:{verticalScrollbarSize:1,horizontalScrollbarSize:1,alwaysConsumeMouseWheel:!1}},language:String(r),value:String(c.value),onChange:a=>{(0,f.setNodes)(b,{value:a,lang:r})}}))))},kb="mt-0.5",lb="font-normal",mb=()=>({[f.ELEMENT_H1]:({attributes:a,editor:b,element:c,className:e,...f})=>d.createElement("h1",{className:cb(lb,kb,e,"text-4xl font-medium mb-4 last:mb-0 mt-6 first:mt-0"),...a,...f}),[f.ELEMENT_H2]:({attributes:a,editor:b,element:c,className:e,...f})=>d.createElement("h2",{className:cb(lb,kb,e,"text-3xl font-medium mb-4 last:mb-0 mt-6 first:mt-0"),...a,...f}),[f.ELEMENT_H3]:({attributes:a,editor:b,element:c,className:e,...f})=>d.createElement("h3",{className:cb(lb,kb,e,"text-2xl font-semibold mb-4 last:mb-0 mt-6 first:mt-0"),...a,...f}),[f.ELEMENT_H4]:({attributes:a,editor:b,element:c,className:e,...f})=>d.createElement("h4",{className:cb(lb,kb,e,"text-xl font-bold mb-4 last:mb-0 mt-6 first:mt-0"),...a,...f}),[f.ELEMENT_H5]:({attributes:a,editor:b,element:c,className:e,...f})=>d.createElement("h5",{className:cb(lb,kb,e,"text-lg font-bold mb-4 last:mb-0 mt-6 first:mt-0"),...a,...f}),[f.ELEMENT_H6]:({attributes:a,editor:b,element:c,className:e,...f})=>d.createElement("h6",{className:cb(lb,kb,e,"text-base font-bold mb-4 last:mb-0 mt-6 first:mt-0"),...a,...f}),[f.ELEMENT_PARAGRAPH]:({attributes:a,className:b,editor:c,element:e,...f})=>d.createElement("div",{className:cb(kb,b,"text-base font-normal mb-4 last:mb-0"),...a,...f}),[f.ELEMENT_BLOCKQUOTE]:({className:a,attributes:b,editor:c,element:e,...f})=>d.createElement("blockquote",{className:cb("not-italic mb-4 last:mb-0 border-l-3 border-gray-200 pl-3",kb,a),...b,...f}),[f.ELEMENT_CODE_BLOCK]:a=>d.createElement(jb,{...a}),html:({attributes:a,editor:b,element:c,children:e,className:f})=>d.createElement("div",{...a,className:cb("font-mono text-sm bg-green-100 cursor-not-allowed mb-4",f)},e,c.value),html_inline:({attributes:a,editor:b,element:c,children:e,className:f})=>d.createElement("span",{...a,className:cb("font-mono bg-green-100 cursor-not-allowed",f)},e,c.value),[f.ELEMENT_UL]:({attributes:a,editor:b,className:c,element:e,...f})=>d.createElement("ul",{className:cb(kb,c,"mb-4 pl-4 list-disc list-inside last:mb-0"),...a,...f}),[f.ELEMENT_OL]:({attributes:a,editor:b,className:c,element:e,...f})=>d.createElement("ol",{className:cb(kb,c,"mb-4 pl-4 list-decimal list-inside last:mb-0"),...a,...f}),[f.ELEMENT_LI]:({attributes:a,className:b,editor:c,element:e,...f})=>d.createElement("li",{className:cb("p-0 mt-0 mb-0 list-outside",b),...a,...f}),[f.ELEMENT_LIC]:({attributes:a,editor:b,element:c,className:e,...f})=>d.createElement("span",{className:cb(e,"w-full inline-block align-top mb-2"),...a,...f}),[f.ELEMENT_LINK]:({attributes:a,editor:b,element:c,nodeProps:e,className:f,...g})=>d.createElement("a",{className:cb(f,"text-blue-500 hover:text-blue-600 transition-color ease-out duration-150 underline"),...a,...g}),[f.MARK_CODE]:({editor:a,leaf:b,text:c,attributes:e,className:f,...g})=>d.createElement("code",{className:cb("bg-gray-100 p-1 rounded-sm",f),...e,...g}),[f.MARK_ITALIC]:({editor:a,leaf:b,text:c,...e})=>d.createElement("em",{...e.attributes,...e}),[f.MARK_BOLD]:({editor:a,leaf:b,text:c,...e})=>d.createElement("strong",{...e.attributes,...e}),[f.ELEMENT_HR]:({attributes:a,className:b,editor:c,element:e,children:f,...g})=>{const i=(0,h.useSelected)();return d.createElement("div",{className:cb(b,"cursor-pointer relative border bg-gray-200 my-4 first:mt-0 last:mb-0"),...a,...g},f,i&&d.createElement("span",{className:"absolute h-4 -top-2 inset-0 ring-2 ring-blue-100 ring-inset rounded-md z-10 pointer-events-none"}))}}),nb={heading:d.createElement(qb,null),link:d.createElement(function(a){const b=a.title||"insert link";return d.createElement("svg",{height:"24",className:"h-5 w-5",width:"24",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null,b),d.createElement("g",{fill:"none"},d.createElement("path",{d:"M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1 0 1.71-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z",fill:"currentColor"})))},null),quote:d.createElement(function(a){const b=a.title||"format quote";return d.createElement("svg",{height:"24",className:"h-5 w-5",width:"24",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null,b),d.createElement("g",{fill:"none"},d.createElement("path",{d:"M6 17h3l2-4V7H5v6h3l-2 4zm8 0h3l2-4V7h-6v6h3l-2 4z",fill:"currentColor"})))},null),image:d.createElement(function(a){const b=a.title||"image";return d.createElement("svg",{className:"h-5 w-5",height:"24",width:"24",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null,b),d.createElement("g",{fill:"none"},d.createElement("path",{d:"M19 5v14H5V5h14zm0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-4.86 8.86l-3 3.87L9 13.14 6 17h12l-3.86-5.14z",fill:"currentColor"})))},null),ul:d.createElement(function(a){const b=a.title||"format list bulleted";return d.createElement("svg",{className:"h-5 w-5",height:"24",width:"24",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null,b),d.createElement("g",{fill:"none"},d.createElement("path",{d:"M7 5h14v2H7V5z",fill:"currentColor"}),d.createElement("path",{d:"M4 7.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z",fill:"currentColor"}),d.createElement("path",{d:"M7 11h14v2H7v-2zm0 6h14v2H7v-2zm-3 2.5c.82 0 1.5-.68 1.5-1.5s-.67-1.5-1.5-1.5-1.5.68-1.5 1.5.68 1.5 1.5 1.5z",fill:"currentColor"}),d.createElement("path",{d:"M4 13.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z",fill:"currentColor"})))},null),ol:d.createElement(function(a){const b=a.title||"format list numbered";return d.createElement("svg",{className:"h-5 w-5",height:"24",width:"24",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null,b),d.createElement("g",{fill:"none"},d.createElement("path",{d:"M2 17h2v.5H3v1h1v.5H2v1h3v-4H2v1zm1-9h1V4H2v1h1v3zm-1 3h1.8L2 13.1v.9h3v-1H3.2L5 10.9V10H2v1zm5-6v2h14V5H7zm0 14h14v-2H7v2zm0-6h14v-2H7v2z",fill:"currentColor"})))},null),code:d.createElement(function(a){const b=a.title||"code";return d.createElement("svg",{className:"h-5 w-5",height:"24",width:"24",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null,b),d.createElement("g",{fill:"none"},d.createElement("path",{d:"M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z",fill:"currentColor"})))},null),codeBlock:d.createElement(function(a){const b=a.title||"code-block";return d.createElement("svg",{className:"h-5 w-5",stroke:"currentColor",fill:"currentColor",strokeWidth:0,viewBox:"0 0 16 16",height:"1em",width:"1em",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null,b),d.createElement("path",{d:"M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"}),d.createElement("path",{d:"M6.854 4.646a.5.5 0 0 1 0 .708L4.207 8l2.647 2.646a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 0 1 .708 0zm2.292 0a.5.5 0 0 0 0 .708L11.793 8l-2.647 2.646a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708 0z"}))},null),bold:d.createElement(function(a){const b=a.title||"format bold";return d.createElement("svg",{className:"h-5 w-5",height:"24",width:"24",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null,b),d.createElement("g",{fill:"none"},d.createElement("path",{d:"M15.6 10.79c.97-.67 1.65-1.77 1.65-2.79 0-2.26-1.75-4-4-4H7v14h7.04c2.09 0 3.71-1.7 3.71-3.79 0-1.52-.86-2.82-2.15-3.42zM10 6.5h3c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5h-3v-3zm3.5 9H10v-3h3.5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5z",fill:"currentColor"})))},null),italic:d.createElement(function(a){const b=a.title||"format italic";return d.createElement("svg",{className:"h-5 w-5",height:"24",width:"24",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null,b),d.createElement("g",{fill:"none"},d.createElement("path",{d:"M10 4v3h2.21l-3.42 8H6v3h8v-3h-2.21l3.42-8H18V4h-8z",fill:"currentColor"})))},null),raw:d.createElement(()=>d.createElement("svg",{stroke:"currentColor",fill:"currentColor",strokeWidth:0,role:"img",className:"h-5 w-5",viewBox:"0 0 24 24",height:"1em",width:"1em",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null),d.createElement("path",{d:"M22.27 19.385H1.73A1.73 1.73 0 010 17.655V6.345a1.73 1.73 0 011.73-1.73h20.54A1.73 1.73 0 0124 6.345v11.308a1.73 1.73 0 01-1.73 1.731zM5.769 15.923v-4.5l2.308 2.885 2.307-2.885v4.5h2.308V8.078h-2.308l-2.307 2.885-2.308-2.885H3.46v7.847zM21.232 12h-2.309V8.077h-2.307V12h-2.308l3.461 4.039z"})),null)},ob=({name:a})=>nb[a],pb=({title:a})=>d.createElement(d.Fragment,null,a&&d.createElement("span",{className:"sr-only"},a),d.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",className:"h-5 w-5",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor"},d.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"})));function qb(a){const b=a.title||"format size";return d.createElement("svg",{height:"24",width:"24",className:"h-5 w-5",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},d.createElement("title",null,b),d.createElement("g",{fill:"none"},d.createElement("path",{d:"M9 4v3h5v12h3V7h5V4H9zm-6 8h3v7h3v-7h3V9H3v3z",fill:"currentColor"})))}function rb({className:a=""}){return d.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",className:`h-4 w-4 ${a}`,viewBox:"0 0 20 20",fill:"currentColor"},d.createElement("path",{fillRule:"evenodd",d:"M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z",clipRule:"evenodd"}))}class sb{constructor({id:tb,label:ub,fields:vb,actions:wb,buttons:xb,global:yb,reset:zb,loadInitialValues:Ab,onChange:Bb,queries:Cb,...Db}){this.global=null,this.loading=!1,this.subscribe=(a,b)=>this.finalForm.subscribe(a,b),this.handleSubmit=async(a,b,c)=>{try{const d=await this.onSubmit(a,b,c);return b.initialize(a),d}catch(e){return{[q.FORM_ERROR]:e}}},this.submit=()=>this.finalForm.submit();const Eb=Db.initialValues||{};if(this.__type=Db.__type||"form",this.id=tb,this.label=ub,this.global=yb,this.fields=vb||[],this.onSubmit=Db.onSubmit,this.queries=Cb||[],this.finalForm=(0,q.createForm)({...Db,initialValues:Eb,onSubmit:this.handleSubmit,mutators:{...o.default,setFieldData:p.default,...Db.mutators}}),this._reset=zb,this.actions=wb||[],this.buttons=xb||{save:"Save",reset:"Reset"},this.updateFields(this.fields),Ab&&(this.loading=!0,Ab().then(a=>{this.updateInitialValues(a)}).finally(()=>{this.loading=!1})),Bb){let Fb=!0;this.subscribe(a=>{Fb?Fb=!1:Bb(a)},{values:!0,...(null==Db?void 0:Db.extraSubscribeValues)||{}})}}get name(){}get values(){if(!this.loading)return this.finalForm.getState().values||this.initialValues}get initialValues(){return this.finalForm.getState().initialValues}get pristine(){return this.finalForm.getState().pristine}get dirty(){return this.finalForm.getState().dirty}get submitting(){return this.finalForm.getState().submitting}get valid(){return this.finalForm.getState().valid}async reset(){this._reset&&await this._reset(),this.finalForm.reset()}updateFields(Gb){this.fields=Gb}change(Hb,Ib){return this.finalForm.change(Hb,Ib)}get mutators(){return this.finalForm.mutators}addQuery(Jb){this.queries=[...this.queries.filter(a=>a!==Jb),Jb]}removeQuery(Kb){this.queries=this.queries.filter(a=>a!==Kb)}updateValues(Lb){this.finalForm.batch(()=>{const a=this.finalForm.getState().active;a?jc(this.finalForm,Lb):ic(this.finalForm,Lb)})}updateInitialValues(Mb){this.finalForm.batch(()=>{const a=this.values||{};this.finalForm.initialize(Mb);const b=this.finalForm.getState().active;b?jc(this.finalForm,a):ic(this.finalForm,a)})}getActiveField(Nb){return Nb?this.getFieldGroup({formOrObjectField:this,values:this.finalForm.getState().values,namePathIndex:0,namePath:Nb.split(".")}):this}getFieldGroup({formOrObjectField:Ob,values:Pb,namePathIndex:Qb,namePath:Rb}){const Sb=Rb[Qb],Tb=Ob.fields.find(a=>a.name===Sb),Ub=Pb[Sb],Vb=Qb===Rb.length-1;if(!Tb)return Ob;if("object"===Tb.type)if(Tb.templates){if(Tb.list){if(Vb)return console.log("isLast"),Ob;{const Wb=Qb+1,Xb=Rb[Wb],Yb=Ub[Xb],Zb=Tb.templates[Yb._template],$b=[...Rb.slice(0,Wb),Xb].join("."),_b=Wb===Rb.length-1;if(!_b)return this.getFieldGroup({formOrObjectField:Zb,values:Yb,namePath:Rb,namePathIndex:Qb+2});if(!Zb)throw console.error({field:Tb,value:Ub}),new Error(`Expected template value for field ${Tb.name}`);return{...Zb,name:$b,fields:Zb.fields.map(a=>({...a,name:[$b,a.name].join(".")}))}}}}else{if(Tb.list){const ac=Qb+1,bc=Rb[ac],cc=Ub[bc],dc=[...Rb.slice(0,ac),bc].join("."),ec=ac===Rb.length-1;return!ec&&Tb.fields?this.getFieldGroup({formOrObjectField:Tb,values:cc,namePath:Rb,namePathIndex:Qb+2}):{...Tb,name:dc,fields:Tb.fields.map(a=>({...a,name:[dc,a.name].join(".")}))}}{const fc=[...Rb.slice(0,Qb+1)].join("."),gc=Qb===Rb.length-1;return gc?{...Tb,name:fc,fields:Tb.fields.map(a=>({...a,name:[fc,a.name].join(".")}))}:this.getFieldGroup({formOrObjectField:Tb,values:Ub,namePath:Rb,namePathIndex:Qb+1})}}else{const hc=[...Rb.slice(0,Qb)].join(".");return hc?{...Ob,name:hc,fields:Ob.fields.map(a=>({...a,name:[hc,a.name].join(".")}))}:Ob}}}function ic(a,b){Object.entries(b).forEach(([b,c])=>{a.change(b,c)})}function jc(a,b,c){const d=a.getState().active;Object.entries(b).forEach(([b,e])=>{const f=c?`${c}.${b}`:b;"object"==typeof e?"string"==typeof d&&d.startsWith(f)?jc(a,e,f):a.change(f,e):f!==d&&a.change(f,e)})}const kc=lc;function lc(a){const b=Ta();let c;c=Array.isArray(a)?a:[a],d.useEffect(()=>(c.forEach(a=>{a&&b.plugins.add(a)}),()=>{c.forEach(a=>{a&&b.plugins.remove(a)})}),[b.plugins,...c])}function mc(a,b={}){const[c,d]=nc(a,b);return lc(d),[c,d]}function nc({loadInitialValues:a,...b},c={}){b.initialValues=b.initialValues||c.values;const[,e]=d.useState(b.initialValues),[f,g]=d.useState(()=>oc(b,a=>{e(a.values)}));d.useEffect(function(){f.id!==b.id&&g(oc(b,a=>{e(a.values)}))},[b.id]);const[h,i]=d.useState(()=>!!a),j=d.useCallback(async()=>{a&&(i(!0),await a().then(a=>{f.updateInitialValues(a)}).finally(()=>{i(!1)}))},[f,i]);return d.useEffect(()=>{j()},[f,j]),Ua("unstable:reload-form-data",async()=>{await j(),await f.reset()},[j,f]),pc(f,c.fields),qc(f,c.label),rc(f,c.values),[f?f.values:b.initialValues,f,h]}function oc(a,b){const c=new sb(a);return c.subscribe(b,{values:!0}),c}function pc(a,b){d.useEffect(()=>{void 0!==b&&a.updateFields(b)},[a,b])}function qc(a,b){d.useEffect(()=>{void 0!==b&&(a.label=b)},[a,b])}function rc(a,b){d.useEffect(()=>{void 0!==b&&a.updateValues(b)},[a,b])}function sc(a,b){const[,c]=d.useState(0);d.useEffect(()=>a.subscribe(()=>{c(a=>a+1),b&&b()}))}function tc(a,b){(0,d.useEffect)(()=>{if(!a)return;let c=!0;return a.subscribe(a=>{c?c=!1:b(a)},{values:!0})},[b,a])}function uc(a,b){return c=>(kc(b),d.createElement(a,{...c}))}const vc=uc;function wc({form:a,fields:b,activeFieldName:c,padding:e=!1}){const f=Ta(),[g,h]=d.useState([]),i=d.useCallback(()=>{const a=f.plugins.getType("field").all();h(a)},[h]);return d.useEffect(()=>i(),[]),Va("plugin:add:field",()=>i(),[]),d.createElement(yc,{padding:e},b.map((b,e)=>d.createElement(xc,{key:b.name,field:b,activeFieldName:c,form:a,fieldPlugins:g,index:e})))}const xc=({field:a,form:b,fieldPlugins:c,index:e,activeFieldName:f})=>{if(d.useEffect(()=>{b.mutators.setFieldData(a.name,{tinaField:a})},[b,a]),null===a.component)return null;const g=c.find(b=>b.name===a.component);let h;g&&g.type&&(h=g.type);const i=zc("parse",a,g),j=zc("validate",a,g);let k=a.format;!k&&g&&g.format&&(k=g.format);let l=a.name===f;if(a.list&&"string"===a.type&&f){const m=f.split("."),n=m.slice(0,m.length-1).join(".");a.name===n&&(l=!0)}return d.createElement(r.Field,{name:a.name,key:a.name,type:h,parse:i?(b,c)=>i(b,c,a):void 0,format:k?(b,c)=>k(b,c,a):void 0,validate:(b,c,d)=>{if(j)return j(b,c,d,a)}},c=>"string"!=typeof a.component&&null!==a.component?d.createElement(a.component,{...c,form:b.finalForm,tinaForm:b,field:{...a,experimental_focusIntent:l}}):g?d.createElement(g.Component,{...c,experimental_focusIntent:l,form:b.finalForm,tinaForm:b,field:{...a,experimental_focusIntent:l},index:e}):d.createElement("p",null,"Unrecognized field type"))},yc=({padding:a,children:b})=>d.createElement("div",{className:`relative block w-full h-full whitespace-nowrap overflow-x-visible ${a?"pb-5":""}`},b);function zc(a,b,c){let d=b[a];return!d&&c&&c[a]&&(d=c[a]),d}const Ac=r.Form,Bc=({form:a,children:b})=>{const[c,e]=d.useState(0);return d.useEffect(()=>{e(a=>a+1)},[a]),d.createElement(Ac,{form:a.finalForm,key:`${c}: ${a.id}`},b)},Cc=d.createContext(!1);function Dc({form:a,children:b}){const[c,e]=(0,d.useState)(!1);return a?d.createElement(Cc.Provider,{value:c},d.createElement(Bc,{form:a},()=>b({isEditing:c,setIsEditing:e}))):d.createElement(Cc.Provider,{value:c},b({isEditing:c,setIsEditing:e}))}function Ec({Component:a,children:b,...c}){const e=(0,d.useContext)(Cc);return e?d.createElement(r.Field,{...c},({input:b,meta:e})=>d.createElement(a,{input:b,meta:e,...c})):b||null}Ec.propTypes={name:t().string,type:t().string,Component:t().any.isRequired,children:t().any};const Fc=({variant:a="secondary",as:b="button",size:c="medium",busy:e,disabled:f,rounded:g="full",children:h,className:i,...j})=>{const k={disabled:`pointer-events-none	opacity-30 cursor-not-allowed`,busy:"pointer-events-none opacity-70 cursor-wait",default:""};return d.createElement(b,{className:`icon-parent border-0 inline-flex items-center font-medium focus:outline-none focus:ring-2 focus:shadow-outline text-center inline-flex justify-center transition-all duration-150 ease-out  ${{primary:"shadow text-white bg-blue-500 hover:bg-blue-600 focus:ring-blue-500",secondary:"shadow text-gray-500 hover:text-blue-500 bg-gray-50 hover:bg-white border border-gray-200",white:"shadow text-gray-500 hover:text-blue-500 bg-white hover:bg-gray-50 border border-gray-200",ghost:"text-gray-500 hover:text-blue-500 hover:shadow border border-transparent hover:border-gray-200 bg-transparent",danger:"shadow text-white bg-red-500 hover:bg-red-600 focus:ring-red-500"}[a]} ${{small:"text-xs h-8 px-3",medium:"text-sm h-10 px-4",custom:""}[c]} ${k[e?"busy":f?"disabled":"default"]} ${{full:"rounded-full",left:"rounded-l-full",right:"rounded-r-full",custom:""}[g]} ${i}`,...j},h)},Gc=({variant:a="secondary",size:b="medium",busy:c,disabled:e,children:f,className:g,...h})=>{const i={disabled:`pointer-events-none	opacity-30 cursor-not-allowed`,busy:"pointer-events-none opacity-70 cursor-wait",default:""};return d.createElement("button",{className:`icon-parent inline-flex items-center border border-transparent text-sm font-medium focus:outline-none focus:ring-2 focus:shadow-outline text-center inline-flex justify-center transition-all duration-150 ease-out rounded-full  ${{primary:"shadow text-white bg-blue-500 hover:bg-blue-600 focus:ring-blue-500",secondary:"shadow text-gray-500 hover:text-blue-500 bg-gray-50 hover:bg-white border border-gray-200",white:"shadow text-gray-500 hover:text-blue-500 bg-white hover:bg-gray-50 border border-gray-200",ghost:"text-gray-500 hover:text-blue-500 hover:shadow border border-transparent hover:border-gray-200 bg-transparent"}[a]} ${{small:"h-7 w-7",medium:"h-9 w-9",custom:""}[b]} ${i[c?"busy":e?"disabled":"default"]} ${g}`,...h},f)};function Hc(){const[a,b]=d.useState(!1),e={google:{families:["Inter:400,600"]},loading:()=>{b(!0)}};return d.useEffect(()=>{a||c.e(933).then(c.t.bind(c,75933,23)).then(a=>a.load(e))},[]),null}function Ic(...a){return a.filter(Boolean).join(" ")}const Jc=({toolbarItems:a})=>d.createElement(k.J,{as:"div",className:"relative block w-full"},({open:b})=>d.createElement(d.Fragment,null,d.createElement(k.J.Button,{"data-test":"popoverRichTextButton",className:`cursor-pointer relative w-full justify-center inline-flex border items-center p-3 text-sm font-medium focus:outline-none pointer-events-auto ${b?"text-blue-400":"text-gray-300 hover:text-blue-500"}`,onMouseDown:a=>{a.preventDefault()}},d.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",className:"h-5 w-5",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor"},d.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"}))),d.createElement(j.u,{as:d.Fragment,enter:"transition ease-out duration-100",enterFrom:"transform opacity-0 scale-95",enterTo:"transform opacity-100 scale-100",leave:"transition ease-in duration-75",leaveFrom:"transform opacity-100 scale-100",leaveTo:"transform opacity-0 scale-95"},d.createElement(k.J.Panel,{className:"absolute z-20 origin-top-right right-0"},({close:b})=>d.createElement("div",{className:"mt-0 -mr-1 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none py-1"},a.map(a=>d.createElement("span",{"data-test":`${a.name}OverflowButton`,key:a.name,onMouseDown:c=>{c.preventDefault(),b(),a.onMouseDown(c)},className:Ic(a.active?"bg-gray-50 text-blue-500":"bg-white text-gray-600","hover:bg-gray-50 hover:text-blue-500 cursor-pointer pointer-events-auto px-4 py-2 text-sm w-full flex items-center whitespace-nowrap")},d.createElement("div",{className:"mr-2 opacity-80"},a.Icon)," ",a.label))))))),Kc=({dotSize:a=8,color:b="white"})=>d.createElement("div",null,d.createElement("style",null,"@keyframes loading-dots-scale-up-and-down {\n  0% {\n    transform: scale(0.1);\n  }\n\n  50% {\n    transform: scale(1);\n  }\n\n  90% {\n    transform: scale(0.1);\n  }\n\n  100% {\n    transform: scale(0.1);\n  }\n}\n"),d.createElement(Lc,{dotSize:a,color:b}),d.createElement(Lc,{dotSize:a,color:b,delay:.3}),d.createElement(Lc,{dotSize:a,color:b,delay:.5})),Lc=({delay:a=0,color:b,dotSize:c})=>d.createElement("span",{className:"inline-block mr-1",style:{animation:"loading-dots-scale-up-and-down 2s linear infinite",animationDelay:`${a}s`,background:b,width:c,height:c,borderRadius:c}}),Mc=d.createContext(()=>null);function Nc(){return(0,d.useContext)(Mc)}const Oc=({children:a})=>{const b=d.useRef(null),c=d.useRef(0),f=d.useCallback(a=>b.current?(0,e.createPortal)(a.children({zIndexShift:c.current+=1}),b.current):null,[b,c]);return d.createElement(Mc.Provider,{value:f},d.createElement("div",{ref:b,style:{position:"relative",width:"100%",flex:"1 1 0%",overflow:"hidden"}},a))},Pc=({pristine:a,reset:b,children:c,...e})=>{const[f,g]=d.useState(!1);return d.createElement(d.Fragment,null,d.createElement(Fc,{onClick:()=>{g(a=>!a)},disabled:a,...e},c),f&&d.createElement(Qc,{reset:b,close:()=>g(!1)}))},Qc=({close:a,reset:b})=>d.createElement(N,null,d.createElement(Qa,null,d.createElement(La,{close:a},"Reset"),d.createElement(P,{padded:!0},d.createElement("p",null,"Are you sure you want to reset all changes?")),d.createElement(O,null,d.createElement(Fc,{style:{flexGrow:2},onClick:a},"Cancel"),d.createElement(Fc,{style:{flexGrow:3},variant:"primary",onClick:async()=>{await b(),a()}},"Reset")))),Rc=({onDismiss:a,escape:b,click:c,disabled:e,allowClickPropagation:f,document:g,...h})=>{const i=Sc({onDismiss:a,escape:b,click:c,disabled:e,allowClickPropagation:f,document:g});return d.createElement("div",{ref:i,...h})};function Sc({onDismiss:a,escape:b=!1,click:c=!1,disabled:e=!1,allowClickPropagation:f=!1,document:g}){const h=(0,d.useRef)();return(0,d.useEffect)(()=>{const d=g?[document,g]:[document],i=a=>{a.stopPropagation(),a.stopImmediatePropagation(),a.preventDefault()},j=b=>{e||h.current.contains(b.target)||(console.log("did not click main content",b.target,h.current),f||i(b),a(b))},k=b=>{e||27===b.keyCode&&(b.stopPropagation(),a(b))};return c&&d.forEach(a=>a.body.addEventListener("click",j)),b&&d.forEach(a=>a.addEventListener("keydown",k)),()=>{d.forEach(a=>{a.body.removeEventListener("click",j),a.removeEventListener("keydown",k)})}},[c,g,b,e,a]),h}const Tc=({actions:a,form:b})=>{const[c,e]=(0,d.useState)(!1);return d.createElement(d.Fragment,null,d.createElement(Uc,{onClick:()=>e(a=>!a)}),d.createElement(Vc,{open:c},d.createElement(Rc,{click:!0,escape:!0,disabled:!c,onDismiss:()=>{e(a=>!a)}},a.map((a,c)=>d.createElement(a,{form:b,key:c})))))},Uc=({className:a="",...b})=>d.createElement("button",{className:`h-16 w-10 self-stretch bg-transparent bg-center bg-[length:auto_18px] -mr-4 ml-2 outline-none cursor-pointer transition-opacity duration-100 ease-out flex justify-center items-center hover:bg-gray-50 hover:fill-gray-700 ${a}`,...b},d.createElement(V,null)),Vc=({open:a,className:b="",style:c={},...e})=>d.createElement("div",{className:`min-w-[192px] rounded-3xl border border-solid border-[#efefef] block absolute bottom-5 right-5 ${a?"opacity-100":"opacity-0"} transition-all duration-100 ease-out origin-bottom-right shadow-[0_2px_3px_rgba(0,0,0,0.05)] bg-white overflow-hidden z-10 ${b}`,style:{transform:a?"translate3d(0, -28px, 0) scale3d(1, 1, 1)":"translate3d(0, 0, 0) scale3d(0.5, 0.5, 1)",pointerEvents:a?"all":"none",...c},...e}),Wc=({className:a="",...b})=>d.createElement("button",{className:`relative text-center text-[13px] px-3 h-10 font-normal w-full bg-none cursor-pointer outline-none border-0 transition-all duration-[150ms] ease-out hover:text-blue-500 hover:bg-gray50 [&:not(:last-child)]: border-b-[1px] border-solid border-b-[#edecf3] ${a}`,...b});var Xc={color:void 0,size:void 0,className:void 0,style:void 0,attr:void 0},Yc=d.createContext&&d.createContext(Xc),Zc=globalThis&&globalThis.__assign||function(){return(Zc=Object.assign||function(a){for(var b,c=1,d=arguments.length;c<d;c++)for(var e in b=arguments[c])Object.prototype.hasOwnProperty.call(b,e)&&(a[e]=b[e]);return a}).apply(this,arguments)},$c=globalThis&&globalThis.__rest||function(a,b){var c={};for(var d in a)Object.prototype.hasOwnProperty.call(a,d)&&0>b.indexOf(d)&&(c[d]=a[d]);if(null!=a&&"function"==typeof Object.getOwnPropertySymbols)for(var e=0,d=Object.getOwnPropertySymbols(a);e<d.length;e++)0>b.indexOf(d[e])&&Object.prototype.propertyIsEnumerable.call(a,d[e])&&(c[d[e]]=a[d[e]]);return c};function _c(a){return a&&a.map(function(a,b){return d.createElement(a.tag,Zc({key:b},a.attr),_c(a.child))})}function ad(a){return function(b){return d.createElement(bd,Zc({attr:Zc({},a.attr)},b),_c(a.child))}}function bd(a){var b=function(b){var c,e=a.attr,f=a.size,g=a.title,h=$c(a,["attr","size","title"]),i=f||b.size||"1em";return b.className&&(c=b.className),a.className&&(c=(c?c+" ":"")+a.className),d.createElement("svg",Zc({stroke:"currentColor",fill:"currentColor",strokeWidth:"0"},b.attr,e,h,{className:c,style:Zc(Zc({color:a.color||b.color},b.style),a.style),height:i,width:i,xmlns:"http://www.w3.org/2000/svg"}),g&&d.createElement("title",null,g),a.children)};return void 0!==Yc?d.createElement(Yc.Consumer,null,function(a){return b(a)}):b(Xc)}function cd(a){return ad({tag:"svg",attr:{viewBox:"0 0 512 512"},child:[{tag:"path",attr:{d:"M405 136.798L375.202 107 256 226.202 136.798 107 107 136.798 226.202 256 107 375.202 136.798 405 256 285.798 375.202 405 405 375.202 285.798 256z"}}]})(a)}function dd(a){return ad({tag:"svg",attr:{viewBox:"0 0 512 512"},child:[{tag:"path",attr:{d:"M256 388c-72.597 0-132-59.405-132-132 0-72.601 59.403-132 132-132 36.3 0 69.299 15.4 92.406 39.601L278 234h154V80l-51.698 51.702C348.406 99.798 304.406 80 256 80c-96.797 0-176 79.203-176 176s78.094 176 176 176c81.045 0 148.287-54.134 169.401-128H378.85c-18.745 49.561-67.138 84-122.85 84z"}}]})(a)}const ed=()=>d.createElement("div",{className:"relative flex flex-col items-center justify-center text-center p-5 pb-16 w-full h-full overflow-y-auto",style:{animationName:"fade-in",animationDelay:"300ms",animationTimingFunction:"ease-out",animationIterationCount:1,animationFillMode:"both",animationDuration:"150ms"}},d.createElement(jd,{className:"block pb-5"},"🤔"),d.createElement("h3",{className:"font-sans font-normal text-lg block pb-5"},"Hey, you don't have any fields added to this form."),d.createElement("p",{className:"block pb-5"},d.createElement("a",{className:"text-center rounded-3xl border border-solid border-gray-100 shadow-[0_2px_3px_rgba(0,0,0,0.12)] font-normal cursor-pointer text-[12px] transition-all duration-100 ease-out bg-white text-gray-700 py-3 pr-5 pl-14 relative no-underline inline-block hover:text-blue-500",href:"https://tinacms.org/docs/fields",target:"_blank"},d.createElement(jd,{className:"absolute left-5 top-1/2 origin-center -translate-y-1/2 transition-all duration-100 ease-out",style:{fontSize:24}},"📖")," ","Field Setup Guide"))),fd=({onSubmit:a})=>((0,d.useEffect)(()=>{const b=b=>{(b.metaKey||b.ctrlKey)&&"s"===b.key&&(b.preventDefault(),a())};return window.addEventListener("keydown",b),()=>window.removeEventListener("keydown",b)},[a]),null),gd=({form:a,onPristineChange:b,...c})=>{Ta();const e=!!c.hideFooter,f=a.tinaForm,g=a.tinaForm.finalForm,h=d.useCallback(a=>{if(!a.destination||!g)return;const b=a.type;g.mutators.move(b,a.source.index,a.destination.index)},[f]);d.useEffect(()=>{const a=g.subscribe(({pristine:a})=>{b&&b(a)},{pristine:!0});return()=>{a()}},[g]);const i=f.getActiveField(a.activeFieldName),j=function(a){const b=d.useRef(null);return(0,d.useEffect)(()=>{b.current=a},[a]),b.current}(i.name);return i.name===j||i.name&&j&&j.length<i.name.length,d.createElement(r.Form,{key:f.id,form:f.finalForm,onSubmit:f.onSubmit},({handleSubmit:b,pristine:c,invalid:j,submitting:k,dirtySinceLastSubmit:l,hasValidationErrors:m})=>{const n=!c&&!k&&!m&&!(j&&!l),o=()=>{n&&b()};return d.createElement(d.Fragment,null,d.createElement(u.DragDropContext,{onDragEnd:h},d.createElement(fd,{onSubmit:o}),d.createElement(Oc,null,d.createElement(id,{header:d.createElement(ld,{...i,id:f.id}),id:f.id},f&&f.fields.length?d.createElement(wc,{form:f,activeFieldName:a.activeFieldName,fields:i.fields}):d.createElement(ed,null))),!e&&d.createElement("div",{className:"relative flex-none w-full h-16 px-6 bg-white border-t border-gray-100\tflex items-center justify-center"},d.createElement("div",{className:"flex-1 w-full flex justify-between gap-4 items-center max-w-form"},f.reset&&d.createElement(Pc,{pristine:c,reset:async()=>{g.reset(),await f.reset()},style:{flexGrow:1}},f.buttons.reset),d.createElement(Fc,{onClick:o,disabled:!n,busy:k,variant:"primary",style:{flexGrow:3}},k&&d.createElement(Kc,null),!k&&f.buttons.save),f.actions.length>0&&d.createElement(Tc,{form:f,actions:f.actions})))))})},hd=({pristine:a})=>d.createElement("div",{className:"flex flex-0 items-center"},!a&&d.createElement(d.Fragment,null,d.createElement("span",{className:"w-3 h-3 flex-0 rounded-full bg-yellow-400 border border-yellow-500 mr-2"})," ",d.createElement("p",{className:"text-gray-700 text-sm leading-tight whitespace-nowrap"},"Unsaved Changes")),a&&d.createElement(d.Fragment,null,d.createElement("span",{className:"w-3 h-3 flex-0 rounded-full bg-green-300 border border-green-400 mr-2"})," ",d.createElement("p",{className:"text-gray-500 text-sm leading-tight whitespace-nowrap"},"No Changes"))),id=({header:a,children:b,id:c})=>d.createElement("div",{"data-test":`form:${null==c?void 0:c.replace(/\\/g,"/")}`,className:"h-full overflow-y-auto max-h-full bg-gray-50"},a,d.createElement("div",{className:"py-5 px-6"},d.createElement("div",{className:"w-full flex justify-center"},d.createElement("div",{className:"w-full max-w-form"},b)))),jd=({className:a="",...b})=>d.createElement("span",{className:`text-[40px] leading-none inline-block ${a}`,...b}),kd=a=>!isNaN(Number(a)),ld=a=>{var b;const c=Ta(),e=(null==(b=a.name)?void 0:b.split("."))||[];if(!e||0===e.length)return null;let f;e.forEach((a,b)=>{kd(a)||(f=b)});const g=e.slice(0,f);return d.createElement("button",{className:`relative z-40 group text-left w-full bg-white hover:bg-gray-50 py-2 border-t border-b shadow-sm
   border-gray-100 px-6 -mt-px`,onClick:()=>{c.dispatch({type:"forms:set-active-field-name",value:{formId:a.id,fieldName:g.length>0?g.join("."):null}})},tabIndex:-1},d.createElement("div",{className:"flex items-center justify-between gap-3 text-xs tracking-wide font-medium text-gray-700 group-hover:text-blue-400 uppercase max-w-form mx-auto"},a.label||a.name||"Back",d.createElement(cd,{className:"h-auto w-5 inline-block opacity-70 -mt-0.5 -mx-0.5"})))};function md(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M6 18h12v2H6zm5-14v8.586L6.707 8.293 5.293 9.707 12 16.414l6.707-6.707-1.414-1.414L13 12.586V4z"}}]})(a)}function nd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"m10 15.586-3.293-3.293-1.414 1.414L10 18.414l9.707-9.707-1.414-1.414z"}}]})(a)}function od(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"}}]})(a)}function pd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z"}}]})(a)}function qd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M13 19v-4h3l-4-5-4 5h3v4z"}},{tag:"path",attr:{d:"M7 19h2v-2H7c-1.654 0-3-1.346-3-3 0-1.404 1.199-2.756 2.673-3.015l.581-.102.192-.558C8.149 8.274 9.895 7 12 7c2.757 0 5 2.243 5 5v1h1c1.103 0 2 .897 2 2s-.897 2-2 2h-3v2h3c2.206 0 4-1.794 4-4a4.01 4.01 0 0 0-3.056-3.888C18.507 7.67 15.56 5 12 5 9.244 5 6.85 6.611 5.757 9.15 3.609 9.792 2 11.82 2 14c0 2.757 2.243 5 5 5z"}}]})(a)}function rd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M20 2H10c-1.103 0-2 .897-2 2v4H4c-1.103 0-2 .897-2 2v10c0 1.103.897 2 2 2h10c1.103 0 2-.897 2-2v-4h4c1.103 0 2-.897 2-2V4c0-1.103-.897-2-2-2zM4 20V10h10l.002 10H4zm16-6h-4v-4c0-1.103-.897-2-2-2h-4V4h10v10z"}},{tag:"path",attr:{d:"M6 12h6v2H6zm0 4h6v2H6z"}}]})(a)}function sd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"m7 17.013 4.413-.015 9.632-9.54c.378-.378.586-.88.586-1.414s-.208-1.036-.586-1.414l-1.586-1.586c-.756-.756-2.075-.752-2.825-.003L7 12.583v4.43zM18.045 4.458l1.589 1.583-1.597 1.582-1.586-1.585 1.594-1.58zM9 13.417l6.03-5.973 1.586 1.586-6.029 5.971L9 15.006v-1.589z"}},{tag:"path",attr:{d:"M5 21h14c1.103 0 2-.897 2-2v-8.668l-2 2V19H8.158c-.026 0-.053.01-.079.01-.033 0-.066-.009-.1-.01H5V5h6.847l2-2H5c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2z"}}]})(a)}function td(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M11.001 10h2v5h-2zM11 16h2v2h-2z"}},{tag:"path",attr:{d:"M13.768 4.2C13.42 3.545 12.742 3.138 12 3.138s-1.42.407-1.768 1.063L2.894 18.064a1.986 1.986 0 0 0 .054 1.968A1.984 1.984 0 0 0 4.661 21h14.678c.708 0 1.349-.362 1.714-.968a1.989 1.989 0 0 0 .054-1.968L13.768 4.2zM4.661 19 12 5.137 19.344 19H4.661z"}}]})(a)}function ud(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M19.002 3h-14c-1.103 0-2 .897-2 2v4h2V5h14v14h-14v-4h-2v4c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2V5c0-1.103-.898-2-2-2z"}},{tag:"path",attr:{d:"m11 16 5-4-5-4v3.001H3v2h8z"}}]})(a)}function vd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M5 12H3v9h9v-2H5zm7-7h7v7h2V3h-9z"}}]})(a)}function wd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M19.937 8.68c-.011-.032-.02-.063-.033-.094a.997.997 0 0 0-.196-.293l-6-6a.997.997 0 0 0-.293-.196c-.03-.014-.062-.022-.094-.033a.991.991 0 0 0-.259-.051C13.04 2.011 13.021 2 13 2H6c-1.103 0-2 .897-2 2v16c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2V9c0-.021-.011-.04-.013-.062a.99.99 0 0 0-.05-.258zM16.586 8H14V5.414L16.586 8zM6 20V4h6v5a1 1 0 0 0 1 1h5l.002 10H6z"}}]})(a)}function xd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M19.903 8.586a.997.997 0 0 0-.196-.293l-6-6a.997.997 0 0 0-.293-.196c-.03-.014-.062-.022-.094-.033a.991.991 0 0 0-.259-.051C13.04 2.011 13.021 2 13 2H6c-1.103 0-2 .897-2 2v16c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2V9c0-.021-.011-.04-.013-.062a.952.952 0 0 0-.051-.259c-.01-.032-.019-.063-.033-.093zM16.586 8H14V5.414L16.586 8zM6 20V4h6v5a1 1 0 0 0 1 1h5l.002 10H6z"}},{tag:"path",attr:{d:"M8 12h8v2H8zm0 4h8v2H8zm0-8h2v2H8z"}}]})(a)}function yd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M20 5h-8.586L9.707 3.293A.997.997 0 0 0 9 3H4c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V7c0-1.103-.897-2-2-2zM4 19V7h16l.002 12H4z"}}]})(a)}function zd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M17.5 4C15.57 4 14 5.57 14 7.5c0 1.554 1.025 2.859 2.43 3.315-.146.932-.547 1.7-1.23 2.323-1.946 1.773-5.527 1.935-7.2 1.907V8.837c1.44-.434 2.5-1.757 2.5-3.337C10.5 3.57 8.93 2 7 2S3.5 3.57 3.5 5.5c0 1.58 1.06 2.903 2.5 3.337v6.326c-1.44.434-2.5 1.757-2.5 3.337C3.5 20.43 5.07 22 7 22s3.5-1.57 3.5-3.5c0-.551-.14-1.065-.367-1.529 2.06-.186 4.657-.757 6.409-2.35 1.097-.997 1.731-2.264 1.904-3.768C19.915 10.438 21 9.1 21 7.5 21 5.57 19.43 4 17.5 4zm-12 1.5C5.5 4.673 6.173 4 7 4s1.5.673 1.5 1.5S7.827 7 7 7s-1.5-.673-1.5-1.5zM7 20c-.827 0-1.5-.673-1.5-1.5a1.5 1.5 0 0 1 1.482-1.498l.13.01A1.495 1.495 0 0 1 7 20zM17.5 9c-.827 0-1.5-.673-1.5-1.5S16.673 6 17.5 6s1.5.673 1.5 1.5S18.327 9 17.5 9z"}}]})(a)}function Ad(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M10 3H4a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zM9 9H5V5h4v4zm5 2h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1zm1-6h4v4h-4V5zM3 20a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v6zm2-5h4v4H5v-4zm8 5a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v6zm2-5h4v4h-4v-4z"}}]})(a)}function Bd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M12.707 17.293 8.414 13H18v-2H8.414l4.293-4.293-1.414-1.414L4.586 12l6.707 6.707z"}}]})(a)}function Cd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"m13 3 3.293 3.293-7 7 1.414 1.414 7-7L21 11V3z"}},{tag:"path",attr:{d:"M19 19H5V5h7l-2-2H5c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2v-5l-2-2v7z"}}]})(a)}function Dd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M4 6h2v2H4zm0 5h2v2H4zm0 5h2v2H4zm16-8V6H8.023v2H18.8zM8 11h12v2H8zm0 5h12v2H8z"}}]})(a)}function Ed(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"}}]})(a)}function Fd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M4 21a1 1 0 0 0 .24 0l4-1a1 1 0 0 0 .47-.26L21 7.41a2 2 0 0 0 0-2.82L19.42 3a2 2 0 0 0-2.83 0L4.3 15.29a1.06 1.06 0 0 0-.27.47l-1 4A1 1 0 0 0 3.76 21 1 1 0 0 0 4 21zM18 4.41 19.59 6 18 7.59 16.42 6zM5.91 16.51 15 7.41 16.59 9l-9.1 9.1-2.11.52z"}}]})(a)}function Gd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M19 11h-6V5h-2v6H5v2h6v6h2v-6h6z"}}]})(a)}function Hd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M10 11H7.101l.001-.009a4.956 4.956 0 0 1 .752-1.787 5.054 5.054 0 0 1 2.2-1.811c.302-.128.617-.226.938-.291a5.078 5.078 0 0 1 2.018 0 4.978 4.978 0 0 1 2.525 1.361l1.416-1.412a7.036 7.036 0 0 0-2.224-1.501 6.921 6.921 0 0 0-1.315-.408 7.079 7.079 0 0 0-2.819 0 6.94 6.94 0 0 0-1.316.409 7.04 7.04 0 0 0-3.08 2.534 6.978 6.978 0 0 0-1.054 2.505c-.028.135-.043.273-.063.41H2l4 4 4-4zm4 2h2.899l-.001.008a4.976 4.976 0 0 1-2.103 3.138 4.943 4.943 0 0 1-1.787.752 5.073 5.073 0 0 1-2.017 0 4.956 4.956 0 0 1-1.787-.752 5.072 5.072 0 0 1-.74-.61L7.05 16.95a7.032 7.032 0 0 0 2.225 1.5c.424.18.867.317 1.315.408a7.07 7.07 0 0 0 2.818 0 7.031 7.031 0 0 0 4.395-2.945 6.974 6.974 0 0 0 1.053-2.503c.027-.135.043-.273.063-.41H22l-4-4-4 4z"}}]})(a)}function Id(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"m11.293 17.293 1.414 1.414L19.414 12l-6.707-6.707-1.414 1.414L15.586 11H6v2h9.586z"}}]})(a)}function Jd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M10 18a7.952 7.952 0 0 0 4.897-1.688l4.396 4.396 1.414-1.414-4.396-4.396A7.952 7.952 0 0 0 18 10c0-4.411-3.589-8-8-8s-8 3.589-8 8 3.589 8 8 8zm0-14c3.309 0 6 2.691 6 6s-2.691 6-6 6-6-2.691-6-6 2.691-6 6-6z"}}]})(a)}function Kd(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"m16.192 6.344-4.243 4.242-4.242-4.242-1.414 1.414L10.535 12l-4.242 4.242 1.414 1.414 4.242-4.242 4.243 4.242 1.414-1.414L13.364 12l4.242-4.242z"}}]})(a)}const Ld=Ya(({tinaForm:a,field:b})=>{const c=Ta();return d.useState(!1),d.createElement(d.Fragment,null,d.createElement(Md,{onClick:()=>{const d=a.finalForm.getState();if(!0===d.invalid){c.alerts.error("Cannot navigate away from an invalid form.");return}c.dispatch({type:"forms:set-active-field-name",value:{formId:a.id,fieldName:b.name}})}},b.label||b.name))}),Md=({onClick:a,children:b})=>d.createElement("div",{className:"pt-1 mb-5"},d.createElement("button",{onClick:a,className:"group px-4 py-3 bg-white hover:bg-gray-50 shadow focus:shadow-outline focus:border-blue-500 w-full border border-gray-100 hover:border-gray-200 text-gray-500 hover:text-blue-400 focus:text-blue-500 rounded-md flex justify-between items-center gap-2"},d.createElement("span",{className:"text-left text-base font-medium overflow-hidden text-ellipsis whitespace-nowrap flex-1"},b)," ",d.createElement(Fd,{className:"h-6 w-auto transition-opacity duration-150 ease-out opacity-80 group-hover:opacity-90"}))),Nd=({onClick:a,children:b})=>d.createElement("button",{className:`relative z-40 group text-left w-full bg-white hover:bg-gray-50 py-2 border-t border-b shadow-sm
       border-gray-100 px-6 -mt-px`,onClick:a,tabIndex:-1},d.createElement("div",{className:"flex items-center justify-between gap-3 text-xs tracking-wide font-medium text-gray-700 group-hover:text-blue-400 uppercase max-w-form mx-auto"},b,d.createElement(cd,{className:"h-auto w-5 inline-block opacity-70 -mt-0.5 -mx-0.5"}))),Od=({id:a,children:b})=>d.createElement("div",{style:{flex:"1 1 0%",width:"100%",overflowY:"auto",background:"var(--tina-color-grey-1)"}},d.createElement(id,{id:a},b)),Pd=({isExpanded:a,className:b="",style:c={},...e})=>d.createElement("div",{className:`absolute w-full top-0 bottom-0 left-0 flex flex-col justify-between overflow-hidden z-10 ${b}`,style:{pointerEvents:a?"all":"none",...a?{animationName:"fly-in-left",animationDuration:"150ms",animationDelay:"0",animationIterationCount:1,animationTimingFunction:"ease-out",animationFillMode:"backwards"}:{transition:"transform 150ms ease-out",transform:"translate3d(100%, 0, 0)"},...c},...e});function Qd(a){return d.createElement("div",null,"Subfield: ",a.field.label||a.field.name)}const Rd={name:"group",Component:Ld},Sd=a=>{const b=Nc(),c=d.useMemo(()=>db(),[a.id]),e=d.useMemo(()=>new sb({...a,id:c,onChange:({values:b})=>{a.onChange(b)},onSubmit:()=>{}}),[c]);return d.createElement(b,null,({zIndexShift:b})=>d.createElement(Pd,{isExpanded:!0,style:{zIndex:b+1e3}},d.createElement(Nd,{onClick:a.onClose},a.label),d.createElement(gd,{form:{tinaForm:e},hideFooter:!0})))},Td=(a,b)=>{const c=h.ReactEditor.findPath(a,b),d=h.ReactEditor.toDOMNode(a,a);d&&(d.focus(),setTimeout(()=>{n.Transforms.select(a,c)},1))},Ud=(a,b)=>{const c=h.ReactEditor.findPath(a,b);n.Transforms.removeNodes(a,{at:c})},Vd=(a,b)=>{const c=(0,h.useSelected)();d.useEffect(()=>{const d=d=>{c&&(0,v.default)(a,d)&&(d.preventDefault(),b())};return document.addEventListener("keydown",d),()=>document.removeEventListener("keydown",d)},[c])},Wd=(a,b)=>{const[c,e]=d.useState(!1);return{isExpanded:c,handleClose:()=>{e(!1),Td(a,b)},handleRemove:()=>{Ud(a,b)},handleSelect:a=>{a.preventDefault(),e(!0)}}},Xd=d.createContext({rawMode:!1,setRawMode:()=>{},templates:[]}),Yd=()=>d.useContext(Xd),Zd=()=>{const{templates:a}=d.useContext(Xd);return a},$d=({inline:a,children:b})=>d.createElement(a?"span":"div",{contentEditable:!1,style:{userSelect:"none"},className:"relative"},b),_d=({attributes:a,children:b,element:c,onChange:e,editor:g})=>{const i=(0,h.useSelected)(),{handleClose:j,handleRemove:k,handleSelect:l,isExpanded:m}=Wd(g,c);Vd("enter",()=>{(0,f.insertNodes)(g,[{type:f.ELEMENT_PARAGRAPH,children:[{text:""}]}])}),Vd("space",()=>{(0,f.insertNodes)(g,[{text:" "}],{match:a=>{if(n.Element.isElement(a)&&a.type===Bf)return!0},select:!0})});const o=Zd(),p=o.find(a=>a.name===c.name),q={activeTemplate:p,element:c,editor:g,onChange:e,onClose:j};if(!p)return null;const r=be(p,q);return d.createElement("span",{...a},b,d.createElement($d,{inline:!0},d.createElement("span",{style:{margin:"0 0.5px"},className:"relative inline-flex shadow-sm rounded-md leading-none"},i&&d.createElement("span",{className:"absolute inset-0 ring-2 ring-blue-100 ring-inset rounded-md z-10 pointer-events-none"}),d.createElement("span",{style:{fontWeight:"inherit",maxWidth:"275px"},className:"truncate cursor-pointer relative inline-flex items-center justify-start px-2 py-0.5 rounded-l-md border border-gray-200 bg-white  hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500",onMouseDown:l},r),d.createElement(de,{onOpen:l,onRemove:k})),m&&d.createElement(ce,{...q})))},ae=({attributes:a,children:b,element:c,editor:e,onChange:g})=>{const i=(0,h.useSelected)(),{handleClose:j,handleRemove:k,handleSelect:l,isExpanded:m}=Wd(e,c);Vd("enter",()=>{(0,f.insertNodes)(e,[{type:f.ELEMENT_PARAGRAPH,children:[{text:""}]}])});const n=Zd(),o=n.find(a=>a.name===c.name),p={activeTemplate:o,element:c,editor:e,onChange:g,onClose:j};if(!o)return null;const q=be(o,p);return d.createElement("div",{...a,className:"w-full my-2"},b,d.createElement($d,{inline:!1},d.createElement("span",{className:"relative w-full inline-flex shadow-sm rounded-md"},i&&d.createElement("span",{className:"absolute inset-0 ring-2 ring-blue-100 ring-inset rounded-md z-10 pointer-events-none"}),d.createElement("span",{onMouseDown:l,className:"truncate cursor-pointer w-full relative inline-flex items-center justify-start px-4 py-2 rounded-l-md border border-gray-200 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"},q),d.createElement(de,{onOpen:l,onRemove:k})),m&&d.createElement(ce,{...p})))},be=(a,b)=>{const c=a.fields.find(a=>a.isTitle);let d=a.label||a.name;if(c){const e=b.element.props[c.name];e&&(d=`${d}: ${e}`)}return d},ce=({editor:a,element:b,activeTemplate:c,onClose:e,onChange:f})=>{const g=h.ReactEditor.findPath(a,b),i=[...g,c.name].join(".");return d.createElement(Sd,{id:i,label:c.label,fields:c.fields,initialValues:b.props,onChange:f,onClose:e})},de=({onOpen:a,onRemove:b})=>d.createElement(k.J,{as:"span",className:"-ml-px relative block"},d.createElement(k.J.Button,{as:"span",className:"cursor-pointer h-full relative inline-flex items-center px-1 py-0.5 rounded-r-md border border-gray-200 bg-white text-gray-500 hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"},d.createElement(pb,{title:"Open options"})),d.createElement(j.u,{as:d.Fragment,enter:"transition ease-out duration-100",enterFrom:"transform opacity-0 scale-95",enterTo:"transform opacity-100 scale-100",leave:"transition ease-in duration-75",leaveFrom:"transform opacity-100 scale-100",leaveTo:"transform opacity-0 scale-95"},d.createElement(k.J.Panel,{className:"z-30 absolute origin-top-right right-0"},d.createElement("div",{className:"mt-2 -mr-1 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none"},d.createElement("div",{className:"py-1"},d.createElement("span",{onClick:a,className:cb("cursor-pointer text-left w-full block px-4 py-2 text-sm hover:bg-gray-100 hover:text-gray-900")},"Edit"),d.createElement("button",{onMouseDown:a=>{a.preventDefault(),b()},className:cb("cursor-pointer text-left w-full block px-4 py-2 text-sm hover:bg-gray-100 hover:text-gray-900")},"Remove")))))),ee=(0,f.createPluginFactory)({key:"code_block",isElement:!0,isVoid:!0,isInline:!1}),fe=(0,f.createPluginFactory)({key:"html",isElement:!0,isVoid:!0,isInline:!1}),ge=(0,f.createPluginFactory)({key:"html_inline",isElement:!0,isVoid:!0,isInline:!0}),he="shadow-inner focus:shadow-outline focus:border-blue-500 focus:outline-none block text-base placeholder:text-gray-300 px-3 py-2 text-gray-600 w-full bg-white border border-gray-200 transition-all ease-out duration-150 focus:text-gray-900 rounded-md",ie=d.forwardRef(({className:a,disabled:b,...c},e)=>d.createElement("input",{ref:e,type:"text",className:`${he} ${b?"opacity-50 pointer-events-none cursor-not-allowed":""} ${a}`,...c})),je=d.forwardRef(({...a},b)=>d.createElement("textarea",{...a,className:"shadow-inner text-base px-3 py-2 text-gray-600 resize-y focus:shadow-outline focus:border-blue-500 block w-full border border-gray-200 focus:text-gray-900 rounded-md",ref:b,style:{minHeight:"160px"}}));var ke,le=((ke=le||{}).Hex="hex",ke.RGB="rgb",ke);function me(a){if(!a)return null;const b=(0,x.get)(a);if(!b)return null;const c=b.value;return{r:c[0],g:c[1],b:c[2],a:c[3]}}const ne={["rgb"]:{getLabel(a){return`R${a.r} G${a.g} B${a.b}`},getValue(a){const b=[a.r,a.g,a.b,a.a];return x.to.rgb(b)},parse:me},["hex"]:{getLabel(a){var b;return"#"+(16777216+((b=a).r<<16)+(b.g<<8)+b.b).toString(16).slice(1)},getValue(a){const b=[a.r,a.g,a.b,a.a];return x.to.hex(b)},parse:me}},oe=({colorRGBA:a,colorFormat:b,unselectable:c,...e})=>{var f;return d.createElement("div",{className:"bg-gray-100 rounded-3xl shadow-[0_2px_3px_rgba(0,0,0,0.12)] cursor-pointer w-full m-0",...e},d.createElement("div",{className:"swatch-inner flex items-center justify-center text-[13px] font-bold w-full h-10 rounded-3xl hover:opacity-[.6]",style:{background:a?`rgba(${a.r}, ${a.g}, ${a.b}, ${a.a})`:"#fff",color:(f=a)&&!(.299*f.r+.587*f.g+.114*f.b>186)?"#ffffff":"#000000",transition:"all var(--tina-timing-short) ease-out"}},a?ne[b].getLabel(a):"Click to add color"))},pe=({triggerBoundingBox:a,openTop:b,className:c="",style:e={},...f})=>d.createElement("div",{className:`fixed z-50 before:content-[""] before:absolute before:left-1/2 before:-translate-x-1/2 before:w-[18px] before:h-[14px] before:bg-gray-200 before:z-10 after:content-[""] after:absolute after:left-1/2 after:-translate-x-1/2 after:w-4 after:h-[13px] after:bg-white after:z-20 ${b?"before:bottom-0 before:mt-[1px] before:translate-y-full color-picker-on-top-clip-path after:bottom-0 after:mb-0.5 after:translate-y-full":"before:top-0 before:mb-[1px] before:-translate-y-full color-picker-clip-path after:top-0 after:mt-0.5 after:-translate-y-full"} ${c}`,style:{top:a?b?a.top:a.bottom:0,left:a?a.left+a.width/2:0,transform:b?"translate3d(-50%, calc(-100% - 8px), 0) scale3d(1, 1, 1)":"translate3d(-50%, 8px, 0) scale3d(1, 1, 1)",animation:`${b?"color-popup-open-top-keyframes":"color-popup-keyframes"} 85ms ease-out both 1`,transformOrigin:`50% ${b?"100%":"0"}`,...e},...f}),qe="transparent",re=["#D0021B","#F5A623","#F8E71C","#8B572A","#7ED321","#417505","#BD10E0","#9013FE","#4A90E2","#50E3C2","#B8E986","#000000","#4A4A4A","#9B9B9B","#FFFFFF"],se={sketch:a=>d.createElement(w.SketchPicker,{presetColors:a.presetColors,color:a.color,onChange:a.onChange,disableAlpha:a.disableAlpha,width:a.width}),block:a=>d.createElement(w.BlockPicker,{colors:a.presetColors,color:a.color,onChange:a.onChange,width:a.width})},te=({colorFormat:a,userColors:b=re,widget:c="sketch",input:e})=>{const f=Nc(),g=d.useRef(null),[h,i]=(0,d.useState)(null),[j,k]=(0,d.useState)(!1),l=()=>{g.current&&i(g.current.getBoundingClientRect())};d.useEffect(()=>{if(h){const a=h.top+h.height/2,b=window.innerHeight;a>b/2?k(!0):k(!1)}},[h]),d.useEffect(()=>{let a=!1;setTimeout(()=>{l()},100);const b=()=>{clearTimeout(a),a=setTimeout(l,100)};return window.addEventListener("resize",b),()=>{window.removeEventListener("resize",b)}},[g.current]);const m=se[c];if(!m)throw new Error("You must specify a widget type.");const[n,o]=(0,d.useState)(!1),p=(a||le.Hex).toLowerCase(),q=e.value?ne[p].parse(e.value):null,r=a=>{const b=a.hex===qe?null:{...a.rgb,a:1};e.onChange(b?ne[p].getValue(b):null)},s=a=>{a.stopPropagation();const b=!n;o(b),b&&l()};return d.createElement("div",{className:"relative",ref:g},d.createElement("style",null,"@keyframes color-popup-keyframes {\n  0% {\n    transform: translate3d(-50%, 0, 0) scale3d(0.5, 0.5, 1);\n  }\n  100% {\n    transform: translate3d(-50%, 8px, 0) scale3d(1, 1, 1);\n  }\n}\n\n@keyframes color-popup-open-top-keyframes {\n  0% {\n    transform: translate3d(-50%, -100%, 0) scale3d(0.5, 0.5, 1);\n  }\n  100% {\n    transform: translate3d(-50%, calc(-100% - 8px), 0) scale3d(1, 1, 1);\n  }\n}\n\n.color-picker-clip-path::before,\n.color-picker-clip-path::after {\n  clip-path: polygon(50% 0%, 0% 100%, 100% 100%);\n}\n\n.color-picker-on-top-clip-path::before,\n.color-picker-on-top-clip-path::after {\n  clip-path: polygon(0% 0%, 100% 0%, 50% 100%);\n}\n"),d.createElement(oe,{onClick:s,colorRGBA:q,colorFormat:p}),n&&d.createElement(f,null,({zIndexShift:a})=>d.createElement(pe,{openTop:j,triggerBoundingBox:h,style:{zIndex:5e3+a}},d.createElement(Rc,{click:!0,escape:!0,disabled:!n,onDismiss:s},d.createElement(m,{presetColors:[...b,qe],color:q||{r:0,g:0,b:0,a:0},onChange:r,disableAlpha:!0,width:"240px"})))))},ue=({input:a,field:b,name:c,disabled:e=!1})=>{const f=!!(a.value||a.checked);let g=null;if(b.toggleLabels){const h="object"==typeof b.toggleLabels&&"true"in b.toggleLabels&&"false"in b.toggleLabels&&b.toggleLabels;g={true:h?h.true:"Yes",false:h?h.false:"No"}}return d.createElement("div",{className:"flex gap-2 items-center"},g&&d.createElement("span",{className:`text-sm ${f?"text-gray-300":"text-blue-500 font-bold"}`},g.false),d.createElement("div",{className:"relative w-12 h-7"},d.createElement(ve,{id:c,type:"checkbox",...a}),d.createElement("label",{className:"bg-none p-0 outline-none w-12 h-7",style:{opacity:e?.4:1,pointerEvents:e?"none":"inherit"},htmlFor:c,role:"switch"},d.createElement("div",{className:"relative w-[48px] h-7 rounded-3xl bg-white shadow-inner border border-gray-200 pointer-events-none -ml-0.5"},d.createElement("span",{className:`absolute rounded-3xl left-0.5 top-1/2 w-[22px] h-[22px] shadow border transition-all ease-out duration-150 ${f?"bg-blue-500 border-blue-600":"bg-gray-250 border-gray-300"}`,style:{transform:`translate3d(${f?"20px":"0"}, -50%, 0)`}})))),g&&d.createElement("span",{className:`text-sm ${f?"text-blue-500 font-bold":"text-gray-300"}`},g.true))},ve=({disabled:a,...b})=>d.createElement("input",{className:`absolute left-0 top-0 w-12 h-8 opacity-0 m-0 ${a?"cursor-not-allowed pointer-events-none":"cursor-pointer z-20"}`,...b});function we(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{fill:"none",d:"M0 0h24v24H0V0z"}},{tag:"path",attr:{d:"M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"}}]})(a)}function xe(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{fill:"none",d:"M0 0h24v24H0z"}},{tag:"path",attr:{d:"M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"}}]})(a)}function ye(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{fill:"none",d:"M0 0h24v24H0z"}},{tag:"path",attr:{d:"M3 12c0 2.21.91 4.2 2.36 5.64L3 20h6v-6l-2.24 2.24A6.003 6.003 0 015 12a5.99 5.99 0 014-5.65V4.26C5.55 5.15 3 8.27 3 12zm8 5h2v-2h-2v2zM21 4h-6v6l2.24-2.24A6.003 6.003 0 0119 12a5.99 5.99 0 01-4 5.65v2.09c3.45-.89 6-4.01 6-7.74 0-2.21-.91-4.2-2.36-5.64L21 4zm-10 9h2V7h-2v6z"}}]})(a)}function ze(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{fill:"none",d:"M0 0h24v24H0V0z"}},{tag:"path",attr:{d:"M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"}}]})(a)}function Ae(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{fill:"none",d:"M0 0h24v24H0V0z"}},{tag:"path",attr:{d:"M12 6c2.62 0 4.88 1.86 5.39 4.43l.3 1.5 1.53.11A2.98 2.98 0 0122 15c0 1.65-1.35 3-3 3H6c-2.21 0-4-1.79-4-4 0-2.05 1.53-3.76 3.56-3.97l1.07-.11.5-.95A5.469 5.469 0 0112 6m0-2C9.11 4 6.6 5.64 5.35 8.04A5.994 5.994 0 000 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96A7.49 7.49 0 0012 4z"}}]})(a)}function Be(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{fill:"none",d:"M0 0h24v24H0V0z",opacity:".87"}},{tag:"path",attr:{d:"M17.51 3.87L15.73 2.1 5.84 12l9.9 9.9 1.77-1.77L9.38 12l8.13-8.13z"}}]})(a)}const Ce="shadow appearance-none bg-white block pl-3 pr-8 py-2 truncate w-full text-base cursor-pointer border border-gray-200 focus:outline-none focus:shadow-outline focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md",De=({input:a,field:b,options:c})=>{const e=c||b.options,f=d.useRef(null);return d.useEffect(()=>{f.current&&(null==b?void 0:b.experimental_focusIntent)&&f.current.focus()},[null==b?void 0:b.experimental_focusIntent,f]),d.createElement("div",{className:"relative group"},d.createElement("select",{id:a.name,ref:f,value:a.value,onChange:a.onChange,className:`${Ce} ${a.value?"text-gray-700":"text-gray-300"} }`,...a},e?e.map(Ee).map(Fe):d.createElement("option",null,a.value)),d.createElement(we,{className:"absolute top-1/2 right-2 w-6 h-auto -translate-y-1/2 text-gray-300 group-hover:text-blue-500 transition duration-150 ease-out pointer-events-none"}))};function Ee(a){return"object"==typeof a?a:{value:a,label:a}}function Fe(a){return d.createElement("option",{key:a.value,value:a.value},a.label)}const Ge=({input:a,field:b,options:c})=>{const e=c||b.options,f={};return d.createElement(He,{id:a.name,direction:b.direction},e?e.map(a=>"object"==typeof a?a:{value:a,label:a}).map(c=>{const e=`field-${b.name}-option-${c.value}`,g=c.value===a.value;return d.createElement("div",{key:c.value,ref:a=>{f[`radio_${c.value}`]=a}},d.createElement("input",{className:"absolute w-0 h-0 opacity-0 cursor-pointer",type:"radio",id:e,name:a.name,value:c.value,onChange:b=>{a.onChange(b.target.value)},checked:g}),d.createElement(Ie,{htmlFor:e,checked:g},c.label))}):a.value)},He=({direction:a,children:b,...c})=>d.createElement("div",{className:`flex w-full ${"horizontal"===a?"flex-wrap gap-y-1 gap-x-3":"flex-col gap-1"}`,...c},b),Ie=({checked:a,htmlFor:b,children:c,...e})=>d.createElement("label",{className:"cursor-pointer flex group items-center gap-2",htmlFor:b,...e},d.createElement("span",{className:`relative h-[19px] w-[19px] rounded-full border text-indigo-600 focus:ring-indigo-500 transition ease-out duration-150 ${a?"border-blue-500 bg-blue-500 shadow-sm group-hover:bg-blue-400 group-hover:border-blue-400":"border-gray-200 bg-white shadow-inner group-hover:bg-gray-100"}`},d.createElement(nd,{className:`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[17px] h-[17px] transition ease-out duration-150 ${a?"opacity-100 text-white group-hover:opacity-80":"text-blue-500 opacity-0 grou-hover:opacity-30"}`})),d.createElement("span",{className:`relative transition ease-out duration-150 ${a?"text-gray-800 opacity-100":"text-gray-700 opacity-70 group-hover:opacity-100"}`},c)),Je=({input:a,field:b,options:c,disabled:e=!1})=>{const f=c||b.options;return d.createElement("div",{className:`flex w-full ${"horizontal"===b.direction?"flex-wrap gap-y-1 gap-x-3":"flex-col gap-1"}`,id:a.name},null==f?void 0:f.map(a=>"object"==typeof a?a:{value:a,label:a}).map(c=>{const f=`field-${b.name}-option-${c.value}`,g=!!a.value&&a.value.includes(c.value);return d.createElement("div",{key:c.value},d.createElement("input",{className:"absolute w-0 h-0 opacity-0 cursor-pointer",type:"checkbox",name:a.name,id:f,value:c.value,checked:g,disabled:e,onChange:b=>{!0===b.target.checked?a.onChange([...a.value,b.target.value]):a.onChange([...a.value.filter(a=>a!==b.target.value)])}}),d.createElement("label",{className:"cursor-pointer flex group items-center gap-2",htmlFor:f},d.createElement("span",{className:`relative h-[18px] w-[18px] rounded border text-indigo-600 focus:ring-indigo-500 transition ease-out duration-150 ${g?"border-blue-500 bg-blue-500 shadow-sm group-hover:bg-blue-400 group-hover:border-blue-400":"border-gray-200 bg-white shadow-inner group-hover:bg-gray-100"}`},d.createElement(nd,{className:`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[17px] h-[17px] transition ease-out duration-150 ${g?"opacity-100 text-white group-hover:opacity-80":"text-blue-500 opacity-0 grou-hover:opacity-30"}`})),d.createElement("span",{className:`relative transition ease-out duration-150 ${g?"text-gray-800 opacity-100":"text-gray-700 opacity-70 group-hover:opacity-100"}`},c.label)))}))},Ke=({...a})=>d.createElement("input",{className:he,...a}),Le=({onChange:a,value:b,step:c})=>d.createElement(Ke,{type:"number",step:c,value:b,onChange:a});function Me(){return Ta()}const Ne="text/*,application/pdf,application/octet-stream,application/json,application/ld+json,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/*",Oe=a=>Object.assign({},...(a||Ne).split(",").map(a=>({[a]:[]}))),Pe=a=>/\.(gif|jpg|jpeg|tiff|png|svg|webp|avif)(\?.*)?$/i.test(a),Qe=a=>a.startsWith("http")?a:`${window.location.origin}${a}`,Re=({src:a})=>{const b=/\.svg$/.test(a);return d.createElement("img",{src:a,className:`"block max-w-full rounded shadow overflow-hidden max-h-48 h-auto object-contain transition-opacity duration-100 ease-out m-0 bg-gray-200 bg-auto bg-center bg-no-repeat ${b?"min-w-[12rem]":""}`})},Se=({src:a})=>d.createElement("div",{className:"max-w-full w-full overflow-hidden flex-1 flex justify-start items-center gap-3"},d.createElement("div",{className:"w-14 h-14 bg-gray-50 shadow border border-gray-100 rounded flex justify-center flex-none"},d.createElement(wd,{className:"w-3/5 h-full fill-gray-300"})),d.createElement("span",{className:"text-base text-left flex-1 text-gray-500 w-full break-words truncate"},a)),Te=d.forwardRef(({onDrop:a,onClear:b,onClick:c,value:e,src:f,loading:g},h)=>{const i=Me(),{getRootProps:j,getInputProps:k}=(0,y.useDropzone)({accept:Oe(i.media.accept||Ne),onDrop:a,noClick:!!c});return d.createElement("div",{className:"w-full max-w-full",...j()},d.createElement("input",{...k()}),e?g?d.createElement(Ve,null):d.createElement("div",{className:`relative w-full max-w-full flex justify-start gap-3 ${Pe(f)?"items-start":"items-center"}`},d.createElement("button",{className:"shadow-inner focus-within:shadow-outline focus-within:border-blue-500 outline-none overflow-visible cursor-pointer border-none hover:opacity-60 transition ease-out duration-100",onClick:c,ref:h},Pe(f)?d.createElement(Re,{src:f}):d.createElement(Se,{src:f})),b&&d.createElement(Ue,{onClick:a=>{a.stopPropagation(),b()}})):d.createElement("button",{className:"outline-none relative hover:opacity-60 w-full",onClick:c},g?d.createElement(Ve,null):d.createElement("div",{className:"text-center rounded-[5px] bg-gray-100 text-gray-300 leading-[1.35] py-3 text-[15px] font-normal transition-all ease-out duration-100 hover:opacity-60"},"Drag 'n' drop a file here,",d.createElement("br",null),"or click to select a file")))}),Ue=({onClick:a})=>d.createElement(Gc,{variant:"white",className:"flex-none",onClick:a},d.createElement(oa,{className:"w-7 h-auto"})),Ve=()=>d.createElement("div",{className:"p-4 w-full min-h-[96px] flex flex-col justify-center items-center"},d.createElement(Kc,null)),We=(a,b)=>{const[c,e]=d.useState([]),[f,g]=d.useState(!0);return d.useEffect(()=>{const c=async()=>{const c=await Promise.all(b.map(async b=>{try{const c=await a.api.tina.request(`#graphql
            query ($collection: String!){
              collection(collection: $collection) {
                documents(first: -1) {
                  edges {
                    node {
                      ...on Node {
                        id,
                      }
                      ...on Document {
                        _internalSys: _sys {
                          title
                        }
                      }
                    }
                  }
                }
              }
            }
            `,{variables:{collection:b}});return{collection:b,edges:c.collection.documents.edges}}catch(d){return{collection:b,edges:[]}}}));e(c),g(!1)};a&&b.length>0?c():e([])},[a,b]),{optionSets:c,loading:f}},Xe=({cms:a,input:b,field:c})=>{const{optionSets:e,loading:f}=We(a,c.collections),g=d.useRef(null);return(d.useEffect(()=>{g.current&&c.experimental_focusIntent&&g.current.focus()},[c.experimental_focusIntent,g]),!0===f)?d.createElement(Kc,{color:"var(--tina-color-primary)"}):d.createElement(d.Fragment,null,d.createElement("select",{ref:g,id:b.name,value:b.value,onChange:b.onChange,className:Ce,...b},d.createElement("option",{value:""},"Choose an option"),e.length>0&&e.map(({collection:a,edges:b})=>d.createElement("optgroup",{key:`${a}-group`,label:a},b.map(({node:{id:a,_internalSys:{title:b}}})=>d.createElement("option",{key:`${a}-option`,value:a},b||a))))),d.createElement(we,{className:"absolute top-1/2 right-3 w-6 h-auto -translate-y-1/2 text-gray-300 group-hover:text-blue-500 transition duration-150 ease-out"}))},Ye=(a,b)=>{const[c,e]=d.useState(void 0);return d.useEffect(()=>{const c=async()=>{const c=await a.api.tina.request(`#graphql
        query($id: String!) {
          node(id:$id) {
            ... on Document {
              _sys {
                collection {
                  name
                }
                breadcrumbs
              }
            }
          }
        }`,{variables:{id:b}});e(c.node)};a&&b?c():e(void 0)},[a,b]),c},Ze=({cms:a,id:b,children:c})=>{const e=Ye(a,b);return e?d.createElement(d.Fragment,null,c(e)):null},$e=({cms:a,input:b})=>{const c=!1!==a.flags.get("tina-admin"),e=a.flags.get("tina-preview")||!1;return c?d.createElement(Ze,{cms:a,id:b.value},c=>"visual"===a.state.editingMode?d.createElement("button",{type:"button",onClick:()=>{a.dispatch({type:"forms:set-active-form-id",value:b.value})},className:"text-gray-700 hover:text-blue-500 flex items-center uppercase text-sm mt-2 mb-2 leading-none"},d.createElement(sd,{className:"h-5 w-auto opacity-80 mr-2"}),"Edit"):d.createElement("a",{href:`${e?`/${e}/index.html#`:"/admin#"}/collections/${c._sys.collection.name}/${c._sys.breadcrumbs.join("/")}`,className:"text-gray-700 hover:text-blue-500 flex items-center uppercase text-sm mt-2 mb-2 leading-none"},d.createElement(sd,{className:"h-5 w-auto opacity-80 mr-2"}),"Edit in CMS")):null},_e=({input:a,field:b})=>{const c=Me();return d.createElement("div",null,d.createElement("div",{className:"relative group"},d.createElement(Xe,{cms:c,input:a,field:b})),d.createElement($e,{cms:c,input:a}))},af=({input:a,field:b,options:c})=>{const e=c||b.options,f=b.direction||"horizontal";return d.createElement(d.Fragment,null,d.createElement("input",{type:"text",id:a.name,className:"hidden",...a}),d.createElement("div",{className:`flex ${"horizontal"===f?"divide-x":"flex-col divide-y"} divide-gray-150 shadow-inner bg-gray-50 border border-gray-200 w-full justify-between rounded-md`},e?e.map(b=>{const c=cf(b);return c.icon?d.createElement(bf,{key:c.value,input:a,value:c.value,icon:c.icon}):d.createElement(bf,{key:c.value,input:a,value:c.value,label:c.label})}):a.value))},bf=({input:a,value:b,label:c="",icon:e,...f})=>{const g=e;return d.createElement("button",{className:"relative whitespace-nowrap flex items-center justify-center flex-1 block font-medium text-base px-3 py-2 text-gray-400 transition-all ease-out duration-150",onClick:()=>{a.onChange(b)},...f},g?d.createElement(g,{className:"w-6 h-auto opacity-70"}):d.createElement("span",{className:"flex-1 truncate max-w-full w-0"},c),d.createElement("span",{className:`absolute whitespace-nowrap px-3 py-2 z-20 font-medium text-base flex items-center justify-center -top-0.5 -right-0.5 -bottom-0.5 -left-0.5 truncate bg-white border border-gray-200 origin-center rounded-md shadow text-blue-500 transition-all ease-out duration-150 ${a.value===b?"opacity-100":"opacity-0"}`},g?d.createElement(g,{className:"w-6 h-auto opacity-70"}):d.createElement("span",{className:"flex-1 truncate max-w-full w-0"},c)))};function cf(a){return"object"==typeof a?a:{value:a,label:a}}const df=({attributes:a,children:b,element:c,editor:e,onChange:g})=>{const i=(0,h.useSelected)(),{handleClose:j,handleRemove:k,handleSelect:l,isExpanded:m}=Wd(e,c);return Vd("enter",()=>{(0,f.insertNodes)(e,[{type:f.ELEMENT_PARAGRAPH,children:[{text:""}]}])}),d.createElement("span",{...a,className:""},b,d.createElement("span",{className:"relative"},d.createElement("span",{className:"relative inline-flex shadow-sm rounded-md"},i&&d.createElement("span",{className:"z-10 absolute inset-0 ring-2 ring-blue-100 ring-inset rounded-md pointer-events-none"}),d.createElement("div",{className:"z-10"},d.createElement(Ue,{onClick:a=>{a.stopPropagation(),k()}})),d.createElement("span",{onMouseDown:l,className:"min-w-[200px] max-w-[400px] cursor-pointer rounded-md relative bg-gray-100 overflow-hidden relative"},c.url?d.createElement("img",{src:c.url,title:c.caption,alt:c.alt,className:"my-0 min-h-[100px]"}):d.createElement("span",{className:"min-h-[100px] min-w-[200px] flex items-center justify-center text-gray-300"},d.createElement("span",null,"Click to add an image")))),m&&d.createElement(ef,{onChange:g,initialValues:c,onClose:j,element:c})))},ef=a=>d.createElement(Sd,{id:"image-form",label:"Image",fields:[{label:"URL",name:"url",component:"image",clearable:!0},{label:"Caption",name:"caption",component:"text"},{label:"Alt",name:"alt",component:"text"}],initialValues:a.initialValues,onChange:a.onChange,onClose:a.onClose}),ff=(0,f.createPluginFactory)({key:"img",isVoid:!0,isInline:!0,isElement:!0,component:a=>d.createElement(df,{...a,onChange:b=>{const c=h.ReactEditor.findPath(a.editor,a.element);(0,f.setNodes)(a.editor,b,{at:c})}})}),gf=(a,b)=>{Pe(b.src)?xf(a,{type:"img",children:[{text:""}],url:b.src,caption:"",alt:""}):xf(a,{type:"a",url:b.src,title:b.filename,children:[{text:b.filename}]}),(0,f.normalizeEditor)(a,{force:!0})},hf="break",jf=(0,f.createPluginFactory)({key:hf,isElement:!0,isInline:!0,isVoid:!0,component:a=>d.createElement(d.Fragment,null,d.createElement("br",{className:a.className,...a.attributes}),a.children),handlers:{onKeyDown:(a,{options:{rules:b=[]}})=>c=>{const d=(0,f.getBlockAbove)(a);d&&b.forEach(({hotkey:b,query:e})=>{(0,v.default)(b,c)&&(0,f.queryNode)(d,e)&&(c.preventDefault(),c.stopPropagation(),(0,f.insertNodes)(a,[{type:hf,children:[{text:""}]},{type:"text",text:""}],{select:!0}))})}},options:{rules:[{hotkey:"shift+enter"}]}}),kf=a=>(0,f.unwrapList)(a),lf=(a,b)=>{if(a.selection){const c=(0,f.getParentNode)(a,a.selection);if(!c)return;const[d]=c;!(0,f.isElement)(d)||(0,f.isType)(a,d,f.ELEMENT_CODE_BLOCK)||(0,f.isType)(a,d,f.ELEMENT_CODE_LINE)||b()}},mf=(a,b)=>{lf(a,()=>(0,f.toggleList)(a,{type:b}))},nf=a=>{if((0,f.someNode)(a,{match:b=>b.type===(0,f.getPluginType)(a,f.ELEMENT_CODE_BLOCK)}))return;const b={type:f.ELEMENT_CODE_BLOCK,value:"",lang:"javascript",children:[{type:"text",text:""}]};(0,f.isSelectionAtBlockStart)(a)?(0,f.setElements)(a,b):(0,f.insertNode)(a,b)},of=[{mode:"block",type:f.ELEMENT_H1,match:"# ",preFormat:kf},{mode:"block",type:f.ELEMENT_H2,match:"## ",preFormat:kf},{mode:"block",type:f.ELEMENT_H3,match:"### ",preFormat:kf},{mode:"block",type:f.ELEMENT_H4,match:"#### ",preFormat:kf},{mode:"block",type:f.ELEMENT_H5,match:"##### ",preFormat:kf},{mode:"block",type:f.ELEMENT_H6,match:"###### ",preFormat:kf},{mode:"block",type:f.ELEMENT_BLOCKQUOTE,match:"> ",preFormat:kf},{mode:"block",type:f.ELEMENT_CODE_BLOCK,match:"```",triggerAtBlockStart:!1,preFormat:kf,format:a=>{nf(a)}},{mode:"block",type:f.ELEMENT_HR,match:["---","—-","___ "],format:a=>{(0,f.setNodes)(a,{type:f.ELEMENT_HR}),(0,f.insertNodes)(a,{type:f.ELEMENT_DEFAULT,children:[{text:""}]})}}],pf=[{mode:"block",type:f.ELEMENT_LI,match:["* ","- "],preFormat:kf,format:a=>mf(a,f.ELEMENT_UL)},{mode:"block",type:f.ELEMENT_LI,match:["1. ","1) "],preFormat:kf,format:a=>mf(a,f.ELEMENT_OL)},{mode:"block",type:f.ELEMENT_TODO_LI,match:"[] "},{mode:"block",type:f.ELEMENT_TODO_LI,match:"[x] ",format:a=>(0,f.setNodes)(a,{type:f.ELEMENT_TODO_LI,checked:!0},{match:b=>(0,f.isBlock)(a,b)})}],qf=[{mode:"mark",type:[f.MARK_BOLD,f.MARK_ITALIC],match:"***"},{mode:"mark",type:f.MARK_BOLD,match:"**"},{mode:"mark",type:f.MARK_ITALIC,match:"*"},{mode:"mark",type:f.MARK_ITALIC,match:"_"},{mode:"mark",type:f.MARK_CODE,match:"`"}],rf=[f.ELEMENT_H1,f.ELEMENT_H2,f.ELEMENT_H3,f.ELEMENT_H3,f.ELEMENT_H4,f.ELEMENT_H5,f.ELEMENT_H6,f.ELEMENT_PARAGRAPH],sf={types:[f.ELEMENT_BLOCKQUOTE,f.ELEMENT_H1,f.ELEMENT_H2,f.ELEMENT_H3,f.ELEMENT_H3,f.ELEMENT_H4,f.ELEMENT_H5,f.ELEMENT_H6],defaultType:f.ELEMENT_PARAGRAPH},tf=(0,f.createPluginFactory)({key:"WITH_CORRECT_NODE_BEHAVIOR",withOverrides:a=>{const{deleteBackward:b,insertBreak:c}=a;return a.insertBreak=()=>{if(!a.selection||!n.Range.isCollapsed(a.selection))return c();const b=n.Path.parent(a.selection.anchor.path),d=n.Node.get(a,b);if(n.Editor.isVoid(a,d)){n.Editor.insertNode(a,{type:"p",children:[{text:""}]});return}c()},a.deleteBackward=c=>{if(!a.selection||!n.Range.isCollapsed(a.selection)||0!==a.selection.anchor.offset)return b(c);const d=n.Path.parent(a.selection.anchor.path),e=n.Node.get(a,d),f=0===n.Node.string(e).length;if(f&&n.Path.hasPrevious(d)){const g=n.Path.previous(d),h=n.Node.get(a,g);if(n.Editor.isVoid(a,h)){n.Transforms.removeNodes(a),n.Editor.normalize(a,{force:!0});return}}b(c)},a}}),uf=[(0,f.createTrailingBlockPlugin)(),tf(),(0,f.createAutoformatPlugin)({options:{rules:[...of,...pf,...qf]}}),(0,f.createExitBreakPlugin)({options:{rules:[{hotkey:"mod+enter"},{hotkey:"mod+shift+enter",before:!0},{hotkey:"enter",query:{start:!0,end:!0,allow:f.KEYS_HEADING}}]}}),(0,f.createResetNodePlugin)({options:{rules:[{...sf,hotkey:"Enter",predicate:f.isBlockAboveEmpty},{...sf,hotkey:"Backspace",predicate:f.isSelectionAtBlockStart}]}}),jf({options:{rules:[{hotkey:"shift+enter"},{hotkey:"enter",query:{allow:[f.ELEMENT_CODE_BLOCK,f.ELEMENT_BLOCKQUOTE]}}]}})],vf=[(0,f.createHeadingPlugin)(),(0,f.createParagraphPlugin)(),ee(),fe(),ge(),(0,f.createBlockquotePlugin)(),(0,f.createBoldPlugin)(),(0,f.createItalicPlugin)(),(0,f.createUnderlinePlugin)(),(0,f.createCodePlugin)(),(0,f.createListPlugin)(),(0,f.createHorizontalRulePlugin)(),(0,f.createNodeIdPlugin)()],wf=a=>[Cf,Bf,"img"].includes(a.type)?{...a,children:[{type:"text",text:""}],id:Date.now()}:a.children?a.children.length?{...a,children:a.children.map(wf),id:Date.now()}:{...a,children:[{text:""}],id:Date.now()}:a,xf=(a,b)=>{(0,f.insertNodes)(a,[b]),setTimeout(()=>{n.Transforms.move(a)},1)},yf=(a,b)=>{const c=h.ReactEditor.toDOMNode(a,a);c&&(c.focus(),setTimeout(()=>{zf(a)?(0,f.setNodes)(a,b):(0,f.insertNodes)(a,[b])},1))},zf=a=>{var b;if(!a.selection)return!1;const[c]=n.Editor.node(a,a.selection),d=a.selection.focus,e=(0,f.getBlockAbove)(a),g=!n.Node.string(c)&&!(null==(b=c.children)?void 0:b.some(b=>n.Editor.isInline(a,b)))&&n.Editor.isStart(a,d,e[1]);return g},Af={isNodeActive:(a,b)=>{const c=(0,f.getPluginType)(a,b);return!!(null==a?void 0:a.selection)&&(0,f.someNode)(a,{match:{type:c}})},isMarkActive:(a,b)=>!!(null==a?void 0:a.selection)&&(0,f.isMarkActive)(a,b),isListActive:(a,b)=>{const c=!!(null==a?void 0:a.selection)&&(0,f.getListItemEntry)(a);return!!c&&c.list[0].type===b},currentNodeSupportsMDX:a=>(0,f.findNode)(a,{match:{type:rf}}),normalize:wf},Bf="mdxJsxTextElement",Cf="mdxJsxFlowElement",Df=a=>{const b=b=>{const c=h.ReactEditor.findPath(a.editor,a.element);(0,f.setNodes)(a.editor,{props:b},{at:c})};return a.inline?d.createElement(_d,{...a,onChange:b}):d.createElement(ae,{...a,onChange:b})},Ef=(0,f.createPluginFactory)({key:Bf,isInline:!0,isVoid:!0,isElement:!0,component:a=>d.createElement(Df,{...a,inline:!0})}),Ff=(0,f.createPluginFactory)({key:Cf,isVoid:!0,isElement:!0,component:a=>d.createElement(Df,{...a,inline:!1})}),Gf=(a,b)=>{const c=!b.inline;Af.currentNodeSupportsMDX(a)&&(c?(yf(a,{type:Cf,name:b.name,children:[{text:""}],props:b.defaultItem?b.defaultItem:{}}),(0,f.normalizeEditor)(a,{force:!0})):xf(a,{type:Bf,name:b.name,children:[{text:""}],props:b.defaultItem?b.defaultItem:{}}))},Hf=a=>{const b={type:"a",url:"",title:"",children:[{text:""}]};if((0,f.isCollapsed)(a.selection)){const[,c]=(0,f.getAboveNode)(a,{match:b=>!n.Editor.isEditor(b)&&n.Element.isElement(b)&&(0,f.getPluginType)(a,f.ELEMENT_LINK)});n.Transforms.select(a,c)}if(Jf(a)){const[d]=Lf(a);b.url=d[0].url,b.title=d[0].title,Kf(a)}(0,f.wrapNodes)(a,b,{split:!0})},If=a=>{const b=(0,f.useEditorState)(),c=d.useMemo(()=>b.selection,[]),[e]=Lf(b);return d.createElement(Sd,{id:"link-form",label:"Link",fields:[{label:"URL",name:"url",component:"text"},{label:"Title",name:"title",component:"text"}],initialValues:{url:e?e[0].url:"",title:e?e[0].title:""},onChange:a=>{const d=(0,f.getNodeEntries)(b,{match:a=>!n.Editor.isEditor(a)&&n.Element.isElement(a)&&a.type===f.ELEMENT_LINK,at:c});if(d)for(const[,e]of d)(0,f.setNodes)(b,a,{match:a=>!n.Editor.isEditor(a)&&n.Element.isElement(a)&&a.type===f.ELEMENT_LINK,at:e})},onClose:a.onClose})},Jf=a=>{const[b]=Lf(a);return!!b},Kf=(a,b)=>{(0,f.unwrapNodes)(a,{match:a=>!n.Editor.isEditor(a)&&n.Element.isElement(a)&&a.type===f.ELEMENT_LINK,at:b||void 0})},Lf=a=>(0,f.getNodeEntries)(a,{match:a=>!n.Editor.isEditor(a)&&n.Element.isElement(a)&&a.type===f.ELEMENT_LINK}),Mf=({hidden:a,label:b,active:c,onMouseDown:e,icon:g,options:h,name:i,isLastItem:l=!1})=>{const m=(0,f.useEditorState)(),[n,o]=d.useState(null),p=Ta();d.useEffect(()=>{m.selection&&o(m.selection)},[JSON.stringify(m.selection)]);const[q,r]=d.useState(!1);if(h)return d.createElement(k.J,{as:"div",className:"relative z-10 w-full"},d.createElement(k.J.Button,{as:"span",className:`cursor-pointer w-full inline-flex justify-center items-center px-2 py-2 rounded-l-md border-l border-b border-t border-gray-200 bg-white text-sm font-medium text-gray-600 hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${l?"border-r rounded-r-md":"border-r-0"}`,onMouseDown:a=>{a.preventDefault()}},d.createElement("span",{className:"sr-only"},"Open options"),d.createElement(qb,null)),d.createElement(j.u,{as:d.Fragment,enter:"transition ease-out duration-100",enterFrom:"transform opacity-0 scale-95",enterTo:"transform opacity-100 scale-100",leave:"transition ease-in duration-75",leaveFrom:"transform opacity-100 scale-100",leaveTo:"transform opacity-0 scale-95"},d.createElement(k.J.Panel,null,({close:a})=>d.createElement("div",{className:"origin-top-left absolute left-0 mt-2 -mr-1 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none"},d.createElement("div",{className:"py-2 tina-prose"},d.createElement("span",{onMouseDown:()=>a()},h))))));if("image"===g)return d.createElement("span",{className:"relative"},d.createElement("span",{"data-test":`${i}Button`,className:`cursor-pointer w-full inline-flex relative justify-center items-center px-2 py-2 border-l border-b border-t border-r-0 border-gray-200 text-sm font-medium  hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${c?"bg-gray-50 text-blue-500":"bg-white text-gray-600"} ${l?"border-r rounded-r-md":"border-r-0"}`,style:{visibility:a?"hidden":"visible",pointerEvents:a?"none":"auto"},onMouseDown:a=>{a.preventDefault(),p.media.open({allowDelete:!0,directory:"",onSelect:a=>{gf(m,a)}})}},d.createElement("span",{className:"sr-only"},b),d.createElement(ob,{name:g})));if("link"===g){const s=!m.selection||(0,f.isCollapsed)(m.selection)&&!Jf(m);return d.createElement("span",{className:"relative"},d.createElement("span",{"data-test":`${i}Button`,className:`cursor-pointer w-full inline-flex relative justify-center items-center px-2 py-2 border-l border-b border-t border-r-0 border-gray-200 text-sm font-medium  hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${c?"bg-gray-50 text-blue-500":s?"bg-gray-50 text-gray-300":"bg-white text-gray-600"} ${l?"border-r rounded-r-md":"border-r-0"}`,style:{visibility:a?"hidden":"visible",pointerEvents:a?"none":"auto"},onMouseDown:a=>{a.preventDefault(),s||(Hf(m),r(a=>!a))}},d.createElement("span",{className:"sr-only"},b),d.createElement(ob,{name:g})),q&&d.createElement(If,{selection:n,onClose:()=>{r(!1)},onChange:a=>console.log(a)}))}return d.createElement("span",{"data-test":`${i}Button`,className:`cursor-pointer w-full inline-flex relative justify-center items-center px-2 py-2 border-l border-b border-t border-r-0 border-gray-200 text-sm font-medium  hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${c?"bg-gray-50 text-blue-500":"bg-white text-gray-600"} ${l?"border-r rounded-r-md":"border-r-0"}`,style:{visibility:a?"hidden":"visible",pointerEvents:a?"none":"auto"},onMouseDown:e},d.createElement("span",{className:"sr-only"},b),d.createElement(ob,{name:g}))},Nf=({editor:a,templates:b})=>d.createElement(k.J,{as:"span",className:"relative z-10 block",style:{width:"85px"}},({open:c})=>d.createElement(d.Fragment,null,d.createElement(k.J.Button,{as:"span",onMouseDown:a=>{a.preventDefault()},className:`cursor-pointer relative inline-flex items-center px-2 py-2 rounded-r-md border text-sm font-medium transition-all ease-out duration-150 focus:z-10 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${c?"bg-gray-50 border-gray-200 text-blue-500":"text-white border-blue-500 bg-blue-500"}`},d.createElement("span",{className:"text-sm font-semibold tracking-wide align-baseline mr-1"},"Embed"),d.createElement(rb,{className:`origin-center transition-all ease-out duration-150 ${c?"rotate-45":""}`})),d.createElement(j.u,{as:d.Fragment,enter:"transition ease-out duration-100",enterFrom:"transform opacity-0 scale-95",enterTo:"transform opacity-100 scale-100",leave:"transition ease-in duration-75",leaveFrom:"transform opacity-100 scale-100",leaveTo:"transform opacity-0 scale-95"},d.createElement(k.J.Panel,null,({close:c})=>d.createElement("div",{className:"origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none max-h-[13rem] overflow-y-auto"},d.createElement("div",{className:"sticky z-10 top-0 w-full h-8 -mb-8 opacity-10 bg-gradient-to-b from-blue-600 to-transparent"}),d.createElement("div",{className:"relative py-1 z-20"},b.map(b=>d.createElement("span",{key:b.name,onMouseDown:d=>{d.preventDefault(),c(),Gf(a,b)},className:"relative z-30 hover:bg-gray-400/10 hover:text-blue-500 cursor-pointer pointer-events-auto px-4 py-2 text-sm w-full flex items-center"},b.label||b.name)),d.createElement("div",{className:"absolute top-0 w-full h-8 bg-gradient-to-b from-white to-transparent"}),d.createElement("div",{className:"absolute bottom-0 w-full h-8 bg-gradient-to-t from-white to-transparent"})),d.createElement("div",{className:"sticky z-10 bottom-0 w-full h-8 -mt-8 opacity-10 bg-gradient-to-t from-blue-600 to-transparent"})))))),Of=({toolbarItems:a,itemsShown:b,showEmbed:c})=>d.createElement(k.J,{as:"span",className:"relative z-10 block w-full"},d.createElement(k.J.Button,{"data-test":"popoverRichTextButton",as:"span",className:`cursor-pointer relative w-full justify-center inline-flex border border-gray-200 focus:border-blue-500 items-center px-2 py-2 bg-white text-sm font-medium text-gray-600 hover:bg-gray-50 focus:z-10 focus:outline-none focus:ring-1 focus:ring-blue-500 pointer-events-auto ${c?"rounded-none":"rounded-r-md"}`,onMouseDown:a=>{a.preventDefault()}},d.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",className:"h-5 w-5",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor"},d.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"}))),d.createElement(j.u,{as:d.Fragment,enter:"transition ease-out duration-100",enterFrom:"transform opacity-0 scale-95",enterTo:"transform opacity-100 scale-100",leave:"transition ease-in duration-75",leaveFrom:"transform opacity-100 scale-100",leaveTo:"transform opacity-0 scale-95"},d.createElement(k.J.Panel,null,({close:c})=>d.createElement("div",{className:"origin-top-right absolute right-0 mt-2 -mr-1 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none py-1"},a.map((a,e)=>e<b-1?null:d.createElement("span",{"data-test":`${a.name}OverflowButton`,key:a.name,onMouseDown:b=>{b.preventDefault(),c(),a.onMouseDown(b)},className:cb(a.active?"bg-gray-50 text-blue-500":"bg-white text-gray-600","hover:bg-gray-50 hover:text-blue-500 cursor-pointer pointer-events-auto px-4 py-2 text-sm w-full flex items-center")},d.createElement("div",{className:"mr-2 opacity-80"},d.createElement(ob,{name:a.name}))," ",a.label)))))),Pf=(a,b)=>{d.useEffect(()=>{const c=new ResizeObserver(a=>{for(const c of a)b(c)});return a.current&&c.observe(a.current),()=>c.disconnect()},[a.current])},Qf=({children:a,position:b})=>{const c=d.useRef(),e=(0,f.useEditorState)(),{selection:g}=e;return d.useEffect(()=>{const a=c.current;if(!a)return;if(!g||!(0,f.isEditorFocused)(e)||n.Range.isCollapsed(g)||""===(0,f.getEditorString)(e,g)){a.classList.add("hidden"),a.classList.remove("block");return}a.classList.add("block"),a.classList.remove("hidden");const d=async()=>{if(c.current){const a=window.getSelection(),d=a.getRangeAt(0),{x:e,y:f}=await (0,z.oo)(d,c.current,{placement:b||"top",middleware:[(0,A.RR)(),(0,A.uY)()]});Object.assign(c.current.style,{left:`${e}px`,top:`${f}px`})}};d()},[JSON.stringify(g),c.current]),d.createElement("div",{ref:c,className:"absolute z-10"},a)},Rf=[{name:f.ELEMENT_H1,render:d.createElement("h1",{className:"my-0 text-4xl font-medium"},"Heading 1")},{name:f.ELEMENT_H2,render:d.createElement("h2",{className:"my-0 text-3xl font-medium"},"Heading 2")},{name:f.ELEMENT_H3,render:d.createElement("h3",{className:"my-0 text-2xl font-semibold"},"Heading 3")},{name:f.ELEMENT_H4,render:d.createElement("h4",{className:"my-0 text-xl font-bold"},"Heading 4")},{name:f.ELEMENT_H5,render:d.createElement("h5",{className:"my-0 text-lg font-bold"},"Heading 5")},{name:f.ELEMENT_H6,render:d.createElement("h6",{className:"my-0 text-base font-bold"},"Heading 6")},{name:f.ELEMENT_PARAGRAPH,render:d.createElement("p",{className:"my-0"},"Paragraph")}];function Sf({templates:a}){const{setRawMode:b}=Yd(),c=a.length>0,e=d.useRef(null),g=(0,f.useEditorState)(),h=Af.isMarkActive(g,f.MARK_BOLD),i=Af.isMarkActive(g,f.MARK_CODE),j=Af.isMarkActive(g,f.MARK_ITALIC),k=Af.isNodeActive(g,f.ELEMENT_LINK),l=Af.isListActive(g,f.ELEMENT_UL),m=Af.isListActive(g,f.ELEMENT_OL),n=Af.isNodeActive(g,f.ELEMENT_CODE_BLOCK),o=Af.isNodeActive(g,f.ELEMENT_BLOCKQUOTE),p=Af.isNodeActive(g,"img"),q=[{name:"heading",label:"Heading",active:!1,options:Rf.map(a=>d.createElement("span",{key:a.name,onMouseDown:(0,f.getPreventDefaultHandler)(f.toggleNodeType,g,{activeType:a.name}),className:cb("hover:bg-gray-100 hover:text-gray-900 cursor-pointer block px-4 py-2 text-sm w-full text-left")},a.render))},{name:"link",label:"Link",active:k},{name:"image",label:"Image",active:p},{name:"quote",label:"Quote",active:o,onMouseDown:(0,f.getPreventDefaultHandler)(f.toggleNodeType,g,{activeType:f.ELEMENT_BLOCKQUOTE})},{name:"ul",label:"Bullet List",active:l,onMouseDown:(0,f.getPreventDefaultHandler)(f.toggleList,g,{type:f.ELEMENT_UL})},{name:"ol",label:"List",active:m,onMouseDown:(0,f.getPreventDefaultHandler)(f.toggleList,g,{type:f.ELEMENT_OL})},{name:"code",label:"Code",active:i,onMouseDown:(0,f.getPreventDefaultHandler)(f.toggleMark,g,{key:f.MARK_CODE})},{name:"codeBlock",label:"Code Block",active:n,onMouseDown:(0,f.getPreventDefaultHandler)(nf,g)},{name:"bold",label:"Bold",active:h,onMouseDown:(0,f.getPreventDefaultHandler)(f.toggleMark,g,{key:f.MARK_BOLD})},{name:"italic",label:"Italic",active:j,onMouseDown:(0,f.getPreventDefaultHandler)(f.toggleMark,g,{key:f.MARK_ITALIC})},{name:"raw",label:"Raw",active:!1,onMouseDown:()=>b(!0)}],[r,s]=d.useState(q.length);return Pf(e,a=>{const b=a.target.getBoundingClientRect().width;s(Math.floor((b-(c?85:0))/40))}),d.createElement("div",{className:"sticky top-1 inline-flex shadow rounded-md mb-2 z-50 max-w-full",style:{width:`${40*q.length+(c?85:0)}px`}},d.createElement("div",{ref:e,className:"grid w-full",style:{gridTemplateColumns:c?"1fr 85px":"1fr"}},d.createElement("div",{className:"grid",style:{gridTemplateColumns:"repeat(auto-fit, minmax(40px, 1fr))",gridTemplateRows:"auto",gridAutoRows:0}},q.map((a,b)=>{const e=b+1===r;return r<q.length&&e?d.createElement(Of,{key:a.name,itemsShown:r,toolbarItems:q,showEmbed:c}):d.createElement(Mf,{key:a.name,name:a.name,hidden:b+1>r,active:a.active,onMouseDown:a.onMouseDown,label:a.label,options:a.options,icon:a.name,isLastItem:e&&!c})})),c&&d.createElement(Nf,{templates:a,editor:g})))}const Tf=()=>{const a=(0,f.useEditorState)(),b=Af.isNodeActive(a,f.ELEMENT_LINK);return d.createElement(Qf,{position:"bottom"},b&&d.createElement("button",{onMouseDown:b=>{b.preventDefault(),Kf(a)},className:"mt-2 cursor-pointer hover:bg-gray-100 border border-gray-200 rounded-md bg-gray-100 text-gray-600 py-1 px-2"},"Clear"))},Uf=a=>({message:a.message,position:a.position&&{endColumn:a.position.end.column,startColumn:a.position.start.column,startLineNumber:a.position.start.line,endLineNumber:a.position.end.line}}),Vf=a=>{if(!a)return"";const b=Uf(a),c=b?`${b.message}${b.position?` at line: ${b.position.startLineNumber}, column: ${b.position.startColumn}`:""}`:null;return c},Wf=(0,f.createPluginFactory)({key:"invalid_markdown",isVoid:!0,isInline:!1,isElement:!0,component:({attributes:a,element:b,children:c})=>d.createElement("div",{...a},d.createElement(Xf,{error:b}),c)});function Xf({error:a}){const b=Vf(a),{setRawMode:c}=Yd();return d.createElement("div",{contentEditable:!1,className:"bg-red-50 sm:rounded-lg"},d.createElement("div",{className:"px-4 py-5 sm:p-6"},d.createElement("h3",{className:"text-lg leading-6 font-medium text-red-800"},"Error parsing markdown"),d.createElement("div",{className:"mt-2 max-w-xl text-sm text-red-800 space-y-4"},d.createElement("p",null,b),d.createElement("p",null,"To fix these errors, edit the content in raw-mode."),d.createElement("button",{onClick:()=>c(!0),className:"rounded-l-md border-r-0 shadow rounded-md bg-white cursor-pointer relative inline-flex items-center px-2 py-2 border border-gray-200 hover:text-white text-sm font-medium transition-all ease-out duration-150 hover:bg-gray-500 focus:z-10 focus:outline-none focus:ring-1 focus:ring-gray-500 focus:border-gray-500"},"Switch to raw-mode"))))}const Yf=a=>{const b=d.useMemo(()=>{var b,c;return(null==(c=null==(b=a.input.value)?void 0:b.children)?void 0:c.length)?a.input.value.children.map(Af.normalize):[{type:"p",children:[{type:"text",text:""}]}]},[]),c=d.useMemo(()=>(0,f.createPlugins)([...uf,...vf,Ff(),Ef(),ff(),Wf(),(0,f.createLinkPlugin)()],{components:mb()}),[]),e=[a.tinaForm.id,a.input.name].join("."),g=d.useMemo(()=>db()+e,[e]),h=d.useRef(null);return d.useEffect(()=>{h.current&&setTimeout(()=>{const b=h.current.querySelector("[role=\"textbox\"]");a.field.experimental_focusIntent&&b&&b&&b.focus()},100)},[a.field.experimental_focusIntent,h]),d.createElement("div",{ref:h,className:"with-toolbar"},d.createElement(f.Plate,{id:g,initialValue:b,plugins:c,onChange:b=>{a.input.onChange({type:"root",children:b})},firstChildren:d.createElement(d.Fragment,null,d.createElement(Sf,{templates:a.field.templates,inlineOnly:!1}),d.createElement(Tf,null))}))},Zf={name:"rich-text",Component:Xa(a=>{const[b,c]=d.useState(!1),[e,f]=d.useState(0);return d.useMemo(()=>{const{reset:b}=a.form;a.form.reset=a=>(f(a=>a+1),b(a))},[]),d.createElement(Xd.Provider,{key:e,value:{templates:a.field.templates,rawMode:b,setRawMode:c}},d.createElement("div",{className:"min-h-[100px] max-w-full tina-prose relative shadow-inner focus-within:shadow-outline focus-within:border-blue-500 block w-full bg-white border border-gray-200 text-gray-600 focus-within:text-gray-900 rounded-md px-3 py-2"},d.createElement(Yf,{...a})))})},$f={name:"rich-text",validate(a){return null!=a&&Array.isArray(a.children)&&a.children[0]&&"invalid_markdown"===a.children[0].type?"Unable to parse rich-text":void 0},Component:Xa(a=>{const[b,c]=d.useState(0);return d.useMemo(()=>{const{reset:b}=a.form;a.form.reset=a=>(c(a=>a+1),b(a))},[]),d.createElement(Xd.Provider,{key:b,value:{templates:a.field.templates,rawMode:a.rawMode,setRawMode:a.setRawMode}},d.createElement("div",{className:"min-h-[100px] max-w-full tina-prose relative shadow-inner focus-within:shadow-outline focus-within:border-blue-500 block w-full bg-white border border-gray-200 text-gray-600 focus-within:text-gray-900 rounded-md px-3 py-2"},a.rawMode?a.rawEditor:d.createElement(Yf,{...a})))})};class _f{constructor(ag,bg){this.__type=ag,this.events=bg,this.__plugins={}}add(cg){const dg=cg;dg.__type||(dg.__type=this.__type),this.__plugins[dg.name]=dg,this.events.dispatch({type:`plugin:add:${this.__type}`})}all(){return Object.keys(this.__plugins).map(a=>this.__plugins[a])}find(eg){return this.__plugins[eg]}remove(fg){const gg="string"==typeof fg?fg:fg.name,hg=this.__plugins[gg];return delete this.__plugins[gg],this.events.dispatch({type:`plugin:remove:${this.__type}`}),hg}subscribe(ig){return this.events.subscribe(`plugin:*:${this.__type}`,ig)}}class jg{constructor(){this.listeners=new Set()}subscribe(kg,lg){let mg;mg="string"==typeof kg?[kg]:kg;const ng=mg.map(a=>new qg(a,lg));return ng.forEach(a=>this.listeners.add(a)),()=>{ng.forEach(a=>this.listeners.delete(a))}}dispatch(og){if(!this.listeners)return;const pg=Array.from(this.listeners.values());pg.forEach(a=>a.handleEvent(og))}}class qg{constructor(rg,sg){this.eventPattern=rg,this.callback=sg}handleEvent(tg){return!!this.watchesEvent(tg)&&(this.callback(tg),!0)}watchesEvent(ug){if("*"===this.eventPattern)return!0;const vg=ug.type.split(":"),wg=this.eventPattern.split(":");let xg=0,yg=!1;for(;!yg&&xg<wg.length;){const zg="*"===wg[xg],Ag=wg[xg]===vg[xg];yg=!(zg||Ag),xg++}return!yg}}const Bg=/<Error>.*<Code>(.+)<\/Code>.*<Message>(.+)<\/Message>.*/;class Cg{constructor(){this.accept="*"}async persist(Dg){return Dg.map(({directory:a,file:b})=>({id:b.name,type:"file",directory:a,filename:b.name}))}async list(){return{items:[],nextOffset:0}}async delete(){}}class Eg{constructor(Fg){this.fetchFunction=(a,b)=>fetch(a,b),this.accept=Ne,this.parse=a=>a.src,this.cms=Fg}setup(){var Gg,Hg,Ig,Jg;if(!this.api){this.api=null==(Hg=null==(Gg=this.cms)?void 0:Gg.api)?void 0:Hg.tina,this.isLocal=!!this.api.isLocalMode;const Kg=new URL(this.api.contentApiUrl);if(this.url=`${Kg.origin}/media`,!this.isLocal)if(null==(Jg=null==(Ig=this.api.options)?void 0:Ig.tinaioConfig)?void 0:Jg.assetsApiUrlOverride){const Lg=new URL(this.api.assetsApiUrl);this.url=`${Lg.origin}/v1/${this.api.clientId}`}else this.url=`${Kg.origin.replace("content","assets")}/v1/${this.api.clientId}`}}async isAuthenticated(){return this.setup(),await this.api.isAuthenticated()}async persist_cloud(Mg){const Ng=[];if(await this.isAuthenticated())for(const Og of Mg){const Pg=`${Og.directory&&"/"!==Og.directory?`${Og.directory}/${Og.file.name}`:Og.file.name}`,Qg=await this.api.fetchWithToken(`${this.url}/upload_url/${Pg}`,{method:"GET"}),{signedUrl:Rg}=await Qg.json();if(!Rg)throw new Error("Unexpected error generating upload url");const Sg=await this.fetchFunction(Rg,{method:"PUT",body:Og.file,headers:{"Content-Type":Og.file.type||"application/octet-stream","Content-Length":String(Og.file.size)}});if(!Sg.ok){const Tg=await Sg.text(),Ug=Bg.exec(Tg);if(console.error(Tg),Ug)throw new Error(`Upload error: '${Ug[2]}'`);throw new Error("Unexpected error uploading media asset")}const Vg=`https://assets.tina.io/${this.api.clientId}/${Pg}`;Ng.push({directory:Og.directory,filename:Og.file.name,id:Og.file.name,type:"file",thumbnails:{"75x75":Vg,"400x400":Vg,"1000x1000":Vg},src:Vg})}return Ng}async persist_local(Wg){var Xg,Yg,Zg,$g,_g,ah,bh,ch,dh;const eh=[],fh=Object.keys((null==(Zg=null==(Yg=null==(Xg=this.cms.api.tina.schema.schema)?void 0:Xg.config)?void 0:Yg.media)?void 0:Zg.tina)||{}).includes("mediaRoot")&&Object.keys((null==(ah=null==(_g=null==($g=this.cms.api.tina.schema.schema)?void 0:$g.config)?void 0:_g.media)?void 0:ah.tina)||{}).includes("publicFolder");let gh=fh?null==(dh=null==(ch=null==(bh=this.cms.api.tina.schema.schema)?void 0:bh.config)?void 0:ch.media)?void 0:dh.tina.mediaRoot:"/";for(const hh of(gh.startsWith("/")||(gh="/"+gh),gh.endsWith("/")||(gh+="/"),Wg)){const{file:ih,directory:jh}=hh;let kh=jh;kh.startsWith("/")&&(kh=kh.substr(1)||""),kh.endsWith("/")&&(kh=kh.substr(0,kh.length-1)||"");const lh=new FormData();lh.append("file",ih),lh.append("directory",jh),lh.append("filename",ih.name);let mh=`${kh?`${kh}/${ih.name}`:ih.name}`;mh.startsWith("/")&&(mh=mh.substr(1));const nh=`${kh?`${gh}${kh}/${ih.name}`:gh+ih.name}`,oh=await this.fetchFunction(`${this.url}/upload/${mh}`,{method:"POST",body:lh});if(200!=oh.status){const ph=await oh.json();throw new Error(ph.message)}const qh=await oh.json();if(null==qh?void 0:qh.success){const rh={type:"file",id:ih.name,filename:ih.name,directory:jh,src:nh,thumbnails:{"75x75":nh,"400x400":nh,"1000x1000":nh}};eh.push(rh)}else throw new Error("Unexpected error uploading media")}return eh}async persist(sh){return(this.setup(),this.isLocal)?this.persist_local(sh):this.persist_cloud(sh)}genThumbnail(th,uh){return this.isLocal?th:`${th}?fit=crop&max-w=${uh.w}&max-h=${uh.h}`}async list(vh){this.setup();let wh;if(this.isLocal){if(404==(wh=await this.fetchFunction(`${this.url}/list/${vh.directory||""}?limit=${vh.limit||20}${vh.offset?`&cursor=${vh.offset}`:""}`)).status)throw Xh;if(wh.status>=500){const{e:xh}=await wh.json(),yh=new Error("Unexpected error");throw console.error(xh),yh}}else if(await this.isAuthenticated()){if(401==(wh=await this.api.fetchWithToken(`${this.url}/list/${vh.directory||""}?limit=${vh.limit||20}${vh.offset?`&cursor=${vh.offset}`:""}`)).status)throw Wh;if(404==wh.status)throw Xh}else throw new Error("Not authenticated");const{cursor:zh,files:Ah,directories:Bh}=await wh.json(),Ch=[];for(const Dh of Ah)Ch.push({directory:vh.directory||"",type:"file",id:Dh.filename,filename:Dh.filename,src:Dh.src,thumbnails:vh.thumbnailSizes.reduce((a,{w:b,h:c})=>(a[`${b}x${c}`]=this.genThumbnail(Dh.src,{w:b,h:c}),a),{})});for(const Eh of Bh)Ch.push({type:"dir",id:Eh,directory:vh.directory||"",filename:Eh});return{items:Ch,nextOffset:zh||0}}async delete(Fh){const Gh=`${Fh.directory?`${Fh.directory}/${Fh.filename}`:Fh.filename}`;if(this.isLocal)await this.fetchFunction(`${this.url}/${Gh}`,{method:"DELETE"});else if(await this.isAuthenticated())await this.api.fetchWithToken(`${this.url}/${Gh}`,{method:"DELETE"});else throw Wh}}class Hh{constructor(Ih,Jh){this.store=Ih,this.events=Jh,this._pageSize=20}get isConfigured(){return!(this.store instanceof Cg)}get pageSize(){return this._pageSize}set pageSize(Kh){this._pageSize=Kh,this.events.dispatch({type:"media:pageSize",pageSize:Kh})}open(Lh={}){this.events.dispatch({type:"media:open",...Lh})}get accept(){return this.store.accept}async persist(Mh){try{this.events.dispatch({type:"media:upload:start",uploaded:Mh});const Nh=await this.store.persist(Mh);return this.events.dispatch({type:"media:upload:success",uploaded:Mh,media:Nh}),Nh}catch(Oh){throw console.error(Oh),this.events.dispatch({type:"media:upload:failure",uploaded:Mh,error:Oh}),Oh}}async delete(Ph){try{this.events.dispatch({type:"media:delete:start",media:Ph}),await this.store.delete(Ph),this.events.dispatch({type:"media:delete:success",media:Ph})}catch(Qh){throw this.events.dispatch({type:"media:delete:failure",media:Ph,error:Qh}),Qh}}async list(Rh){try{this.events.dispatch({type:"media:list:start",...Rh});const Sh=await this.store.list(Rh);return this.events.dispatch({type:"media:list:success",...Rh,media:Sh}),Sh}catch(Th){throw this.events.dispatch({type:"media:list:failure",...Rh,error:Th}),Th}}}class Uh extends Error{constructor(Vh){super(Vh.message),this.ERR_TYPE="MediaListError",this.title=Vh.title,this.docsLink=Vh.docsLink}}const Wh=new Uh({title:"Unauthorized",message:"You don't have access to this resource.",docsLink:"https://tina.io/docs/reference/media/overview"}),Xh=new Uh({title:"Bad Route",message:"The Cloudinary API route is missing or misconfigured.",docsLink:"https://tina.io/docs/reference/media/external/authentication/"});new Uh({title:"An Error Occurred",message:"Something went wrong accessing your media from Tina Cloud.",docsLink:""});const Yh=class{constructor(Zh={}){this._enabled=!1,this.api={},this.unsubscribeHooks={},this.events=new jg(),this.media=new Hh(new Cg(),this.events),this.enable=()=>{this._enabled=!0,this.events.dispatch(Yh.ENABLED)},this.disable=()=>{this._enabled=!1,this.events.dispatch(Yh.DISABLED)},this.toggle=()=>{this.enabled?this.disable():this.enable()},this.plugins=new class{constructor($h){this.events=$h,this.plugins={}}getType(_h){return this.plugins[_h]=this.plugins[_h]||new _f(_h,this.events)}findOrCreateMap(ai){return this.getType(ai)}add(bi){this.findOrCreateMap(bi.__type).add(bi)}remove(ci){this.findOrCreateMap(ci.__type).remove(ci)}all(di){return this.findOrCreateMap(di).all()}}(this.events),this.flags=new class{constructor(ei){this.events=ei,this._flags=new Map()}get(fi){return this._flags.get(fi)}set(gi,hi){this._flags.set(gi,hi),this.events.dispatch({type:"flag:set",key:gi,value:hi})}}(this.events),Zh.media?this.media.store=Zh.media:this.media.store=new Cg(),Zh.mediaOptions&&Zh.mediaOptions.pageSize&&(this.media.pageSize=Zh.mediaOptions.pageSize),Zh.plugins&&Zh.plugins.forEach(a=>this.plugins.add(a)),Zh.apis&&Object.entries(Zh.apis).forEach(([a,b])=>this.registerApi(a,b)),Zh.enabled&&this.enable()}registerApi(ii,ji){if(this.unsubscribeHooks[ii]&&this.unsubscribeHooks[ii](),ji.events instanceof jg){const ki=ji.events.subscribe("*",this.events.dispatch),li=this.events.subscribe("*",a=>ji.events.dispatch(a));this.unsubscribeHooks[ii]=()=>{ki(),li()}}this.api[ii]=ji}get enabled(){return this._enabled}get disabled(){return!this._enabled}};let mi=Yh;mi.ENABLED={type:"cms:enable"},mi.DISABLED={type:"cms:disable"};class ni{constructor(oi,pi={}){this.events=oi,this.map=pi,this.alerts=new Map(),this.mapEventToAlert=a=>{const b=this.map[a.type];if(b){let c;c="function"==typeof b?b:()=>b;const{level:d,message:e,timeout:f}=c(a);this.add(d,e,f)}},this.events.subscribe("*",this.mapEventToAlert)}setMap(qi){this.map={...this.map,...qi}}add(ri,si,ti=3e3){const ui={level:ri,message:si,timeout:ti,id:`${si}|${Date.now()}`};this.alerts.set(ui.id,ui),this.events.dispatch({type:"alerts:add",alert:ui});let vi=null;const wi=()=>{clearTimeout(vi),this.dismiss(ui)};return vi="error"!==ri?setTimeout(wi,ui.timeout):null,wi}dismiss(xi){this.alerts.delete(xi.id),this.events.dispatch({type:"alerts:remove",alert:xi})}subscribe(yi){const zi=this.events.subscribe("alerts",yi);return()=>zi()}get all(){return Array.from(this.alerts.values())}info(Ai,Bi){return this.add("info",Ai,Bi)}success(Ci,Di){return this.add("success",Ci,Di)}warn(Ei,Fi){return this.add("warn",Ei,Fi)}error(Gi,Hi){return this.add("error",Gi,Hi)}}function Ii({Component:a,props:b,...c}){return{__type:"screen",layout:"popup",...c,Component(c){return d.createElement(a,{...c,...b})}}}function Ji(a,b){const c=(0,d.useMemo)(()=>Ii(a),b);lc(c)}const Ki=({screen:a,close:b})=>d.createElement(Li,{name:a.name,close:b,layout:a.layout},d.createElement(a.Component,{close:b})),Li=({children:a,name:b,close:c,layout:e})=>{let f;switch(e){case"popup":f=Qa;break;case"fullscreen":f=Oa;break;default:f=Qa;break}return d.createElement(N,null,d.createElement(f,null,d.createElement(La,{close:c},b),d.createElement(P,{className:"fullscreen"===e?"flex h-full flex-col":""},a)))},Mi=({name:a,label:b,description:c,error:e,margin:f=!0,children:g,actions:h,index:i,tinaForm:j,triggerHoverEvents:k,...l})=>{const{dispatch:m}=Wa("field:hover"),{dispatch:n}=Wa("field:focus"),o={};return k&&(o.onMouseOver=()=>m({id:j.id,fieldName:a}),o.onMouseOut=()=>m({id:null,fieldName:null})),d.createElement($a,{margin:f,...o,onClick:()=>n({id:j.id,fieldName:a}),style:{zIndex:i?1e3-i:void 0},...l},d.createElement(Ni,null,d.createElement(Oi,null,!1!==b&&d.createElement(Pi,null,b||a),c&&d.createElement(ab,{className:"whitespace-nowrap text-ellipsis overflow-hidden"},c)),h&&h),g,e&&"string"==typeof e&&d.createElement(bb,null,e))},Ni=({children:a})=>d.createElement("span",{className:"relative flex gap-2 w-full justify-between items-center mb-2"},a),Oi=({children:a})=>d.createElement("div",{className:"flex-1 truncate"},a),Pi=({children:a})=>d.createElement("span",{className:"m-0 text-xs font-semibold flex-1 text-ellipsis overflow-hidden transition-all ease-out duration-100 text-left"},a),Qi=({className:a="",...b})=>d.createElement("div",{className:`max-h-[initial] relative h-auto rounded-md shadow bg-gray-100 ${a}`,...b}),Ri=({message:a="There are no items"})=>d.createElement("div",{className:"text-center bg-gray-100 text-gray-300 leading-[1.35] py-3 text-[15px] font-normal"},a),Si=({tinaForm:a,field:b,index:c,item:e,label:f,isMin:g,fixedLength:h,...i})=>{const j=Ta();Nc(),d.useState(!1);const k=d.useCallback(()=>{a.mutators.remove(b.name,c)},[a,b,c]),l=f||(b.label||b.name)+" Item",{dispatch:m}=Wa("field:hover"),{dispatch:n}=Wa("field:focus");return d.createElement(u.Draggable,{type:b.name,draggableId:`${b.name}.${c}`,index:c},(e,f)=>d.createElement(d.Fragment,null,d.createElement(Vi,{provider:e,isDragging:f.isDragging,...i},d.createElement(Xi,{isDragging:f.isDragging}),d.createElement(Ti,{onMouseOver:()=>m({id:a.id,fieldName:`${b.name}.${c}`}),onMouseOut:()=>m({id:null,fieldName:null}),onClick:()=>{const d=a.finalForm.getState();if(!0===d.invalid){j.alerts.error("Cannot navigate away from an invalid form.");return}j.dispatch({type:"forms:set-active-field-name",value:{formId:a.id,fieldName:`${b.name}.${c}`}}),n({id:a.id,fieldName:`${b.name}.${c}`})}},d.createElement(Ui,null,l),d.createElement(Fd,{className:"h-5 w-auto fill-current text-gray-200 group-hover:text-inherit transition-colors duration-150 ease-out"})),(!h||h&&!g)&&d.createElement(Wi,{disabled:g,onClick:k}))))},Ti=({children:a,...b})=>d.createElement("div",{className:"group text-gray-400 hover:text-blue-600 flex-1 min-w-0 relative flex justify-between items-center p-2",...b},a),Ui=({error:a,children:b})=>d.createElement("span",{className:`m-0 text-xs font-semibold flex-1 text-ellipsis overflow-hidden transition-all ease-out duration-100 text-left ${a?"text-red-500":"text-gray-600 group-hover:text-inherit"}`},b),Vi=({isDragging:a,children:b,provider:c,...e})=>d.createElement("div",{className:`relative group cursor-pointer flex justify-between items-stretch bg-white border border-gray-100 -mb-px overflow-visible p-0 text-sm font-normal ${a?"rounded shadow text-blue-600":"text-gray-600 first:rounded-t last:rounded-b"}`,ref:c.innerRef,...c.draggableProps,...c.dragHandleProps,...e},b),Wi=({onClick:a,disabled:b=!1})=>d.createElement("button",{className:`w-8 px-1 py-2.5 flex items-center justify-center hover:bg-gray-50 text-gray-200 hover:text-red-500 ${b&&"pointer-events-none opacity-30 cursor-not-allowed"}`,onClick:a},d.createElement(oa,{className:"fill-current transition-colors ease-out duration-100"})),Xi=({isDragging:a})=>d.createElement("div",{className:`relative w-8 px-1 py-2.5 flex items-center justify-center hover:bg-gray-50 group cursor-[grab] ${a?"text-blue-500":"text-gray-200 hover:text-gray-600"}`},a?d.createElement(sa,{className:"fill-current w-7 h-auto"}):d.createElement(d.Fragment,null,d.createElement(ba,{className:"fill-current w-7 h-auto group-hover:opacity-0 transition-opacity duration-150 ease-out"}),d.createElement(sa,{className:"fill-current w-7 h-auto absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-150 ease-out"}))),Yi=({tinaForm:a,form:b,field:c,input:e,meta:f,index:g})=>{const h=d.useCallback(()=>{let a={};a="function"==typeof c.defaultItem?c.defaultItem():c.defaultItem||{},b.mutators.insert(c.name,0,a)},[b,c]),i=e.value||[],j=d.useCallback(a=>c.itemProps?c.itemProps(a):{},[c.itemProps]),k=i.length>=(c.max||1/0),l=i.length<=(c.min||0),m=c.min===c.max;return d.createElement(Mi,{name:e.name,label:c.label,description:c.description,error:f.error,index:g,triggerHoverEvents:!1,tinaForm:a,actions:(!m||m&&!k)&&d.createElement(Gc,{onClick:h,disabled:k,variant:"primary",size:"small"},d.createElement(Q,{className:"w-5/6 h-auto"}))},d.createElement(Qi,null,d.createElement("div",null,d.createElement(u.Droppable,{droppableId:c.name,type:c.name},b=>d.createElement("div",{ref:b.innerRef},0===i.length&&d.createElement(Ri,null),i.map((b,e)=>d.createElement(Si,{key:e,tinaForm:a,field:c,item:b,index:e,isMin:l,fixedLength:m,...j(b)})),b.placeholder)))))},Zi={name:"group-list",Component:Yi},$i=({templates:a,addItem:b})=>{const c=d.useMemo(()=>Object.entries(a).length>6,[a]),[e,f]=d.useState(""),g=d.useMemo(()=>Object.entries(a).filter(([a,b])=>b.label?b.label.toLowerCase().includes(e.toLowerCase())||a.toLowerCase().includes(e.toLowerCase()):a.toLowerCase().includes(e.toLowerCase())),[e]);return d.createElement(k.J,null,({open:a})=>d.createElement(d.Fragment,null,d.createElement(k.J.Button,{as:"span"},d.createElement(Gc,{variant:a?"secondary":"primary",size:"small",className:`${a?"rotate-45 pointer-events-none":""}`},d.createElement(Q,{className:"w-5/6 h-auto"}))),d.createElement("div",{className:"transform translate-y-full absolute -bottom-1 right-0 z-50"},d.createElement(j.u,{enter:"transition duration-150 ease-out",enterFrom:"transform opacity-0 -translate-y-2",enterTo:"transform opacity-100 translate-y-0",leave:"transition duration-75 ease-in",leaveFrom:"transform opacity-100 translate-y-0",leaveTo:"transform opacity-0 -translate-y-2"},d.createElement(k.J.Panel,{className:"relative overflow-hidden rounded-lg shadow-lg bg-white border border-gray-100"},({close:a})=>d.createElement("div",{className:"min-w-[192px] max-h-[24rem] overflow-y-auto flex flex-col w-full h-full"},c&&d.createElement("div",{className:"sticky top-0 bg-gray-50 p-2 border-b border-gray-100 z-10"},d.createElement("input",{type:"text",className:"bg-white text-xs rounded-sm border border-gray-100 shadow-inner py-1 px-2 w-full block placeholder-gray-200",onClick:a=>{a.stopPropagation(),a.preventDefault()},value:e,onChange:a=>{f(a.target.value)},placeholder:"Filter..."})),0===g.length&&d.createElement("span",{className:"relative text-center text-xs px-2 py-3 text-gray-300 bg-gray-50 italic"},"No matches found"),g.length>0&&g.map(([c,e])=>d.createElement("button",{className:"relative text-center text-xs py-2 px-4 border-l-0 border-t-0 border-r-0 border-b border-gray-50 w-full outline-none transition-all ease-out duration-150 hover:text-blue-500 focus:text-blue-500 focus:bg-gray-50 hover:bg-gray-50",key:c,onClick:()=>{b(c,e),f(""),a()}},e.label?e.label:c))))))))},_i=({templates:a,addItem:b,label:c})=>{const e=Nc(),[f,g]=d.useState(!1),h=d.useMemo(()=>Object.entries(a).length>6,[a]),[i,k]=d.useState(""),l=d.useMemo(()=>Object.entries(a).filter(([a,b])=>b.label?b.label.toLowerCase().includes(i.toLowerCase())||a.toLowerCase().includes(i.toLowerCase()):a.toLowerCase().includes(i.toLowerCase())),[i]),m=d.useMemo(()=>[...new Set(Object.entries(a).filter(([a,b])=>!!b.category&&b.category).map(([a,b])=>b.category))],[a]),n=d.useMemo(()=>Object.entries(a).filter(([a,b])=>!b.category).length>0,[a]),o=d.useMemo(()=>l.filter(([a,b])=>!b.category),[l]),p=(a,c)=>{a&&c&&b(a,c),k(""),g(!1)};return d.createElement(d.Fragment,null,d.createElement(Gc,{variant:f?"secondary":"primary",size:"small",className:`${f?"rotate-45 pointer-events-none":""}`,onClick:()=>g(!f)},d.createElement(Q,{className:"w-5/6 h-auto"})),d.createElement(e,null,({zIndexShift:a})=>d.createElement(j.u,{show:f},d.createElement(j.u.Child,{as:d.Fragment,enter:"transform transition-all ease-out duration-200",enterFrom:"opacity-0 -translate-x-1/2",enterTo:"opacity-100 translate-x-0",leave:"transform transition-all ease-in duration-150",leaveFrom:"opacity-100 translate-x-0",leaveTo:"opacity-0 -translate-x-1/2"},d.createElement("div",{className:"absolute left-0 top-0 z-panel h-full w-full transform bg-gray-50",style:{zIndex:a+1e3}},d.createElement(Nd,{onClick:()=>{g(!1)}},c," ⁠– Add New"),d.createElement("div",{className:"h-full overflow-y-auto max-h-full bg-gray-50 pt-4 px-6 pb-12"},d.createElement("div",{className:"w-full flex justify-center"},d.createElement("div",{className:"w-full max-w-form"},h&&d.createElement("div",{className:"block relative group mb-1"},d.createElement("input",{type:"text",className:"shadow-inner focus:shadow-outline focus:border-blue-400 focus:outline-none block text-sm pl-2.5 pr-8 py-1.5 text-gray-600 w-full bg-white border border-gray-200 focus:text-gray-900 rounded-md placeholder-gray-400 hover:placeholder-gray-600 transition-all ease-out duration-150",onClick:a=>{a.stopPropagation(),a.preventDefault()},value:i,onChange:a=>{k(a.target.value)},placeholder:"Search"}),""===i?d.createElement(Jd,{className:"absolute right-3 top-1/2 -translate-y-1/2 w-5 h-auto text-blue-500 opacity-70 group-hover:opacity-100 transition-all ease-out duration-150"}):d.createElement("button",{onClick:()=>{k("")},className:"outline-none focus:outline-none bg-transparent border-0 p-0 m-0 absolute right-2.5 top-1/2 -translate-y-1/2 opacity-50 hover:opacity-100 transition-all ease-out duration-150"},d.createElement(ze,{className:"w-5 h-auto text-gray-600"}))),0===o.length&&0===m.length&&d.createElement(dj,null,"No blocks to display."),o.length>0&&0===m.length&&d.createElement(bj,{className:"pt-3"},o.map(([a,b])=>d.createElement(cj,{key:`${b}-${a}`,close:p,name:a,template:b}))),m.map((a,b)=>d.createElement(aj,{key:b,templates:l.filter(([b,c])=>!!c.category&&c.category===a),category:a,isLast:b===m.length-1&&!n,close:p})),n&&0===o.length&&d.createElement("div",{className:"relative text-gray-500 block text-left w-full text-base font-bold tracking-wide py-2 truncate pointer-events-none opacity-50"},"Uncategorized"),o.length>0&&m.length>0&&d.createElement(aj,{templates:o,category:"Uncategorized",close:p,isLast:!0})))))))))},aj=({category:a,templates:b,close:c,isLast:e=!1})=>d.createElement(l.p,{defaultOpen:!0,as:"div",className:"left-0 right-0 relative"},({open:f})=>d.createElement(d.Fragment,null,d.createElement(l.p.Button,{className:`relative block group text-left w-full text-base font-bold tracking-wide py-2 truncate ${0===b.length?"pointer-events-none":""} ${!e&&(!f||0===b.length)&&"border-b border-gray-100"}`},d.createElement("span",{className:`text-gray-500 group-hover:text-gray-800 transition-all ease-out duration-150 ${0===b.length?"opacity-50":""}`},a),b.length>0&&d.createElement(we,{className:`absolute top-1/2 right-0 w-6 h-auto -translate-y-1/2 text-gray-300 origin-center group-hover:text-blue-500 transition-all duration-150 ease-out ${f?"":"-rotate-90 opacity-70 group-hover:opacity-100"}`})),d.createElement(j.u,{enter:"transition duration-100 ease-out",enterFrom:"transform scale-95 opacity-0",enterTo:"transform scale-100 opacity-100",leave:"transition duration-75 ease-out",leaveFrom:"transform scale-100 opacity-100",leaveTo:"transform scale-95 opacity-0"},d.createElement(l.p.Panel,null,b.length>0&&d.createElement(bj,null,b.map(([a,b])=>d.createElement(cj,{close:c,name:a,template:b}))))))),bj=({children:a,className:b=""})=>d.createElement("div",{className:`w-full mb-1 -mt-2 ${b}`,style:{columns:"320px",columnGap:"16px"}},a),cj=({close:a,name:b,template:c})=>d.createElement("button",{className:"mb-2 mt-2 group relative text-xs font-bold border border-gray-100 w-full outline-none transition-all ease-out duration-150 hover:text-blue-500 focus:text-blue-500 focus:bg-gray-50 hover:bg-gray-50 rounded-md bg-white shadow overflow-hidden",style:{breakInside:"avoid",transform:"translateZ(0)"},key:b,onClick:()=>{a(b,c)}},c.previewSrc&&d.createElement("img",{src:c.previewSrc,className:"w-full h-auto transition-all ease-out duration-150 group-hover:opacity-50"}),d.createElement("span",{className:`relative flex justify-between items-center gap-4 w-full px-4 text-left ${c.previewSrc?"py-2 border-t border-gray-100 ":"py-3"}`},c.label?c.label:b,d.createElement(Q,{className:"w-5 h-auto group-hover:text-blue-500 opacity-30 transition-all ease-out duration-150 group-hover:opacity-80"}))),dj=({children:a})=>d.createElement("div",{className:"block relative text-gray-300 italic py-1"},a),ej=({label:a,tinaForm:b,field:c,index:e,template:f,block:g,isMin:h,fixedLength:i})=>{const j=Ta();Nc(),d.useState(!1);const k=d.useCallback(()=>{b.mutators.remove(c.name,e)},[b,c,e]),{dispatch:l}=Wa("field:hover"),{dispatch:m}=Wa("field:focus");return d.createElement(u.Draggable,{key:e,type:c.name,draggableId:`${c.name}.${e}`,index:e},(g,n)=>d.createElement(d.Fragment,null,d.createElement(Vi,{provider:g,isDragging:n.isDragging},d.createElement(Xi,{isDragging:n.isDragging}),d.createElement(Ti,{onClick:()=>{const a=b.finalForm.getState();if(!0===a.invalid){j.alerts.error("Cannot navigate away from an invalid form.");return}j.dispatch({type:"forms:set-active-field-name",value:{formId:b.id,fieldName:`${c.name}.${e}`}}),m({id:b.id,fieldName:`${c.name}.${e}`})},onMouseOver:()=>l({id:b.id,fieldName:`${c.name}.${e}`}),onMouseOut:()=>l({id:null,fieldName:null})},d.createElement(Ui,null,a||f.label),d.createElement(Fd,{className:"h-5 w-auto fill-current text-gray-200 group-hover:text-inherit transition-colors duration-150 ease-out"})),(!i||i&&!h)&&d.createElement(Wi,{disabled:h,onClick:k}))))},fj=({tinaForm:a,field:b,index:c})=>{const e=d.useCallback(()=>{a.mutators.remove(b.name,c)},[a,b,c]);return d.createElement(u.Draggable,{key:c,type:b.name,draggableId:`${b.name}.${c}`,index:c},(a,b)=>d.createElement(Vi,{provider:a,isDragging:b.isDragging},d.createElement(Xi,{isDragging:b.isDragging}),d.createElement(Ti,null,d.createElement(Ui,{error:!0},"Invalid Block")),d.createElement(Wi,{onClick:e})))},gj=({tinaForm:a,form:b,field:c,input:e,meta:f,index:g})=>{const h=d.useCallback((a,d)=>{let e={};(e="function"==typeof d.defaultItem?d.defaultItem():d.defaultItem||{})._template=a,b.mutators.insert(c.name,0,e)},[c.name,b.mutators]),i=e.value||[],j=i.length>=(c.max||1/0),k=i.length<=(c.min||0),l=c.min===c.max;return d.createElement(Mi,{name:e.name,label:c.label,description:c.description,error:f.error,triggerHoverEvents:!1,index:g,tinaForm:a,actions:(!l||l&&!j)&&(c.visualSelector?d.createElement(_i,{label:c.label||c.name,templates:c.templates,addItem:h}):d.createElement($i,{templates:c.templates,addItem:h}))},d.createElement(Qi,null,d.createElement(u.Droppable,{droppableId:c.name,type:c.name},b=>d.createElement("div",{ref:b.innerRef,className:"edit-page--list-parent"},0===i.length&&d.createElement(Ri,null),i.map((b,e)=>{var f;const g=c.templates[b._template];return g?d.createElement(ej,{key:e,block:b,template:g,index:e,field:c,tinaForm:a,isMin:k,fixedLength:l,...(f=b,g.itemProps?g.itemProps(f):{})}):d.createElement(fj,{key:e,index:e,field:c,tinaForm:a})}),b.placeholder))))},hj={name:"blocks",Component:gj},ij=Xa(({input:a,field:b})=>d.createElement(te,{colorFormat:b.colorFormat,userColors:b.colors,widget:b.widget,input:a})),jj={name:"color",Component:ij,parse:a=>a||"",validate(a,b,c,d){if(d.required&&!a)return"Required"}},kj=({tinaForm:a,field:b,index:c,item:e,label:f,isMin:g,fixedLength:h,...i})=>{const j=d.useCallback(()=>{a.mutators.remove(b.name,c)},[a,b,c]),k=[{type:b.type,list:b.list,parentTypename:b.parentTypename,...b.field,label:!1,name:b.name+"."+c}];return d.createElement(u.Draggable,{type:b.name,draggableId:`${b.name}.${c}`,index:c},(b,c)=>d.createElement(Vi,{provider:b,isDragging:c.isDragging,...i},d.createElement(Xi,{isDragging:c.isDragging}),d.createElement(Ti,null,d.createElement(wc,{padding:!1,form:a,fields:k})),(!h||h&&!g)&&d.createElement(Wi,{disabled:g,onClick:j})))},lj=({tinaForm:a,form:b,field:c,input:e,meta:f,index:g})=>{const h=d.useCallback(()=>{let a="";"function"==typeof c.defaultItem?a=c.defaultItem():void 0!==c.defaultItem&&(a=c.defaultItem),b.mutators.insert(c.name,0,a)},[b,c]),i=e.value||[],j=d.useCallback(a=>c.itemProps?c.itemProps(a):{},[c.itemProps]),k=i.length>=(c.max||1/0),l=i.length<=(c.min||0),m=c.min===c.max;return d.createElement(Mi,{name:e.name,label:c.label,description:c.description,error:f.error,index:g,tinaForm:a,actions:(!m||m&&!k)&&d.createElement(Gc,{onClick:h,variant:"primary",size:"small"},d.createElement(Q,{className:"w-5/6 h-auto"}))},d.createElement(Qi,null,d.createElement("div",null,d.createElement(u.Droppable,{droppableId:c.name,type:c.name},b=>d.createElement("div",{ref:b.innerRef},0===i.length&&d.createElement(Ri,null),i.map((b,e)=>d.createElement(kj,{key:e,tinaForm:a,field:c,item:b,index:e,isMin:l,fixedLength:m,...j(b)})),b.placeholder)))))},mj={name:"list",Component:lj,validate(a,b,c,d){if(d.required&&!a)return"Required"}},nj=Xa(a=>{const b=d.useRef(null),c=Ta(),{value:e}=a.input,[f,g]=(0,d.useState)(!1);let h;async function i(b){var d,e;if(b){const f="function"==typeof(null==(e=null==(d=null==c?void 0:c.media)?void 0:d.store)?void 0:e.parse)?c.media.store.parse(b):b;a.input.onChange(f)}}a.field.clearable&&(h=()=>a.input.onChange("")),d.useEffect(()=>{b.current&&a.field.experimental_focusIntent&&b.current.focus()},[a.field.experimental_focusIntent,b]);const j=a.field.uploadDir||(()=>"");return d.createElement(Te,{ref:b,value:e,src:e,loading:f,onClick:()=>{const b=j(a.form.getState().values);c.media.open({allowDelete:!0,directory:b,onSelect:i})},onDrop:async([b],e)=>{g(!0);try{if(b){const f=j(a.form.getState().values),[h]=await c.media.persist([{directory:f,file:b}]);h&&await i(h)}const k={"file-invalid-type":"Invalid file type","file-too-large":"File too large","file-too-small":"File too small","too-many-files":"Too many files"},l=a=>{const b=k[a.code];return b||(console.error(a),"Unknown error")};if(e.length>0){const m=[];e.map(a=>{m.push(`${a.file.name}: ${a.errors.map(a=>l(a)).join(", ")}`)}),c.alerts.error(()=>d.createElement(d.Fragment,null,"Upload Failed. ",d.createElement("br",null),m.join(". "),"."))}}catch(n){console.error("Error uploading media asset: ",n)}finally{g(!1)}},onClear:h})}),oj={name:"image",Component:nj,parse:a=>a||"",validate(a,b,c,d){if(d.required&&!a)return"Required"}},pj=Xa(({input:a,field:b})=>d.createElement(Le,{...a,step:b.step})),qj={name:"number",Component:pj,parse:a=>a&&+a,validate(a,b,c,d){if(d.required&&"number"!=typeof a)return"Required"}},rj=Xa(De),sj={name:"select",type:"select",Component:rj,parse:a=>a||"",validate(a,b,c,d){if(d.required&&!a)return"Required"}},tj=Xa(Ge),uj={name:"radio-group",Component:tj,validate(a,b,c,d){if(d.required&&!a)return"Required"}},vj=Xa(a=>{const b=d.useRef(null);return d.useEffect(()=>{if(b.current&&a.field.experimental_focusIntent){const c=b.current;c.focus(),c.setSelectionRange(c.value.length,c.value.length)}},[a.field.experimental_focusIntent,b]),d.createElement(je,{ref:b,...a.input})}),wj={name:"textarea",Component:vj,parse:a=>a||"",validate(a,b,c,d){if(d.required&&!a)return"Required"}},xj=Xa(a=>{var b,c;const e=d.useRef(null);return d.useEffect(()=>{e.current&&a.field.experimental_focusIntent&&e.current.focus()},[a.field.experimental_focusIntent,e]),d.createElement(ie,{...a.input,ref:e,disabled:null!=(c=null==(b=a.field)?void 0:b.disabled)&&c,placeholder:a.field.placeholder})}),yj={name:"text",Component:xj,validate(a,b,c,d){if(d.required&&!a)return"Required"},parse:a=>a||""},zj=Xa(ue),Aj={name:"toggle",type:"checkbox",Component:zj,validate(a,b,c,d){if(d.required&&null==a)return"Required"}},Bj=Xa(({input:a,field:b,form:c,tinaForm:e})=>{const[f,g]=d.useState(""),h=d.useCallback(a=>{var d,e;null!=(e=null==(d=c.getFieldState(b.name))?void 0:d.value)&&e.includes(a)||a.length&&(c.mutators.insert(b.name,0,a),g(""))},[c,b.name]),i=a.value||[],j=d.useRef(null);return d.useEffect(()=>{j.current&&b.experimental_focusIntent&&j.current.focus()},[b.experimental_focusIntent,j]),d.createElement(d.Fragment,null,d.createElement("div",{className:"flex items-center gap-3"},d.createElement(ie,{ref:j,value:f,onChange:a=>g(a.target.value),placeholder:b.placeholder?b.placeholder:"Add a tag",onKeyPress:a=>{(","===a.key||"Enter"===a.key)&&(a.preventDefault(),h(f))},className:"flex-1"}),d.createElement(Gc,{onClick:()=>{h(f)},variant:"primary",size:"small",className:"flex-shrink-0"},d.createElement(Q,{className:"w-5/6 h-auto"}))),d.createElement("span",{className:"flex gap-2 flex-wrap mt-2 mb-0"},0===i.length&&d.createElement("span",{className:"text-gray-300 text-sm italic"},"No tags"),i.map((a,c)=>d.createElement(Cj,{key:a,tinaForm:e,field:b,index:c},a))))}),Cj=({tinaForm:a,field:b,index:c,children:e,...f})=>{const g=d.useCallback(()=>{a.mutators.remove(b.name,c)},[a,b,c]);return d.createElement("span",{className:"rounded-full shadow bg-white border border-gray-150 flex items-center tracking-[0.01em] leading-none text-gray-700",...f},d.createElement("span",{style:{maxHeight:"calc(var(--tina-sidebar-width) - 50px)"},className:"text-sm flex-1 pl-3 pr-1 py-1 truncate"},e),d.createElement("button",{className:"group text-center flex-shrink-0 border-0 bg-transparent pl-1 pr-2 py-1 text-gray-300 hover:text-blue-500 flex items-center justify-center cursor-pointer",onClick:g},d.createElement(Kd,{className:"w-4 h-auto transition ease-out duration-100 group-hover:scale-110 origin-center"})))},Dj={name:"tags",Component:Bj,parse:a=>a||""};function Ej({onClickPrev:a,onClickSwitch:b,onClickNext:c,switchContent:e,switchColSpan:f,switchProps:g}){return d.createElement("tr",null,d.createElement("th",{className:"rdtPrev",onClick:a},d.createElement("span",null,"‹")),d.createElement("th",{className:"rdtSwitch",colSpan:f,onClick:b,...g},e),d.createElement("th",{className:"rdtNext",onClick:c},d.createElement("span",null,"›")))}class Fj extends d.Component{constructor(){super(...arguments),I(this,"_setDate",a=>{this.props.updateDate(a)})}render(){return d.createElement("div",{className:"rdtDays"},d.createElement("table",null,d.createElement("thead",null,this.renderNavigation(),this.renderDayHeaders()),d.createElement("tbody",null,this.renderDays()),this.renderFooter()))}renderNavigation(){const Gj=this.props.viewDate,Hj=Gj.localeData();return d.createElement(Ej,{onClickPrev:()=>this.props.navigate(-1,"months"),onClickSwitch:()=>this.props.showView("months"),onClickNext:()=>this.props.navigate(1,"months"),switchContent:Hj.months(Gj)+" "+Gj.year(),switchColSpan:5,switchProps:{"data-value":this.props.viewDate.month()}})}renderDayHeaders(){const Ij=this.props.viewDate.localeData();let Jj=Zj(Ij).map((a,b)=>d.createElement("th",{key:a+b,className:"dow"},a));return d.createElement("tr",null,Jj)}renderDays(){const Kj=this.props.viewDate,Lj=Kj.clone().startOf("month"),Mj=Kj.clone().endOf("month");let Nj=[[],[],[],[],[],[]],Oj=Kj.clone().subtract(1,"months");Oj.date(Oj.daysInMonth()).startOf("week");let Pj=Oj.clone().add(42,"d"),Qj=0;for(;Oj.isBefore(Pj);)Yj(Nj,Qj++).push(this.renderDay(Oj,Lj,Mj)),Oj.add(1,"d");return Nj.map((a,b)=>d.createElement("tr",{key:`${Pj.month()}_${b}`},a))}renderDay(Rj,Sj,Tj){let Uj=this.props.selectedDate,Vj={key:Rj.format("M_D"),"data-value":Rj.date(),"data-month":Rj.month(),"data-year":Rj.year()},Wj="rdtDay";return Rj.isBefore(Sj)?Wj+=" rdtOld":Rj.isAfter(Tj)&&(Wj+=" rdtNew"),Uj&&Rj.isSame(Uj,"day")&&(Wj+=" rdtActive"),Rj.isSame(this.props.moment(),"day")&&(Wj+=" rdtToday"),this.props.isValidDate(Rj)?Vj.onClick=this._setDate:Wj+=" rdtDisabled",Vj.className=Wj,this.props.renderDay(Vj,Rj.clone(),Uj&&Uj.clone())}renderFooter(){if(!this.props.timeFormat)return;const Xj=this.props.viewDate;return d.createElement("tfoot",null,d.createElement("tr",null,d.createElement("td",{onClick:()=>this.props.showView("time"),colSpan:7,className:"rdtTimeToggle"},Xj.format(this.props.timeFormat))))}}function Yj(a,b){return a[Math.floor(b/7)]}function Zj(a){const b=a.firstDayOfWeek();let c=[],d=0;return a._weekdaysMin.forEach(function(a){c[(7+d++-b)%7]=a}),c}I(Fj,"defaultProps",{isValidDate:()=>!0,renderDay:(a,b)=>d.createElement("td",{...a},b.date())});class $j extends d.Component{constructor(){super(...arguments),I(this,"_updateSelectedMonth",a=>{this.props.updateDate(a)})}render(){return d.createElement("div",{className:"rdtMonths"},d.createElement("table",null,d.createElement("thead",null,this.renderNavigation())),d.createElement("table",null,d.createElement("tbody",null,this.renderMonths())))}renderNavigation(){let _j=this.props.viewDate.year();return d.createElement(Ej,{onClickPrev:()=>this.props.navigate(-1,"years"),onClickSwitch:()=>this.props.showView("years"),onClickNext:()=>this.props.navigate(1,"years"),switchContent:_j,switchColSpan:"2"})}renderMonths(){let ak=[[],[],[]];for(let bk=0;bk<12;bk++)ok(ak,bk).push(this.renderMonth(bk));return ak.map((a,b)=>d.createElement("tr",{key:b},a))}renderMonth(ck){const dk=this.props.selectedDate;let ek="rdtMonth",fk;this.isDisabledMonth(ck)?ek+=" rdtDisabled":fk=this._updateSelectedMonth,dk&&dk.year()===this.props.viewDate.year()&&dk.month()===ck&&(ek+=" rdtActive");let gk={key:ck,className:ek,"data-value":ck,onClick:fk};return this.props.renderMonth?this.props.renderMonth(gk,ck,this.props.viewDate.year(),this.props.selectedDate&&this.props.selectedDate.clone()):d.createElement("td",{...gk},this.getMonthText(ck))}isDisabledMonth(hk){let ik=this.props.isValidDate;if(!ik)return!1;let jk=this.props.viewDate.clone().set({month:hk}),kk=jk.endOf("month").date()+1;for(;kk-- >1;)if(ik(jk.date(kk)))return!1;return!0}getMonthText(lk){const mk=this.props.viewDate,nk=mk.localeData().monthsShort(mk.month(lk));return pk(nk.substring(0,3))}}function ok(a,b){return b<4?a[0]:b<8?a[1]:a[2]}function pk(a){return a.charAt(0).toUpperCase()+a.slice(1)}class qk extends d.Component{constructor(){super(...arguments),I(this,"disabledYearsCache",{}),I(this,"_updateSelectedYear",a=>{this.props.updateDate(a)})}render(){return d.createElement("div",{className:"rdtYears"},d.createElement("table",null,d.createElement("thead",null,this.renderNavigation())),d.createElement("table",null,d.createElement("tbody",null,this.renderYears())))}renderNavigation(){const rk=this.getViewYear();return d.createElement(Ej,{onClickPrev:()=>this.props.navigate(-10,"years"),onClickSwitch:()=>this.props.showView("years"),onClickNext:()=>this.props.navigate(10,"years"),switchContent:`${rk}-${rk+9}`})}renderYears(){const sk=this.getViewYear();let tk=[[],[],[]];for(let uk=sk-1;uk<sk+11;uk++)Ek(tk,uk-sk).push(this.renderYear(uk));return tk.map((a,b)=>d.createElement("tr",{key:b},a))}renderYear(vk){const wk=this.getSelectedYear();let xk="rdtYear",yk;return this.isDisabledYear(vk)?xk+=" rdtDisabled":yk=this._updateSelectedYear,wk===vk&&(xk+=" rdtActive"),this.props.renderYear({key:vk,className:xk,"data-value":vk,onClick:yk},vk,this.props.selectedDate&&this.props.selectedDate.clone())}getViewYear(){return 10*parseInt(this.props.viewDate.year()/10,10)}getSelectedYear(){return this.props.selectedDate&&this.props.selectedDate.year()}isDisabledYear(zk){let Ak=this.disabledYearsCache;if(void 0!==Ak[zk])return Ak[zk];let Bk=this.props.isValidDate;if(!Bk)return!1;let Ck=this.props.viewDate.clone().set({year:zk}),Dk=Ck.endOf("year").dayOfYear()+1;for(;Dk-- >1;)if(Bk(Ck.dayOfYear(Dk)))return Ak[zk]=!1,!1;return Ak[zk]=!0,!0}}function Ek(a,b){return b<3?a[0]:b<7?a[1]:a[2]}I(qk,"defaultProps",{renderYear:(a,b)=>d.createElement("td",{...a},b)});const Fk={hours:{min:0,max:23,step:1},minutes:{min:0,max:59,step:1},seconds:{min:0,max:59,step:1},milliseconds:{min:0,max:999,step:1}};class Gk extends d.Component{constructor(Hk){var Ik;super(Hk);let Jk;Ik=Hk.timeConstraints,Jk={},Object.keys(Fk).forEach(a=>{Jk[a]={...Fk[a],...Ik[a]||{}}}),this.constraints=Jk,this.state=this.getTimeParts(Hk.selectedDate||Hk.viewDate)}render(){let Kk=[];const Lk=this.state;return this.getCounters().forEach((a,b)=>{b&&"ampm"!==a&&Kk.push(d.createElement("div",{key:`sep${b}`,className:"rdtCounterSeparator"},":")),Kk.push(this.renderCounter(a,Lk[a]))}),d.createElement("div",{className:"rdtTime"},d.createElement("table",null,this.renderHeader(),d.createElement("tbody",null,d.createElement("tr",null,d.createElement("td",null,d.createElement("div",{className:"rdtCounters"},Kk))))))}renderCounter(Mk,Nk){return"hours"===Mk&&this.isAMPM()&&0==(Nk=(Nk-1)%12+1)&&(Nk=12),"ampm"===Mk&&(Nk=-1!==this.props.timeFormat.indexOf(" A")?this.props.viewDate.format("A"):this.props.viewDate.format("a")),d.createElement("div",{key:Mk,className:"rdtCounter"},d.createElement("span",{className:"rdtBtn",onMouseDown:a=>this.onStartClicking(a,"increase",Mk)},"▲"),d.createElement("div",{className:"rdtCount"},Nk),d.createElement("span",{className:"rdtBtn",onMouseDown:a=>this.onStartClicking(a,"decrease",Mk)},"▼"))}renderHeader(){if(!this.props.dateFormat)return;const Ok=this.props.selectedDate||this.props.viewDate;return d.createElement("thead",null,d.createElement("tr",null,d.createElement("td",{className:"rdtSwitch",colSpan:"4",onClick:()=>this.props.showView("days")},Ok.format(this.props.dateFormat))))}onStartClicking(Pk,Qk,Rk){if(Pk&&Pk.button&&0!==Pk.button)return;if("ampm"===Rk)return this.toggleDayPart();let Sk={},Tk=document.body;Sk[Rk]=this[Qk](Rk),this.setState(Sk),this.timer=setTimeout(()=>{this.increaseTimer=setInterval(()=>{Sk[Rk]=this[Qk](Rk),this.setState(Sk)},70)},500),this.mouseUpListener=()=>{clearTimeout(this.timer),clearInterval(this.increaseTimer),this.props.setTime(Rk,parseInt(this.state[Rk],10)),Tk.removeEventListener("mouseup",this.mouseUpListener),Tk.removeEventListener("touchend",this.mouseUpListener)},Tk.addEventListener("mouseup",this.mouseUpListener),Tk.addEventListener("touchend",this.mouseUpListener)}toggleDayPart(){let Uk=parseInt(this.state.hours,10);Uk>=12?Uk-=12:Uk+=12,this.props.setTime("hours",Uk)}increase(Vk){const Wk=this.constraints[Vk];let Xk=parseInt(this.state[Vk],10)+Wk.step;return Xk>Wk.max&&(Xk=Wk.min+(Xk-(Wk.max+1))),el(Vk,Xk)}decrease(Yk){const Zk=this.constraints[Yk];let $k=parseInt(this.state[Yk],10)-Zk.step;return $k<Zk.min&&($k=Zk.max+1-(Zk.min-$k)),el(Yk,$k)}getCounters(){let _k=[],al=this.props.timeFormat;return -1!==al.toLowerCase().indexOf("h")&&(_k.push("hours"),-1!==al.indexOf("m")&&(_k.push("minutes"),-1!==al.indexOf("s")&&(_k.push("seconds"),-1!==al.indexOf("S")&&_k.push("milliseconds")))),this.isAMPM()&&_k.push("ampm"),_k}isAMPM(){return -1!==this.props.timeFormat.toLowerCase().indexOf(" a")}getTimeParts(bl){const cl=bl.hours();return{hours:el("hours",cl),minutes:el("minutes",bl.minutes()),seconds:el("seconds",bl.seconds()),milliseconds:el("milliseconds",bl.milliseconds()),ampm:cl<12?"am":"pm"}}componentDidUpdate(dl){this.props.selectedDate?this.props.selectedDate!==dl.selectedDate&&this.setState(this.getTimeParts(this.props.selectedDate)):dl.viewDate!==this.props.viewDate&&this.setState(this.getTimeParts(this.props.viewDate))}}function el(a,b){const c={hours:1,minutes:2,seconds:2,milliseconds:3};let d=b+"";for(;d.length<c[a];)d="0"+d;return d}const fl=t(),gl=function(){},hl=fl.oneOfType([fl.instanceOf(C()),fl.instanceOf(Date),fl.string]);class il extends d.Component{constructor(jl){super(jl),I(this,"_renderCalendar",()=>{const a=this.props,b=this.state;let c={viewDate:b.viewDate.clone(),selectedDate:this.getSelectedDate(),isValidDate:a.isValidDate,updateDate:this._updateDate,navigate:this._viewNavigate,moment:C(),showView:this._showView};switch(b.currentView){case"years":return c.renderYear=a.renderYear,d.createElement(qk,{...c});case"months":return c.renderMonth=a.renderMonth,d.createElement($j,{...c});case"days":return c.renderDay=a.renderDay,c.timeFormat=this.getFormat("time"),d.createElement(Fj,{...c});default:return c.dateFormat=this.getFormat("date"),c.timeFormat=this.getFormat("time"),c.timeConstraints=a.timeConstraints,c.setTime=this._setTime,d.createElement(Gk,{...c})}}),I(this,"_showView",(a,b)=>{const c=(b||this.state.viewDate).clone(),d=this.props.onBeforeNavigate(a,this.state.currentView,c);d&&this.state.currentView!==d&&(this.props.onNavigate(d),this.setState({currentView:d}))}),I(this,"viewToMethod",{days:"date",months:"month",years:"year"}),I(this,"nextView",{days:"time",months:"days",years:"months"}),I(this,"_updateDate",a=>{let b=this.state.currentView,c=this.getUpdateOn(this.getFormat("date")),d=this.state.viewDate.clone();d[this.viewToMethod[b]](parseInt(a.target.getAttribute("data-value"),10)),"days"===b&&(d.month(parseInt(a.target.getAttribute("data-month"),10)),d.year(parseInt(a.target.getAttribute("data-year"),10)));let e={viewDate:d};b===c?(e.selectedDate=d.clone(),e.inputValue=d.format(this.getFormat("datetime")),void 0===this.props.open&&this.props.input&&this.props.closeOnSelect&&this._closeCalendar(),this.props.onChange(d.clone())):this._showView(this.nextView[b],d),this.setState(e)}),I(this,"_viewNavigate",(a,b)=>{let c=this.state.viewDate.clone();c.add(a,b),a>0?this.props.onNavigateForward(a,b):this.props.onNavigateBack(-a,b),this.setState({viewDate:c})}),I(this,"_setTime",(a,b)=>{let c=(this.getSelectedDate()||this.state.viewDate).clone();c[a](b),this.props.value||this.setState({selectedDate:c,viewDate:c.clone(),inputValue:c.format(this.getFormat("datetime"))}),this.props.onChange(c)}),I(this,"_openCalendar",()=>{this.isOpen()||this.setState({open:!0},this.props.onOpen)}),I(this,"_closeCalendar",()=>{this.isOpen()&&this.setState({open:!1},()=>{this.props.onClose(this.state.selectedDate||this.state.inputValue)})}),I(this,"_handleClickOutside",()=>{let a=this.props;a.input&&this.state.open&& void 0===a.open&&a.closeOnClickOutside&&this._closeCalendar()}),I(this,"_onInputFocus",a=>{this.callHandler(this.props.inputProps.onFocus,a)&&this._openCalendar()}),I(this,"_onInputChange",a=>{if(!this.callHandler(this.props.inputProps.onChange,a))return;const b=a.target?a.target.value:a,c=this.localMoment(b,this.getFormat("datetime"));let d={inputValue:b};c.isValid()?(d.selectedDate=c,d.viewDate=c.clone().startOf("month")):d.selectedDate=null,this.setState(d,()=>{this.props.onChange(c.isValid()?c:this.state.inputValue)})}),I(this,"_onInputKeyDown",a=>{!!this.callHandler(this.props.inputProps.onKeyDown,a)&&9===a.which&&this.props.closeOnTab&&this._closeCalendar()}),I(this,"_onInputClick",a=>{this.callHandler(this.props.inputProps.onClick,a)&&this._openCalendar()}),this.state=this.getInitialState()}render(){return d.createElement(lm,{className:this.getClassName(),onClickOut:this._handleClickOutside},this.renderInput(),d.createElement("div",{className:"rdtPicker"},this.renderView()))}renderInput(){if(!this.props.input)return;const kl={type:"text",className:"form-control",value:this.getInputValue(),...this.props.inputProps,onFocus:this._onInputFocus,onChange:this._onInputChange,onKeyDown:this._onInputKeyDown,onClick:this._onInputClick};return this.props.renderInput?d.createElement("div",null,this.props.renderInput(kl,this._openCalendar,this._closeCalendar)):d.createElement("input",{...kl})}renderView(){return this.props.renderView(this.state.currentView,this._renderCalendar)}getInitialState(){let ll=this.props,ml=this.getFormat("datetime"),nl=this.parseDate(ll.value||ll.initialValue,ml);return this.checkTZ(),{open:!ll.input,currentView:ll.initialViewMode||this.getInitialView(),viewDate:this.getInitialViewDate(nl),selectedDate:nl&&nl.isValid()?nl:void 0,inputValue:this.getInitialInputValue(nl)}}getInitialViewDate(ol){const pl=this.props.initialViewDate;let ql;if(pl){if((ql=this.parseDate(pl,this.getFormat("datetime")))&&ql.isValid())return ql;im("The initialViewDated given \""+pl+"\" is not valid. Using current date instead.")}else if(ol&&ol.isValid())return ol.clone();return this.getInitialDate()}getInitialDate(){let rl=this.localMoment();return rl.hour(0).minute(0).second(0).millisecond(0),rl}getInitialView(){const sl=this.getFormat("date");return sl?this.getUpdateOn(sl):"time"}parseDate(tl,ul){let vl;return tl&&"string"==typeof tl?vl=this.localMoment(tl,ul):tl&&(vl=this.localMoment(tl)),vl&&!vl.isValid()&&(vl=null),vl}getClassName(){let wl="rdt",xl=this.props,yl=xl.className;return Array.isArray(yl)?wl+=" "+yl.join(" "):yl&&(wl+=" "+yl),xl.input||(wl+=" rdtStatic"),this.isOpen()&&(wl+=" rdtOpen"),wl}isOpen(){return!this.props.input||(void 0===this.props.open?this.state.open:this.props.open)}getUpdateOn(zl){return this.props.updateOnView?this.props.updateOnView:zl.match(/[lLD]/)?"days":-1!==zl.indexOf("M")?"months":-1!==zl.indexOf("Y")?"years":"days"}getLocaleData(){let Al=this.props;return this.localMoment(Al.value||Al.defaultValue||new Date()).localeData()}getDateFormat(){const Bl=this.getLocaleData();let Cl=this.props.dateFormat;return!0===Cl?Bl.longDateFormat("L"):Cl||""}getTimeFormat(){const Dl=this.getLocaleData();let El=this.props.timeFormat;return!0===El?Dl.longDateFormat("LT"):El||""}getFormat(Fl){if("date"===Fl)return this.getDateFormat();if("time"===Fl)return this.getTimeFormat();let Gl=this.getDateFormat(),Hl=this.getTimeFormat();return Gl&&Hl?Gl+" "+Hl:Gl||Hl}updateTime(Il,Jl,Kl,Ll){let Ml={};const Nl=Ll?"selectedDate":"viewDate";Ml[Nl]=this.state[Nl].clone()[Il](Jl,Kl),this.setState(Ml)}localMoment(Ol,Pl,Ql){Ql=Ql||this.props;let Rl=null;return Rl=Ql.utc?C().utc(Ol,Pl,Ql.strictParsing):Ql.displayTimeZone?C().tz(Ol,Pl,Ql.displayTimeZone):C()(Ol,Pl,Ql.strictParsing),Ql.locale&&Rl.locale(Ql.locale),Rl}checkTZ(){const{displayTimeZone:Sl}=this.props;!Sl||this.tzWarning||C().tz||(this.tzWarning=!0,im("displayTimeZone prop with value \""+Sl+"\" is used but moment.js timezone is not loaded.","error"))}componentDidUpdate(Tl){if(Tl===this.props)return;let Ul=!1,Vl=this.props;["locale","utc","displayZone","dateFormat","timeFormat"].forEach(function(a){Tl[a]!==Vl[a]&&(Ul=!0)}),Ul&&this.regenerateDates(),Vl.value&&Vl.value!==Tl.value&&this.setViewDate(Vl.value),this.checkTZ()}regenerateDates(){const Wl=this.props;let Xl=this.state.viewDate.clone(),Yl=this.state.selectedDate&&this.state.selectedDate.clone();Wl.locale&&(Xl.locale(Wl.locale),Yl&&Yl.locale(Wl.locale)),Wl.utc?(Xl.utc(),Yl&&Yl.utc()):Wl.displayTimeZone?(Xl.tz(Wl.displayTimeZone),Yl&&Yl.tz(Wl.displayTimeZone)):(Xl.locale(),Yl&&Yl.locale());let Zl={viewDate:Xl,selectedDate:Yl};Yl&&Yl.isValid()&&(Zl.inputValue=Yl.format(this.getFormat("datetime"))),this.setState(Zl)}getSelectedDate(){if(void 0===this.props.value)return this.state.selectedDate;let $l=this.parseDate(this.props.value,this.getFormat("datetime"));return!!($l&&$l.isValid())&&$l}getInitialInputValue(_l){const am=this.props;return am.inputProps.value?am.inputProps.value:_l&&_l.isValid()?_l.format(this.getFormat("datetime")):am.value&&"string"==typeof am.value?am.value:am.initialValue&&"string"==typeof am.initialValue?am.initialValue:""}getInputValue(){let bm=this.getSelectedDate();return bm?bm.format(this.getFormat("datetime")):this.state.inputValue}setViewDate(cm){let dm=function(){return im("Invalid date passed to the `setViewDate` method: "+cm)};if(!cm)return dm();let em;if(!(em="string"==typeof cm?this.localMoment(cm,this.getFormat("datetime")):this.localMoment(cm))||!em.isValid())return dm();this.setState({viewDate:em})}navigate(fm){this._showView(fm)}callHandler(gm,hm){return!gm|| !1!==gm(hm)}}function im(a,b){let c="undefined"!=typeof window&&window.console;c&&(b||(b="warn"),c[b]("***react-datetime:"+a))}I(il,"propTypes",{value:hl,initialValue:hl,initialViewDate:hl,initialViewMode:fl.oneOf(["years","months","days","time"]),onOpen:fl.func,onClose:fl.func,onChange:fl.func,onNavigate:fl.func,onBeforeNavigate:fl.func,onNavigateBack:fl.func,onNavigateForward:fl.func,updateOnView:fl.string,locale:fl.string,utc:fl.bool,displayTimeZone:fl.string,input:fl.bool,dateFormat:fl.oneOfType([fl.string,fl.bool]),timeFormat:fl.oneOfType([fl.string,fl.bool]),inputProps:fl.object,timeConstraints:fl.object,isValidDate:fl.func,open:fl.bool,strictParsing:fl.bool,closeOnSelect:fl.bool,closeOnTab:fl.bool,renderView:fl.func,renderInput:fl.func,renderDay:fl.func,renderMonth:fl.func,renderYear:fl.func}),I(il,"defaultProps",{onOpen:gl,onClose:gl,onCalendarOpen:gl,onCalendarClose:gl,onChange:gl,onNavigate:gl,onBeforeNavigate:function(a){return a},onNavigateBack:gl,onNavigateForward:gl,dateFormat:!0,timeFormat:!0,utc:!1,className:"",input:!0,inputProps:{},timeConstraints:{},isValidDate:function(){return!0},strictParsing:!0,closeOnSelect:!1,closeOnTab:!0,closeOnClickOutside:!0,renderView:(a,b)=>b()}),I(il,"moment",C());class jm extends d.Component{constructor(){super(...arguments),I(this,"container",d.createRef())}render(){return d.createElement("div",{className:this.props.className,ref:this.container},this.props.children)}handleClickOutside(km){this.props.onClickOut(km)}setClickOutsideRef(){return this.container.current}}const lm=(0,D.default)(jm),mm="MMM DD, YYYY",nm=Xa(({input:a,field:{dateFormat:b,timeFormat:c,...e}})=>d.createElement(d.Fragment,null,d.createElement(om,{value:a.value,onFocus:a.onFocus,onChange:a.onChange,dateFormat:b||mm,timeFormat:c||!1,inputProps:{className:he},...e}))),om=a=>{const[b,c]=(0,d.useState)(!1),e=(0,d.useRef)(null);return(0,d.useEffect)(()=>{const a=a=>{!e.current||a.target&&(e.current.contains(a.target)?c(!0):c(!1))};return document.addEventListener("mouseup",a,!1),()=>{document.removeEventListener("mouseup",a,!1)}},[document]),d.useEffect(()=>{e.current&&setTimeout(()=>{const b=e.current.querySelector("input[type=\"text\"]");a.experimental_focusIntent&&b&&b&&b.focus()},100)},[a.experimental_focusIntent,e]),d.createElement(d.Fragment,null,d.createElement("style",null,".tina-date-field .rdt {\n  position: relative;\n}\n\n.tina-date-field .rdtPicker {\n  display: none;\n  position: absolute;\n  width: 100%;\n  max-width: 350px;\n  padding: 4px;\n  margin-top: 4px;\n  z-index: 99999 !important;\n  background: var(--tina-color-grey-0);\n  border-radius: var(--tina-radius-small);\n  box-shadow: var(--tina-shadow-big);\n  border: 1px solid var(--tina-color-grey-2);\n}\n\n.tina-date-field .rdtOpen .rdtPicker {\n  display: block;\n}\n\n.tina-date-field .rdtStatic .rdtPicker {\n  box-shadow: none;\n  position: static;\n}\n\n.tina-date-field .rdtPicker .rdtTimeToggle {\n  text-align: center;\n}\n\n.tina-date-field .rdtPicker table {\n  width: 100%;\n  margin: 0;\n}\n\n.tina-date-field .rdtPicker td,\n.rdtPicker th {\n  text-align: center;\n  height: 28px;\n}\n\n.tina-date-field .rdtPicker td {\n  cursor: pointer;\n}\n\n.tina-date-field .rdtPicker td.rdtDay:hover,\n.tina-date-field .rdtPicker td.rdtHour:hover,\n.tina-date-field .rdtPicker td.rdtMinute:hover,\n.tina-date-field .rdtPicker td.rdtSecond:hover,\n.tina-date-field .rdtPicker .rdtTimeToggle:hover {\n  background: var(--tina-color-grey-2);\n  color: var(--tina-color-primary);\n  border-radius: var(--tina-radius-small);\n  cursor: pointer;\n}\n\n.tina-date-field .rdtPicker td.rdtDay:hover:active,\n.tina-date-field .rdtPicker td.rdtHour:hover:active,\n.tina-date-field .rdtPicker td.rdtMinute:hover:active,\n.tina-date-field .rdtPicker td.rdtSecond:hover:active,\n.tina-date-field .rdtPicker .rdtTimeToggle:hover:active {\n  background: var(--tina-color-primary);\n  color: var(--tina-color-grey-0);\n  border-radius: var(--tina-radius-small);\n}\n\n.tina-date-field .rdtPicker td.rdtOld,\n.rdtPicker td.rdtNew {\n  color: var(--tina-color-grey-6);\n}\n\n.tina-date-field .rdtPicker td.rdtToday {\n  position: relative;\n}\n\n.tina-date-field .rdtPicker td.rdtToday:before {\n  content: '';\n  display: inline-block;\n  border-left: 7px solid transparent;\n  border-bottom: 7px solid var(--tina-color-primary);\n  border-radius: 20px;\n  border-top-color: rgba(0, 0, 0, 0.2);\n  position: absolute;\n  bottom: 4px;\n  right: 4px;\n}\n\n.tina-date-field .rdtPicker td.rdtActive,\n.rdtPicker td.rdtActive:hover {\n  background-color: var(--tina-color-primary);\n  color: var(--tina-color-grey-0);\n  text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);\n}\n\n.tina-date-field .rdtPicker td.rdtActive.rdtToday:before {\n  border-bottom-color: var(--tina-color-grey-0);\n}\n\n.tina-date-field .rdtPicker td.rdtDisabled,\n.rdtPicker td.rdtDisabled:hover {\n  background: none;\n  color: var(--tina-color-grey-6);\n  cursor: not-allowed;\n}\n\n.tina-date-field .rdtPicker td span.rdtOld {\n  color: var(--tina-color-grey-6);\n}\n\n.tina-date-field .rdtPicker td span.rdtDisabled,\n.rdtPicker td span.rdtDisabled:hover {\n  background: none;\n  color: var(--tina-color-grey-6);\n  cursor: not-allowed;\n}\n\n.tina-date-field .rdtPicker th {\n  border-bottom: 1px solid var(--tina-color-grey-1);\n}\n\n.tina-date-field .rdtPicker .dow {\n  width: 14.2857%;\n  border-bottom: none;\n  cursor: default;\n}\n\n.tina-date-field .rdtPicker th.rdtSwitch {\n  width: 100px;\n}\n\n.tina-date-field .rdtPicker th.rdtNext,\n.rdtPicker th.rdtPrev {\n  font-size: 21px;\n  vertical-align: top;\n}\n\n.tina-date-field .rdtPrev span,\n.rdtNext span {\n  display: block;\n  -webkit-touch-callout: none;\n  /* iOS Safari */\n  -webkit-user-select: none;\n  /* Chrome/Safari/Opera */\n  -khtml-user-select: none;\n  /* Konqueror */\n  -moz-user-select: none;\n  /* Firefox */\n  -ms-user-select: none;\n  /* Internet Explorer/Edge */\n  user-select: none;\n}\n\n.tina-date-field .rdtPicker th.rdtDisabled,\n.rdtPicker th.rdtDisabled:hover {\n  background: none;\n  color: var(--tina-color-grey-6);\n  cursor: not-allowed;\n}\n\n.tina-date-field .rdtPicker thead tr:first-child th {\n  cursor: pointer;\n}\n\n.tina-date-field .rdtPicker thead tr:first-child th:hover {\n  background: var(--tina-color-grey-2);\n  color: var(--tina-color-primary);\n  border-radius: var(--tina-radius-small);\n}\n\n.tina-date-field .rdtPicker tfoot {\n  border-top: 1px solid var(--tina-color-grey-1);\n}\n\n.tina-date-field .rdtPicker button {\n  border: none;\n  background: none;\n  cursor: pointer;\n}\n\n.tina-date-field .rdtPicker button:hover {\n  background: var(--tina-color-grey-2);\n  color: var(--tina-color-primary);\n  border-radius: var(--tina-radius-small);\n}\n\n.tina-date-field .rdtPicker thead button {\n  width: 100%;\n  height: 100%;\n}\n\n.tina-date-field td.rdtMonth,\ntd.rdtYear {\n  height: 50px;\n  width: 25%;\n  cursor: pointer;\n}\n\n.tina-date-field td.rdtMonth:hover,\ntd.rdtYear:hover {\n  background: var(--tina-color-grey-2);\n  color: var(--tina-color-primary);\n  border-radius: var(--tina-radius-small);\n}\n\n.tina-date-field .rdtCounters {\n  display: inline-block;\n}\n\n.tina-date-field .rdtCounters > div {\n  float: left;\n}\n\n.tina-date-field .rdtCounter {\n  height: 100px;\n  width: 40px;\n}\n\n.tina-date-field .rdtCounterSeparator {\n  line-height: 100px;\n}\n\n.tina-date-field .rdtCounter .rdtBtn {\n  height: 40%;\n  line-height: 40px;\n  cursor: pointer;\n  display: block;\n  -webkit-touch-callout: none;\n  /* iOS Safari */\n  -webkit-user-select: none;\n  /* Chrome/Safari/Opera */\n  -khtml-user-select: none;\n  /* Konqueror */\n  -moz-user-select: none;\n  /* Firefox */\n  -ms-user-select: none;\n  /* Internet Explorer/Edge */\n  user-select: none;\n}\n\n.tina-date-field .rdtCounter .rdtBtn:hover {\n  background: var(--tina-color-grey-2);\n  color: var(--tina-color-primary);\n  border-radius: var(--tina-radius-small);\n}\n\n.tina-date-field .rdtCounter .rdtCount {\n  height: 20%;\n  font-size: 1.2em;\n}\n\n.tina-date-field .rdtMilli {\n  vertical-align: middle;\n  padding-left: 8px;\n  width: 48px;\n}\n\n.tina-date-field .rdtMilli input {\n  width: 100%;\n  font-size: 1.2em;\n  margin-top: 37px;\n}\n\n.tina-date-field .rdtTime td {\n  cursor: default;\n}\n"),d.createElement("div",{className:"tina-date-field",ref:e},d.createElement(il,{...a,isOpen:b})))},pm={__type:"field",name:"date",Component:nm,format:(a,b,c)=>{var d,e;if(!a)return a;const f="string"==typeof(d=c.dateFormat)?d:mm,g="string"==typeof(e=c.timeFormat)?e:e?"h:mm A":void 0,h="string"==typeof g?`${f} ${g}`:f;if("string"==typeof a){const i=C()(a);return i.isValid()?i.format(h):a}return C()(a).format(h)},parse:a=>{if(!a)return a;const b=new Date(a);return isNaN(b.getTime())?a:new Date(a).toISOString()},validate(a,b,c,d){if(d.required&&!a)return"Required"}},qm=Xa(Je),rm={name:"checkbox-group",Component:qm,validate(a,b,c,d){if(d.required&&null==a)return"Required"}},sm=Xa(_e),tm={name:"reference",type:"reference",Component:sm,parse:a=>a||"",validate(a,b,c,d){if(d.required&&!a)return"Required"}},um=Xa(af),vm={name:"button-toggle",Component:um},wm=()=>d.createElement(d.Fragment,null),xm={name:"hidden",Component:wm,parse:a=>a||""},ym=()=>d.createElement("div",{className:"relative flex flex-col items-center justify-center text-center p-5 pb-16 w-full h-full overflow-y-auto",style:{animationName:"fade-in",animationDelay:"300ms",animationTimingFunction:"ease-out",animationIterationCount:1,animationFillMode:"both",animationDuration:"150ms"}},d.createElement("p",{className:"block pb-5"},"Please wait while Tina",d.createElement("br",null),"loads your forms"),d.createElement(Kc,{color:"var(--tina-color-primary)"})),zm=({className:a="",...b})=>d.createElement("span",{className:`text-[24px] leading-none inline-block ${a}`,...b});class Am{constructor(Bm,Cm,Dm){this.form=Bm,this.__type="screen",this.name=Bm.label,this.Icon=Cm||function(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{fill:"none",d:"M0 0h24v24H0V0z"}},{tag:"path",attr:{d:"M19.43 12.98c.04-.32.07-.64.07-.98 0-.34-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46a.5.5 0 00-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65A.488.488 0 0014 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1a.566.566 0 00-.18-.03c-.17 0-.34.09-.43.25l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98 0 .33.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46a.5.5 0 00.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.06.02.12.03.18.03.17 0 .34-.09.43-.25l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zm-1.98-1.71c.04.31.05.52.05.73 0 .21-.02.43-.05.73l-.14 1.13.89.7 1.08.84-.7 1.21-1.27-.51-1.04-.42-.9.68c-.43.32-.84.56-1.25.73l-1.06.43-.16 1.13-.2 1.35h-1.4l-.19-1.35-.16-1.13-1.06-.43c-.43-.18-.83-.41-1.23-.71l-.91-.7-1.06.43-1.27.51-.7-1.21 1.08-.84.89-.7-.14-1.13c-.03-.31-.05-.54-.05-.74s.02-.43.05-.73l.14-1.13-.89-.7-1.08-.84.7-1.21 1.27.51 1.04.42.9-.68c.43-.32.84-.56 1.25-.73l1.06-.43.16-1.13.2-1.35h1.39l.19 1.35.16 1.13 1.06.43c.43.18.83.41 1.23.71l.91.7 1.06-.43 1.27-.51.7 1.21-1.07.85-.89.7.14 1.13zM12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm0 6c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"}}]})(a)},this.layout=Dm||"popup",this.Component=()=>{const a=Me(),b=a.state.forms.find(({tinaForm:a})=>a.id===Bm.id);return d.createElement(gd,{form:b})}}}function Em(a,b={}){const[c,e]=nc(a,b),f=(0,d.useMemo)(()=>{if(e)return new Am(e)},[e]);return lc(f),[c,e]}function Fm(a,b,c){const e=(0,d.useMemo)(()=>{if(a)return new Am(a,b,c)},[a,b,c]);lc(e)}const Gm={__type:"field",name:"markdown",Component:Im("Markdown")},Hm={__type:"field",name:"html",Component:Im("HTML")};function Im(a,b){return b=>d.createElement(Za,{name:b.input.name,label:`${a} Field not Registered`,tinaForm:b.tinaForm},d.createElement("p",{className:"whitespace-normal text-[15px] mt-2"},"The ",a," field is not registered. Some built-in field types are not bundled by default in an effort to control bundle size. Consult the Tina docs to learn how to use this field type."),d.createElement("p",{className:"whitespace-normal text-[15px] mt-2"},d.createElement("a",{className:"text-blue-500 underline",href:"https://tina.io/docs/editing/markdown/#registering-the-field-plugins",target:"_blank",rel:"noreferrer noopener"},"Tina Docs: Registering Field Plugins")))}function Jm({navigateNext:a,navigatePrev:b,hasNext:c,hasPrev:e,variant:f="white"}){return d.createElement("div",{className:"w-full flex flex-shrink-0 justify-end gap-2 items-center"},d.createElement(Fc,{variant:f,disabled:!e,onClick:b},d.createElement(Bd,{className:"w-6 h-full mr-2 opacity-70"})," Previous"),d.createElement(Fc,{variant:f,disabled:!c,onClick:a},"Next ",d.createElement(Id,{className:"w-6 h-full ml-2 opacity-70"})))}function Km({item:a,onClick:b,active:c}){const e="dir"===a.type?yd:xd,f=(a.thumbnails||{})["75x75"];return d.createElement("li",{className:`group relative flex shrink-0 items-center transition duration-150 ease-out cursor-pointer border-b border-gray-150 ${c?"bg-gradient-to-r from-white to-gray-50/50 text-blue-500 hover:bg-gray-50":"bg-white hover:bg-gray-50/50 hover:text-blue-500"}`,onClick:()=>{c?b(!1):b(a)}},a.new&&d.createElement("span",{className:"absolute top-1.5 left-1.5 rounded-full shadow bg-green-100 border border-green-200 text-[10px] tracking-wide\t font-bold text-green-600 px-1.5 py-0.5 z-10"},"NEW"),d.createElement("div",{className:"w-16 h-16 bg-gray-50 border-r border-gray-150 overflow-hidden flex justify-center flex-shrink-0"},Pe(f)?d.createElement("img",{className:"object-cover w-full h-full object-center origin-center transition-all duration-150 ease-out group-hover:scale-110",src:f,alt:a.filename}):d.createElement(e,{className:"w-1/2 h-full fill-gray-300"})),d.createElement("span",{className:"text-base flex-grow w-full break-words truncate px-3 py-2"},a.filename))}function Lm({item:a,active:b,onClick:c}){const e="dir"===a.type?yd:xd,f=(a.thumbnails||{})["400x400"];return d.createElement("li",{className:`relative pb-[100%] h-0 block border border-gray-100 rounded-md overflow-hidden flex justify-center shrink-0 w-full transition duration-150 ease-out ${b?"shadow-outline":"shadow hover:shadow-md hover:scale-103 hover:border-gray-150"} ${"dir"===a.type?"cursor-pointer":""}`},a.new&&d.createElement("span",{className:"absolute top-1.5 left-1.5 rounded-full shadow bg-green-100 border border-green-200 text-[10px] tracking-wide\t font-bold text-green-600 px-1.5 py-0.5 z-10"},"NEW"),d.createElement("button",{className:"absolute w-full h-full flex items-center justify-center bg-white",onClick:()=>{b?c(!1):c(a)}},Pe(f)?d.createElement("img",{className:"object-cover w-full h-full object-center",src:f,alt:a.filename}):d.createElement("div",{className:"p-4 w-full flex flex-col gap-4 items-center justify-center"},d.createElement(e,{className:"w-[30%] h-auto fill-gray-300"}),d.createElement("span",{className:"block text-base text-gray-600 w-full break-words truncate"},a.filename))))}const Mm=({className:a="",...b})=>d.createElement("button",{className:"capitalize transition-colors duration-150 border-0 bg-transparent hover:text-blue-500 "+a,...b});function Nm({directory:a="",setDirectory:b}){let c=function(a){var b,c;const d=new RegExp("(?<prevDir>.*)/");return null==(c=null==(b=a.match(d))?void 0:b.groups)?void 0:c.prevDir}(a=a.replace(/^\/|\/$/g,""))||"";return"."===c&&(c=""),d.createElement("div",{className:"w-full flex items-center text-[16px] text-gray-300"},""!==a&&d.createElement(Gc,{variant:"ghost",className:"mr-2",onClick:()=>b(c)},d.createElement(ca,{className:"w-7 h-auto fill-gray-300 hover:fill-gray-900 transition duration-150 ease-out"})),d.createElement(Mm,{onClick:()=>b(""),className:""===a?"text-gray-500 font-bold":"text-gray-300 font-medium after:pl-1.5 after:content-['/']"},"Media"),a&&a.split("/").map((a,c,e)=>{const f=e.slice(0,c+1).join("/");return d.createElement(Mm,{className:"pl-1.5 "+(c+1===e.length?"text-gray-500 font-bold":"text-gray-300 font-medium after:pl-1.5 after:content-['/']"),key:f,onClick:()=>{b(f)}},a)}))}const Om=({close:a,deleteFunc:b,filename:c})=>d.createElement(N,null,d.createElement(Pa,null,d.createElement(La,{close:a},"Delete ",c),d.createElement(P,{padded:!0},d.createElement("p",null,"Are you sure you want to delete ",d.createElement("strong",null,c),"?")),d.createElement(O,null,d.createElement(Fc,{style:{flexGrow:2},onClick:a},"Cancel"),d.createElement(Fc,{style:{flexGrow:3},variant:"danger",onClick:()=>{b(),a()}},"Delete")))),Pm=({onSubmit:a,close:b})=>{const[c,e]=d.useState("");return d.createElement(N,null,d.createElement(Pa,null,d.createElement(La,{close:b},"New Folder"),d.createElement(P,{padded:!0},d.createElement("p",{className:"text-base text-gray-700 mb-2"},"Please provide a name for your folder."),d.createElement("p",{className:"text-sm text-gray-500 mb-4 italic"},d.createElement("span",{className:"font-bold"},"Note")," – If you navigate away before uploading a media item, the folder will disappear."),d.createElement(Ke,{value:c,placeholder:"Folder Name",required:!0,onChange:a=>e(a.target.value)})),d.createElement(O,null,d.createElement(Fc,{style:{flexGrow:2},onClick:b},"Cancel"),d.createElement(Fc,{disabled:!c,style:{flexGrow:3},variant:"primary",onClick:()=>{c&&(a(c),b())}},"Create New Folder"))))},Qm=({label:a,description:b,value:c})=>{const[e,f]=d.useState(!1),[g,h]=d.useState(!1);return d.createElement("div",{className:"w-full"},a&&d.createElement("label",{className:"w-full mb-1 block flex-1  text-sm font-bold leading-5 text-gray-700"},a),d.createElement("span",{onClick:()=>{!0!==e&&(f(!0),setTimeout(()=>{h(!0)},2500),setTimeout(()=>{f(!1),h(!1)},3e3),navigator.clipboard.writeText(c))},className:`shadow-inner text-base leading-5 whitespace-normal break-all px-3 py-2 text-gray-600 w-full bg-gray-50 border border-gray-200 transition-all ease-out duration-150 rounded-md relative overflow-hidden appearance-none flex items-center w-full cursor-pointer hover:bg-white hover:text-blue-500  ${e?"pointer-events-none":""}`},d.createElement(rd,{className:"relative text-blue-500 shrink-0 w-5 h-auto mr-1.5 -ml-0.5 z-20"})," ",c," ",e&&d.createElement("span",{className:`${g?"opacity-0":"opacity-100"} text-blue-500 transition-opacity	duration-500 absolute right-0 w-full h-full px-3 py-2 bg-white bg-opacity-90 flex items-center justify-center text-center tracking-wide font-medium z-10`},d.createElement("span",null,"Copied to clipboard!"))),b&&d.createElement("p",{className:"mt-2 text-sm text-gray-500"},b))},Rm=function(...a){const[b,c,d]=[0,a.length-1,"/"],e=new RegExp("^"+d),f=new RegExp(d+"$");return(a=a.map(function(a,d){return d===b&&"file://"===a||(d>b&&(a=a.replace(e,"")),d<c&&(a=a.replace(f,""))),a})).join(d)};function Sm(){const a=Me(),[b,c]=(0,d.useState)();if((0,d.useEffect)(()=>a.events.subscribe("media:open",({type:a,...b})=>{c(b)}),[]),!b)return null;const e=()=>c(void 0);return d.createElement(N,null,d.createElement(Na,null,d.createElement("div",{className:"w-full bg-gray-50 flex items-center justify-between px-5 pt-3 m-0"},d.createElement("h2",{className:"text-gray-500 font-sans font-medium text-base leading-none m-0 block truncate"},"Media Manager"),d.createElement("div",{onClick:e,className:"flex items-center fill-gray-400 cursor-pointer transition-colors duration-100 ease-out hover:fill-gray-700"},d.createElement(U,{className:"w-6 h-auto"}))),d.createElement(P,{className:"flex h-full flex-col"},d.createElement(Um,{...b,close:e}))))}const Tm=new Uh({title:"Error fetching media",message:"Something went wrong while requesting the resource.",docsLink:"https://tina.io/docs/media/#media-store"});function Um({allowDelete:a,onSelect:b,close:c,...e}){const f=Me(),[g,h]=(0,d.useState)(()=>f.media.isConfigured?"loading":"not-configured"),[i,j]=d.useState(!1),[k,l]=d.useState(!1),[m,n]=(0,d.useState)(Tm),[o,p]=(0,d.useState)(e.directory),[q,r]=(0,d.useState)({items:[],nextOffset:void 0}),[s,t]=(0,d.useState)("grid"),[u,v]=(0,d.useState)(!1),[w,x]=(0,d.useState)([]),[z,A]=(0,d.useState)(""),B=w[w.length-1],C=()=>x([]),D=w.length>0,E=!!q.nextOffset;function F(){h("loading"),f.media.list({offset:B,limit:f.media.pageSize,directory:o,thumbnailSizes:[{w:75,h:75},{w:400,h:400},{w:1e3,h:1e3}]}).then(a=>{r(a),h("loaded")}).catch(a=>{console.error(a),"MediaListError"===a.ERR_TYPE?n(a):n(Tm),h("error")})}(0,d.useEffect)(()=>{if(f.media.isConfigured)return F(),f.events.subscribe(["media:delete:success","media:pageSize"],F)},[B,o,f.media.isConfigured]);const G=a=>{a?"dir"===a.type?(p("."===a.directory||""===a.directory?a.filename:Rm(a.directory,a.filename)),C()):v(a):v(!1)};let H;a&&(H=a=>{f.media.delete(a)});let I;b&&(I=a=>{b(a),c&&c()});const[J,K]=(0,d.useState)(!1),{getRootProps:L,getInputProps:M,isDragActive:N}=(0,y.useDropzone)({accept:Oe(f.media.accept||Ne),multiple:!0,onDrop:async(a,b)=>{try{K(!0);const c=await f.media.persist(a.map(a=>({directory:o||"/",file:a}))),e={"file-invalid-type":"Invalid file type","file-too-large":"File too large","file-too-small":"File too small","too-many-files":"Too many files"},g=a=>{const b=e[a.code];return b||(console.error(a),"Unknown error")};if(b.length>0){const h=[];b.map(a=>{h.push(`${a.file.name}: ${a.errors.map(a=>g(a)).join(", ")}`)}),f.alerts.error(()=>d.createElement(d.Fragment,null,"Upload Failed. ",d.createElement("br",null),h.join(". "),"."))}0!==c.length&&(v(c[0]),r(a=>({items:[...c.map(a=>({...a,new:!0})),...a.items],nextOffset:a.nextOffset})))}catch{}K(!1)}}),{onClick:O,...P}=L();if((0,d.useEffect)(function(){const a=null==document?void 0:document.body;return a.style.overflow="hidden",()=>{a.style.overflow="auto"}},[]),"loading"===g||J)return d.createElement(Xm,{extraText:z});if("not-configured"===g)return d.createElement(bn,{title:"No Media Store Configured",message:"To use the media manager, you need to configure a Media Store.",docsLink:"https://tina.io/docs/reference/media/overview/"});if("error"===g){const{title:Q,message:R,docsLink:S}=m;return d.createElement(bn,{title:Q,message:R,docsLink:S})}return d.createElement(d.Fragment,null,i&&d.createElement(Om,{filename:u?u.filename:"",deleteFunc:()=>{u&&(H(u),v(!1))},close:()=>j(!1)}),k&&d.createElement(Pm,{onSubmit:a=>{p(b=>b?Rm(b,a):a),C()},close:()=>l(!1)}),d.createElement(Ym,null,d.createElement($m,null,d.createElement("div",{className:"flex flex-wrap items-center bg-gray-50 border-b border-gray-150 gap-4 py-3 px-5 shadow-sm flex-shrink-0"},d.createElement("div",{className:"flex flex-1 items-center gap-4"},d.createElement(cn,{viewMode:s,setViewMode:t}),d.createElement(Nm,{directory:o,setDirectory:p})),d.createElement("div",{className:"flex flex-wrap items-center gap-4"},d.createElement(Fc,{busy:!1,variant:"white",onClick:F,className:"whitespace-nowrap"},"Refresh",d.createElement(dd,{className:"w-6 h-full ml-2 opacity-70 text-blue-500"})),d.createElement(Fc,{busy:!1,variant:"white",onClick:()=>{l(!0)},className:"whitespace-nowrap"},"New Folder",d.createElement(yd,{className:"w-6 h-full ml-2 opacity-70 text-blue-500"})),d.createElement(Wm,{onClick:O,uploading:J}))),d.createElement("div",{className:"flex h-full overflow-hidden bg-white"},d.createElement("div",{className:"flex w-full flex-col h-full @container"},d.createElement("ul",{...P,className:`h-full grow overflow-y-auto transition duration-150 ease-out bg-gradient-to-b from-gray-50/50 to-gray-50 ${0===q.items.length||"list"===s&&"w-full flex flex-1 flex-col justify-start -mb-px"} ${q.items.length>0&&"grid"===s&&"w-full p-4 gap-4 grid grid-cols-1 @sm:grid-cols-2 @lg:grid-cols-3 @2xl:grid-cols-4 @4xl:grid-cols-6 @6xl:grid-cols-8 auto-rows-auto content-start justify-start"} ${N?"border-2 border-blue-500 rounded-lg":""}`},d.createElement("input",{...M()}),"loaded"===g&&0===q.items.length&&d.createElement(an,null),"list"===s&&q.items.map(a=>d.createElement(Km,{key:a.id,item:a,onClick:G,active:u&&u.id===a.id})),"grid"===s&&q.items.map(a=>d.createElement(Lm,{key:a.id,item:a,onClick:G,active:u&&u.id===a.id}))),d.createElement("div",{className:"bg-gradient-to-r to-gray-50/50 from-gray-50 shrink-0 grow-0 border-t border-gray-150 py-3 px-5 shadow-sm z-10"},d.createElement(Jm,{hasNext:E,navigateNext:()=>{q.nextOffset&&x([...w,q.nextOffset])},hasPrev:D,navigatePrev:()=>{const a=w.slice(0,w.length-1);x(a)}}))),d.createElement(Vm,{activeItem:u,close:()=>v(!1),selectMediaItem:I,allowDelete:a,deleteMediaItem:()=>{j(!0)}})))))}const Vm=({activeItem:a,close:b,selectMediaItem:c,deleteMediaItem:e,allowDelete:f})=>{const g=a?(a.thumbnails||{})["1000x1000"]:"";return d.createElement("div",{className:`shrink-0 h-full flex flex-col items-start gap-3 overflow-y-auto bg-white border-l border-gray-100 bg-white shadow-md transition ease-out duration-150 ${a?"p-4 opacity-100 w-[35%] max-w-[560px] min-w-[240px]":"translate-x-8 opacity-0 w-[0px]"}`},a&&d.createElement(d.Fragment,null,d.createElement("div",{className:"flex grow-0 shrink-0 gap-2 w-full items-center justify-between"},d.createElement("h3",{className:"text-lg text-gray-600 w-full max-w-full break-words block truncate flex-1"},a.filename),d.createElement(Gc,{variant:"ghost",className:"group grow-0 shrink-0",onClick:b},d.createElement(Kd,{className:"w-7 h-auto text-gray-500 opacity-50 group-hover:opacity-100 transition duration-150 ease-out"}))),Pe(g)?d.createElement("div",{className:"w-full max-h-[75%]"},d.createElement("img",{className:"block border border-gray-100 rounded-md overflow-hidden max-w-full max-h-full object-fit h-auto shadow",src:g,alt:a.filename})):d.createElement("span",{className:"p-3 border border-gray-100 rounded-md overflow-hidden bg-gray-50 shadow"},d.createElement(xd,{className:"w-14 h-auto fill-gray-300"})),d.createElement("div",{className:"grow h-full w-full shrink flex flex-col gap-3 items-start justify-start"},d.createElement(Qm,{value:Qe(a.src),label:"URL"})),d.createElement("div",{className:"shrink-0 w-full flex flex-col justify-end items-start"},d.createElement("div",{className:"flex w-full gap-3"},c&&d.createElement(Fc,{size:"medium",variant:"primary",className:"grow",onClick:()=>c(a)},"Insert",d.createElement(md,{className:"ml-1 -mr-0.5 w-6 h-auto text-white opacity-70"})),f&&d.createElement(Fc,{variant:"white",size:"medium",className:"grow max-w-[40%]",onClick:e},"Delete",d.createElement(oa,{className:"ml-1 -mr-0.5 w-6 h-auto text-red-500 opacity-70"}))))))},Wm=({onClick:a,uploading:b})=>d.createElement(Fc,{variant:"primary",size:"custom",className:"text-sm h-10 px-6",busy:b,onClick:a},b?d.createElement(Kc,null):d.createElement(d.Fragment,null,"Upload ",d.createElement(qd,{className:"w-6 h-full ml-2 opacity-70"}))),Xm=a=>d.createElement("div",{className:"w-full h-full flex flex-col items-center justify-center",...a},a.extraText&&d.createElement("p",null,a.extraText),d.createElement(Kc,{color:"var(--tina-color-primary)"})),Ym=({children:a})=>d.createElement("div",{className:"h-full flex-1 text-gray-700 flex flex-col relative bg-gray-50 outline-none active:outline-none focus:outline-none"},a),Zm=(0,d.createContext)(void 0),$m=({children:a})=>{var b,c,e;const f=Me(),g=f.api.tina.isLocalMode,h=(null==(e=null==(c=null==(b=f.api.tina.schema.schema)?void 0:b.config)?void 0:c.media)?void 0:e.tina)||{},i=!!(h.mediaRoot||h.publicFolder),j=i&&!g,[k,l]=(0,d.useState)(j?"loading":"synced");return(0,d.useEffect)(()=>{const a=async()=>{if(j){const a=await f.api.tina.getProject();l(a.mediaBranch?"synced":"needs-sync")}};a()},[]),"needs-sync"==k?d.createElement("div",{className:"h-full flex items-center justify-center p-6 bg-gradient-to-t from-gray-200 to-transparent"},d.createElement("div",{className:"rounded-lg border shadow-sm px-4 lg:px-6 py-3 lg:py-4 bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-200 mx-auto mb-12"},d.createElement("div",{className:"flex items-start sm:items-center gap-2"},d.createElement(td,{className:"w-7 h-auto flex-shrink-0 text-yellow-400 -mt-px"}),d.createElement("div",{className:"flex-1 flex flex-col items-start gap-0.5 text-base text-yellow-700"},"Media needs to be turned on for this project.",d.createElement("a",{className:"transition-all duration-150 ease-out text-blue-500 hover:text-blue-400 hover:underline underline decoration-blue-200 hover:decoration-blue-400 font-medium flex items-center justify-start gap-1",target:"_blank",href:`${f.api.tina.appDashboardLink}/media`},"Sync Your Media In Tina Cloud.",d.createElement(Cd,{className:"w-5 h-auto flex-shrink-0"})))))):d.createElement(Zm.Provider,{value:{syncStatus:k}},a)},_m=()=>{const a=(0,d.useContext)(Zm);if(!a)throw new Error("useSyncStatus must be used within a SyncStatusProvider");return a},an=()=>{const{syncStatus:a}=_m();return d.createElement("div",{className:"p-12 text-xl opacity-50 text-center"},"synced"==a?"Drag and drop assets here":"Loading...")},bn=({title:a,message:b,docsLink:c,...e})=>d.createElement("div",{className:"h-3/4 text-center flex flex-col justify-center",...e},d.createElement("h2",{className:"mb-3 text-xl text-gray-600"},a),d.createElement("div",{className:"mb-3 text-base text-gray-700"},b),d.createElement("a",{href:c,target:"_blank",rel:"noreferrer noopener",className:"font-bold text-blue-500 hover:text-blue-600 hover:underline transition-all ease-out duration-150"},"Learn More")),cn=({viewMode:a,setViewMode:b})=>{const c={base:"relative whitespace-nowrap flex items-center justify-center flex-1 block font-medium text-base py-1 transition-all ease-out duration-150 border",active:"bg-white text-blue-500 shadow-inner border-gray-50 border-t-gray-100",inactive:"bg-gray-50 text-gray-400 shadow border-gray-100 border-t-white"};return d.createElement("div",{className:"grow-0 flex justify-between rounded-md border border-gray-100"},d.createElement("button",{className:`${c.base} px-2.5 rounded-l-md ${"grid"===a?c.active:c.inactive}`,onClick:()=>{b("grid")}},d.createElement(Ad,{className:"w-6 h-full opacity-70"})),d.createElement("button",{className:`${c.base} px-2 rounded-r-md ${"list"===a?c.active:c.inactive}`,onClick:()=>{b("list")}},d.createElement(Dd,{className:"w-8 h-full opacity-70"})))},dn=Ii({name:"Media Manager",Component:Um,Icon:function(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{fill:"none",d:"M0 0h24v24H0V0z"}},{tag:"path",attr:{d:"M20 4v12H8V4h12m0-2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 9.67l1.69 2.26 2.48-3.1L19 15H9zM2 6v14c0 1.1.9 2 2 2h14v-2H4V6H2z"}}]})(a)},layout:"fullscreen",props:{allowDelete:!0}});function en({...a}){return{__type:"cloud-config",Icon:Ae,...a}}class fn extends mi{constructor({sidebar:gn,alerts:hn={},isLocalClient:jn,clientId:kn,...ln}={}){if(super(ln),this.alerts.setMap({"media:upload:failure":a=>({error:a.error,level:"error",message:`Failed to upload file(s) ${null==a?void 0:a.uploaded.map(a=>a.file.name).join(", ")}. See error message: 

 ${null==a?void 0:a.error.toString()}`}),"media:delete:failure":()=>({level:"error",message:"Failed to delete file."}),...hn}),gn){const mn="object"==typeof gn?gn:void 0;this.sidebar=new class{constructor(nn,on={}){var pn,qn;this.events=nn,this._isOpen=!1,this.position="displace",this.renderNav=!0,this.buttons={save:"Save",reset:"Reset"},this.position=on.position||"displace",this.renderNav=on.renderNav||!0,this.placeholder=on.placeholder||(()=>d.createElement("div",{className:"relative flex flex-col items-center justify-center text-center p-5 pb-16 w-full h-full overflow-y-auto",style:{animationName:"fade-in",animationDelay:"300ms",animationTimingFunction:"ease-out",animationIterationCount:1,animationFillMode:"both",animationDuration:"150ms"}},d.createElement(zm,{className:"pb-5"},"🔎"),d.createElement("p",{className:"block pb-5"},"Looks like there's ",d.createElement("br",null),"nothing to edit on ",d.createElement("br",null),"this page."),d.createElement("p",{className:"block"},d.createElement(Fc,{href:"https://tina.io/docs/tinacms-context/",target:"_blank",as:"a"},d.createElement(zm,{className:"mr-1.5"},"📖")," Contextual Editing")))),(null==(pn=on.buttons)?void 0:pn.save)&&(this.buttons.save=on.buttons.save),(null==(qn=on.buttons)?void 0:qn.reset)&&(this.buttons.reset=on.buttons.reset)}get isOpen(){return this._isOpen}set isOpen(rn){this._isOpen!==rn&&(this._isOpen=rn,rn?this.events.dispatch({type:"sidebar:opened"}):this.events.dispatch({type:"sidebar:closed"}))}subscribe(sn){const tn=this.events.subscribe("sidebar",sn);return()=>tn()}}(this.events,mn)}[yj,wj,oj,jj,qj,Aj,sj,Zf,uj,Rd,Zi,mj,hj,Dj,pm,Gm,Hm,rm,tm,vm,xm].forEach(a=>{this.fields.find(a.name)||this.fields.add(a)}),this.plugins.add(dn),!0!==jn&&(kn?(this.plugins.add(en({name:"Project Config",link:{text:"Project Config",href:`https://app.tina.io/projects/${kn}/overview`}})),this.plugins.add(en({name:"User Management",link:{text:"User Management",href:`https://app.tina.io/projects/${kn}/collaborators`}}))):this.plugins.add(en({name:"Setup Cloud",text:"No project configured, set one up ",link:{text:"here",href:"https://app.tina.io"}})))}get alerts(){return this._alerts||(this._alerts=new ni(this.events)),this._alerts}registerApi(un,vn){vn.alerts&&this.alerts.setMap(vn.alerts),super.registerApi(un,vn)}get forms(){return this.plugins.findOrCreateMap("form")}get fields(){return this.plugins.findOrCreateMap("field")}get screens(){return this.plugins.findOrCreateMap("screen")}removeAllForms(){this.forms.all().forEach(a=>{this.forms.remove(a)})}removeOrphanedForms(){const wn=this.forms.all().filter(a=>0===a.queries.length);wn.forEach(a=>{this.forms.remove(a)})}}const xn=a=>{var b;return{activeFormId:null,forms:[],formLists:[],editingMode:"basic",quickEditSupported:!1,sidebarDisplayState:(null==(b=null==a?void 0:a.sidebar)?void 0:b.defaultState)||"open"}};function yn(a,b){switch(b.type){case"set-quick-editing-supported":return{...a,quickEditSupported:b.value};case"set-edit-mode":return{...a,editingMode:b.value};case"forms:add":if(a.forms.find(a=>a.tinaForm.id===b.value.id))return a;return{...a,forms:[...a.forms,{tinaForm:b.value}]};case"forms:remove":return{...a,forms:a.forms.filter(a=>a.tinaForm.id!==b.value)};case"form-lists:clear":return{...a,quickEditSupported:!1,formLists:[],forms:[]};case"form-lists:add":{let c=!1;const d=a.formLists.map(a=>a.id===b.value.id?(c=!0,b.value):a);c||d.push(b.value);let e=a.activeFormId;return e||0!==a.formLists.length||b.value.items.forEach(b=>{if("document"===b.type){const c=a.forms.find(({tinaForm:a})=>b.formId===a.id);c.tinaForm.global||(e=b.formId)}}),{...a,activeFormId:e,formLists:d}}case"form-lists:remove":{const f=a.formLists.filter(({id:a})=>a!==b.value),g=[];f.forEach(a=>{a.formIds.forEach(a=>{g.push(a)})});const h=a.forms.filter(({tinaForm:a})=>g.includes(a.id));return{...a,quickEditSupported:!1,activeFormId:null,forms:h,formLists:f}}case"forms:set-active-form-id":if(b.value!==a.activeFormId)return{...a,activeFormId:b.value};return a;case"forms:set-active-field-name":const i=a.forms.map(a=>a.tinaForm.id===b.value.formId?{tinaForm:a.tinaForm,activeFieldName:b.value.fieldName}:a);return{...a,forms:i,activeFormId:b.value.formId};case"toggle-edit-state":return"closed"===a.sidebarDisplayState?{...a,sidebarDisplayState:"open"}:{...a,sidebarDisplayState:"closed"};case"sidebar:set-display-state":if("openOrFull"===b.value){if("closed"===a.sidebarDisplayState)return{...a,sidebarDisplayState:"open"};return a}if("open"===b.value)return{...a,sidebarDisplayState:b.value};return{...a,sidebarDisplayState:b.value};default:throw new Error(`Unhandled action ${b.type}`)}}const zn=({cms:a,children:b})=>{const[c,e]=d.useReducer(yn,a,xn);if(!(a instanceof fn))throw new Error("The `cms` prop must be an instance of `TinaCMS`.");return d.createElement(Sa.Provider,{value:{cms:a,state:c,dispatch:e}},b)};function An({alerts:a}){return(sc(a),a.all.length)?d.createElement(d.Fragment,null,d.createElement("div",{className:"fixed bottom-0 left-0 right-0 p-6 flex flex-col items-center z-[999999] pointer-events-none"},a.all.filter(a=>"error"!==a.level).map(b=>d.createElement(Bn,{key:b.id,level:b.level},"info"===b.level&&d.createElement(Da,{className:"w-5 h-5 mr-2"}),"success"===b.level&&d.createElement(Ca,{className:"w-5 h-5 mr-2"}),"warn"===b.level&&d.createElement(Ea,{className:"w-5 h-5 mr-2"}),d.createElement("p",{className:"m-0 flex-1 max-w-[680px] text-left"},b.message),d.createElement(Cn,{onClick:()=>{a.dismiss(b)}})))),a.all.filter(a=>"error"===a.level).map(b=>{const c="string"==typeof b.message?()=>d.createElement("p",{className:"text-base mb-3 overflow-y-auto"},b.message):b.message;return d.createElement(N,{key:b.id},d.createElement(Pa,null,d.createElement(La,{close:()=>{a.dismiss(b)}},d.createElement(Fa,{className:"mr-1 w-6 h-auto fill-current inline-block text-red-600"})," ","Error"),d.createElement(P,{padded:!0},d.createElement("div",{className:"tina-prose"},d.createElement(c,null))),d.createElement(O,null,d.createElement("div",{className:"flex-1"}),d.createElement(Fc,{style:{flexGrow:1},onClick:()=>{a.dismiss(b)}},"Close"))))})):null}const Bn=({level:a,...b})=>d.createElement("div",{className:"text-center rounded-[5px] bg-gray-50 border border-solid border-gray-100 text-gray-800 fill-blue-500 font-normal cursor-pointer text-[15px] py-2 pr-1 pl-3 transition-all duration-100 ease-out mb-4 flex items-center min-w-[350px] max-w-full ",style:{pointerEvents:"all",animationName:"fly-in-up, fade-in",animationTimingFunction:"ease-out",animationIterationCount:1,animationFillMode:"both",animationDuration:"150ms",fill:{info:"var(--tina-color-primary)",success:"var(--tina-color-success)",warn:"var(--tina-color-dark)",error:"var(--tina-color-error)"}[a],borderLeft:`6px solid ${{info:"var(--tina-color-primary)",success:"var(--tina-color-success)",warn:"var(--tina-color-warning)",error:"var(--tina-color-error)"}[a]}`},...b}),Cn=({...a})=>d.createElement("button",{className:"border-none bg-transparent p-0 ml-[14px] outline-none fill-gray-400 flex items-center",...a},d.createElement(U,{className:"w-5 h-5 flex-grow-0 flex-shrink-0 basis-[auto] mr-2"})),Dn=d.createContext(-1),En=({children:a})=>{const b=d.useRef(null),[c,e]=d.useState(0);return d.useEffect(()=>{if(!b)return;const a=new MutationObserver(()=>e(a=>a+1));return a.observe(b.current,{childList:!0,subtree:!0,characterData:!0}),()=>a.disconnect()},[]),d.createElement(Dn.Provider,{value:c},d.createElement("div",{ref:b},a))},Fn=a=>{const b=d.useContext(Dn),[c,e]=d.useState(null);return d.useEffect(()=>{let b;const c=document.getElementById("tina-iframe");b=c?c.contentDocument:document;const d=b.querySelector(`[data-tinafield="${a}"]`);if(d)e(d);else if(null==a?void 0:a.includes("#")){const f=a.split("#")[1],g=b.querySelector(`[data-tinafield="${f}"]`);e(g)}},[b,a]),c},Gn=({style:a={},position:b,...c})=>d.createElement("div",{className:"fixed left-0 py-2 px-0 text-center",style:{...a,marginLeft:"var(--tina-sidebar-width)",width:"calc(100% - var(--tina-sidebar-width))",top:"top"===b?0:"auto",bottom:"top"===b?"auto":0,zIndex:"var(--tina-z-index-3)"},...c}),Hn=a=>d.createElement("div",{className:"inline-block fill-white rounded-[50%] bg-blue-500 shadow-md",...a}),In=()=>d.createElement(Gn,{position:"top"},d.createElement(Hn,null,d.createElement(Z,{className:"w-8 h-auto"}))),Jn=()=>d.createElement(Gn,{position:"bottom"},d.createElement(Hn,null,d.createElement(Y,{className:"w-8 h-auto"}))),Kn=()=>{const{subscribe:a}=Wa("field:focus");d.useEffect(()=>a(({fieldName:a})=>{const b=document.querySelector(`[data-tinafield="${a}"]`);if(!b)return;const{top:c,height:d}=b.getBoundingClientRect(),e=c+window.scrollY,f=c+d+window.scrollY,g=window.scrollY,h=window.innerHeight+window.scrollY;d<window.innerHeight?f>h?window.scrollTo({top:f-window.innerHeight,behavior:"smooth"}):e<g&&window.scrollTo({top:e,behavior:"smooth"}):f<h?window.scrollTo({top:f-window.innerHeight,behavior:"smooth"}):e>g&&window.scrollTo({top:e,behavior:"smooth"})}))},Ln=()=>{const[a,b]=d.useState(null),[c,e]=d.useState(!1),[f,g]=d.useState(!1),[h,i]=d.useState({left:0}),j=Fn(a);d.useEffect(()=>{let a;if(j){e(!0),g(j.getBoundingClientRect());const b=document.getElementById("tina-iframe");b&&i(b.getBoundingClientRect())}else a=setTimeout(()=>{e(!1)},150);return()=>{clearTimeout(a)}},[j]);const[,k]=d.useState(0),l=()=>k(a=>a+1);d.useEffect(()=>(window.addEventListener("scroll",l),()=>{window.removeEventListener("scroll",l)}),[]);const{subscribe:m}=Wa("field:hover");if(d.useEffect(()=>m(({fieldName:a,id:c})=>{b(`${c}#${a}`)})),Kn(),!c)return null;const n=f.top+window.scrollY,o=f.top+f.height+window.scrollY,p=window.scrollY,q=window.innerHeight+window.scrollY;return n>q?d.createElement(Jn,null):o<p?d.createElement(In,null):d.createElement("div",{style:{position:"absolute",zIndex:"var(--tina-z-index-3)",top:f.top+window.scrollY,left:f.left+window.scrollX+h.left,width:f.width,height:f.height,outline:"2px dashed var(--tina-color-indicator)",borderRadius:"var(--tina-radius-small)",transition:c?j?"opacity 300ms ease-out":"opacity 150ms ease-in":"none",opacity:j&&c?.8:0}})};var Mn=`:root {
  --tina-color-primary-light: #2296fe;
  --tina-color-primary: #0084ff;
  --tina-color-primary-dark: #0574e4;
  --tina-color-error-light: #eb6337;
  --tina-color-error: #ec4815;
  --tina-color-error-dark: #dc4419;
  --tina-color-warning-light: #f5e06e;
  --tina-color-warning: #e9d050;
  --tina-color-warning-dark: #d3ba38;
  --tina-color-success-light: #57c355;
  --tina-color-success: #3cad3a;
  --tina-color-success-dark: #249a21;
  --tina-color-grey-0: #ffffff;
  --tina-color-grey-1: #f6f6f9;
  --tina-color-grey-2: #edecf3;
  --tina-color-grey-3: #e1ddec;
  --tina-color-grey-4: #b2adbe;
  --tina-color-grey-5: #918c9e;
  --tina-color-grey-6: #716c7f;
  --tina-color-grey-7: #565165;
  --tina-color-grey-8: #433e52;
  --tina-color-grey-9: #363145;
  --tina-color-grey-10: #252336;
  --tina-color-indicator: var(--tina-color-primary);

  --tina-radius-small: 5px;
  --tina-radius-big: 24px;

  --tina-padding-small: 12px;
  --tina-padding-big: 20px;

  --tina-font-size-0: 12px;
  --tina-font-size-1: 13px;
  --tina-font-size-2: 15px;
  --tina-font-size-3: 16px;
  --tina-font-size-4: 18px;
  --tina-font-size-5: 20px;
  --tina-font-size-6: 22px;
  --tina-font-size-7: 26px;
  --tina-font-size-8: 32px;

  --tina-font-family: 'Inter', sans-serif;

  --tina-font-weight-regular: 400;
  --tina-font-weight-bold: 600;

  --tina-shadow-big: 0px 2px 3px rgba(0, 0, 0, 0.05),
    0 4px 12px rgba(0, 0, 0, 0.1);
  --tina-shadow-small: 0px 2px 3px rgba(0, 0, 0, 0.12);

  --tina-timing-short: 85ms;
  --tina-timing-medium: 150ms;
  --tina-timing-long: 250ms;

  --tina-z-index-0: 0;
  --tina-z-index-1: 10;
  --tina-z-index-2: 20;
  --tina-z-index-3: 30;
  --tina-z-index-4: 40;
  --tina-z-index-5: 50;

  --tina-sidebar-width: 340px;
  --tina-sidebar-header-height: 60px;
  --tina-toolbar-height: 62px;
}

@keyframes fly-in-left {
  0% {
    transform: translate3d(100%, 0, 0);
  }

  100% {
    transform: translate3d(0, 0, 0);
  }
}

@keyframes fly-in-up {
  0% {
    transform: translate3d(0, 100%, 0);
  }

  100% {
    transform: translate3d(0, 0, 0);
  }
}

@keyframes fade-in {
  0% {
    opacity: 0;
  }

  100% {
    opacity: 1;
  }
}

@keyframes popup-right {
  0% {
    transform: translate3d(-2rem, 0, 0);
    opacity: 0;
  }

  100% {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
}

@keyframes popup-down {
  0% {
    transform: translate3d(0, -2rem, 0);
    opacity: 0;
  }

  100% {
    transform: translate3d(0, 0, 0);
    opacity: 1;
  }
}

.tina-tailwind {
  line-height: 1.5;
  -webkit-text-size-adjust: 100%;
  -moz-tab-size: 4;
  tab-size: 4;
}

.tina-tailwind *,
  .tina-tailwind ::before,
  .tina-tailwind ::after {
    box-sizing: border-box;
    border-width: 0;
    border-style: solid;
    border-color: transparent;
  }

.tina-tailwind ::before,
  .tina-tailwind ::after {
    --tw-content: '';
  }

.tina-tailwind hr {
    height: 0; /* 1 */
    color: inherit; /* 2 */
    border-top-width: 1px; /* 3 */
  }

.tina-tailwind abbr:where([title]) {
    text-decoration: underline dotted;
  }

.tina-tailwind h1,
  .tina-tailwind h2,
  .tina-tailwind h3,
  .tina-tailwind h4,
  .tina-tailwind h5,
  .tina-tailwind h6 {
    font-size: inherit;
    font-weight: inherit;
  }

.tina-tailwind a {
    color: inherit;
    text-decoration: inherit;
  }

.tina-tailwind b,
  .tina-tailwind strong {
    font-weight: bolder;
  }

.tina-tailwind code,
  .tina-tailwind kbd,
  .tina-tailwind samp,
  .tina-tailwind pre {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; /* 1 */
    font-size: 1em; /* 2 */
  }

.tina-tailwind small {
    font-size: 80%;
  }

.tina-tailwind sub,
  .tina-tailwind sup {
    font-size: 75%;
    line-height: 0;
    position: relative;
    vertical-align: baseline;
  }

.tina-tailwind sub {
    bottom: -0.25em;
  }

.tina-tailwind sup {
    top: -0.5em;
  }

.tina-tailwind table {
    text-indent: 0; /* 1 */
    border-color: inherit; /* 2 */
    border-collapse: collapse; /* 3 */
  }

.tina-tailwind button,
  .tina-tailwind input,
  .tina-tailwind optgroup,
  .tina-tailwind select,
  .tina-tailwind textarea {
    font-family: inherit; /* 1 */
    font-size: 100%; /* 1 */
    line-height: inherit; /* 1 */
    color: inherit; /* 1 */
    margin: 0; /* 2 */
    padding: 0; /* 3 */
  }

.tina-tailwind button,
  .tina-tailwind select {
    text-transform: none;
  }

.tina-tailwind button,
  .tina-tailwind [type='button'],
  .tina-tailwind [type='reset'],
  .tina-tailwind [type='submit'] {
    -webkit-appearance: button; /* 1 */
    background-color: transparent; /* 2 */
    background-image: none; /* 2 */
  }

.tina-tailwind :-moz-focusring {
    outline: auto;
  }

.tina-tailwind :-moz-ui-invalid {
    box-shadow: none;
  }

.tina-tailwind progress {
    vertical-align: baseline;
  }

.tina-tailwind ::-webkit-inner-spin-button,
  .tina-tailwind ::-webkit-outer-spin-button {
    height: auto;
  }

.tina-tailwind [type='search'] {
    -webkit-appearance: textfield; /* 1 */
    outline-offset: -2px; /* 2 */
  }

.tina-tailwind ::-webkit-search-decoration {
    -webkit-appearance: none;
  }

.tina-tailwind ::-webkit-file-upload-button {
    -webkit-appearance: button; /* 1 */
    font: inherit; /* 2 */
  }

.tina-tailwind summary {
    display: list-item;
  }

.tina-tailwind blockquote,
  .tina-tailwind dl,
  .tina-tailwind dd,
  .tina-tailwind h1,
  .tina-tailwind h2,
  .tina-tailwind h3,
  .tina-tailwind h4,
  .tina-tailwind h5,
  .tina-tailwind h6,
  .tina-tailwind hr,
  .tina-tailwind figure,
  .tina-tailwind p,
  .tina-tailwind pre {
    margin: 0;
  }

.tina-tailwind fieldset {
    margin: 0;
    padding: 0;
  }

.tina-tailwind legend {
    padding: 0;
  }

.tina-tailwind ol,
  .tina-tailwind ul,
  .tina-tailwind menu {
    list-style: none;
    margin: 0;
    padding: 0;
  }

.tina-tailwind li:before {
    display: none;
  }

.tina-tailwind textarea {
    resize: vertical;
  }

.tina-tailwind input::placeholder,
  .tina-tailwind textarea::placeholder {
    opacity: 1; /* 1 */
    color: #918c9e; /* 2 */
  }

.tina-tailwind button,
  .tina-tailwind [role='button'] {
    cursor: pointer;
  }

.tina-tailwind :disabled {
    cursor: default;
  }

.tina-tailwind img,
  .tina-tailwind svg,
  .tina-tailwind video,
  .tina-tailwind canvas,
  .tina-tailwind audio,
  .tina-tailwind iframe,
  .tina-tailwind embed,
  .tina-tailwind object {
    display: block; /* 1 */
    vertical-align: middle; /* 2 */
  }

.tina-tailwind img,
  .tina-tailwind video {
    max-width: 100%;
    height: auto;
  }

.tina-tailwind [hidden] {
    display: none;
  }

*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(0 132 255 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
}

::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(0 132 255 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
}

.container {
  width: 100%;
}

@media (min-width: 320px) {

  .container {
    max-width: 320px;
  }
}

@media (min-width: 560px) {

  .container {
    max-width: 560px;
  }
}

@media (min-width: 720px) {

  .container {
    max-width: 720px;
  }
}

@media (min-width: 1030px) {

  .container {
    max-width: 1030px;
  }
}

@media (min-width: 1280px) {

  .container {
    max-width: 1280px;
  }
}

@media (min-width: 1536px) {

  .container {
    max-width: 1536px;
  }
}

.tina-prose {
  color: var(--tw-prose-body);
  max-width: 65ch;
}

.tina-prose :where([class~="lead"]):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-lead);
  font-size: 1.25em;
  line-height: 1.6;
  margin-top: 1.2em;
  margin-bottom: 1.2em;
}

.tina-prose :where(a):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-links);
  text-decoration: underline;
  font-weight: 500;
}

.tina-prose :where(strong):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-bold);
  font-weight: 600;
}

.tina-prose :where(ol):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: decimal;
  padding-left: 1.625em;
}

.tina-prose :where(ol[type="A"]):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: upper-alpha;
}

.tina-prose :where(ol[type="a"]):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: lower-alpha;
}

.tina-prose :where(ol[type="A" s]):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: upper-alpha;
}

.tina-prose :where(ol[type="a" s]):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: lower-alpha;
}

.tina-prose :where(ol[type="I"]):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: upper-roman;
}

.tina-prose :where(ol[type="i"]):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: lower-roman;
}

.tina-prose :where(ol[type="I" s]):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: upper-roman;
}

.tina-prose :where(ol[type="i" s]):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: lower-roman;
}

.tina-prose :where(ol[type="1"]):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: decimal;
}

.tina-prose :where(ul):not(:where([class~="not-tina-prose"] *)) {
  list-style-type: disc;
  padding-left: 1.625em;
}

.tina-prose :where(ol > li):not(:where([class~="not-tina-prose"] *))::marker {
  font-weight: 400;
  color: var(--tw-prose-counters);
}

.tina-prose :where(ul > li):not(:where([class~="not-tina-prose"] *))::marker {
  color: var(--tw-prose-bullets);
}

.tina-prose :where(hr):not(:where([class~="not-tina-prose"] *)) {
  border-color: var(--tw-prose-hr);
  border-top-width: 1px;
  margin-top: 3em;
  margin-bottom: 3em;
}

.tina-prose :where(blockquote):not(:where([class~="not-tina-prose"] *)) {
  font-weight: 500;
  font-style: italic;
  color: var(--tw-prose-quotes);
  border-left-width: 0.25rem;
  border-left-color: var(--tw-prose-quote-borders);
  quotes: "\\201C""\\201D""\\2018""\\2019";
  margin-top: 1.6em;
  margin-bottom: 1.6em;
  padding-left: 1em;
}

.tina-prose :where(blockquote p:first-of-type):not(:where([class~="not-tina-prose"] *))::before {
  content: open-quote;
}

.tina-prose :where(blockquote p:last-of-type):not(:where([class~="not-tina-prose"] *))::after {
  content: close-quote;
}

.tina-prose :where(h1):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 800;
  font-size: 2.25em;
  margin-top: 0;
  margin-bottom: 0.8888889em;
  line-height: 1.1111111;
}

.tina-prose :where(h1 strong):not(:where([class~="not-tina-prose"] *)) {
  font-weight: 900;
}

.tina-prose :where(h2):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 700;
  font-size: 1.5em;
  margin-top: 2em;
  margin-bottom: 1em;
  line-height: 1.3333333;
}

.tina-prose :where(h2 strong):not(:where([class~="not-tina-prose"] *)) {
  font-weight: 800;
}

.tina-prose :where(h3):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  font-size: 1.25em;
  margin-top: 1.6em;
  margin-bottom: 0.6em;
  line-height: 1.6;
}

.tina-prose :where(h3 strong):not(:where([class~="not-tina-prose"] *)) {
  font-weight: 700;
}

.tina-prose :where(h4):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  margin-top: 1.5em;
  margin-bottom: 0.5em;
  line-height: 1.5;
}

.tina-prose :where(h4 strong):not(:where([class~="not-tina-prose"] *)) {
  font-weight: 700;
}

.tina-prose :where(figure > *):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 0;
  margin-bottom: 0;
}

.tina-prose :where(figcaption):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-captions);
  font-size: 0.875em;
  line-height: 1.4285714;
  margin-top: 0.8571429em;
}

.tina-prose :where(code):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-code);
  font-weight: 600;
  font-size: 0.875em;
}

.tina-prose :where(code):not(:where([class~="not-tina-prose"] *))::before {
  content: "\`";
}

.tina-prose :where(code):not(:where([class~="not-tina-prose"] *))::after {
  content: "\`";
}

.tina-prose :where(a code):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-links);
}

.tina-prose :where(pre):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-pre-code);
  background-color: var(--tw-prose-pre-bg);
  overflow-x: auto;
  font-weight: 400;
  font-size: 0.875em;
  line-height: 1.7142857;
  margin-top: 1.7142857em;
  margin-bottom: 1.7142857em;
  border-radius: 0.375rem;
  padding-top: 0.8571429em;
  padding-right: 1.1428571em;
  padding-bottom: 0.8571429em;
  padding-left: 1.1428571em;
}

.tina-prose :where(pre code):not(:where([class~="not-tina-prose"] *)) {
  background-color: transparent;
  border-width: 0;
  border-radius: 0;
  padding: 0;
  font-weight: inherit;
  color: inherit;
  font-size: inherit;
  font-family: inherit;
  line-height: inherit;
}

.tina-prose :where(pre code):not(:where([class~="not-tina-prose"] *))::before {
  content: none;
}

.tina-prose :where(pre code):not(:where([class~="not-tina-prose"] *))::after {
  content: none;
}

.tina-prose :where(table):not(:where([class~="not-tina-prose"] *)) {
  width: 100%;
  table-layout: auto;
  text-align: left;
  margin-top: 2em;
  margin-bottom: 2em;
  font-size: 0.875em;
  line-height: 1.7142857;
}

.tina-prose :where(thead):not(:where([class~="not-tina-prose"] *)) {
  border-bottom-width: 1px;
  border-bottom-color: var(--tw-prose-th-borders);
}

.tina-prose :where(thead th):not(:where([class~="not-tina-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  vertical-align: bottom;
  padding-right: 0.5714286em;
  padding-bottom: 0.5714286em;
  padding-left: 0.5714286em;
}

.tina-prose :where(tbody tr):not(:where([class~="not-tina-prose"] *)) {
  border-bottom-width: 1px;
  border-bottom-color: var(--tw-prose-td-borders);
}

.tina-prose :where(tbody tr:last-child):not(:where([class~="not-tina-prose"] *)) {
  border-bottom-width: 0;
}

.tina-prose :where(tbody td):not(:where([class~="not-tina-prose"] *)) {
  vertical-align: baseline;
  padding-top: 0.5714286em;
  padding-right: 0.5714286em;
  padding-bottom: 0.5714286em;
  padding-left: 0.5714286em;
}

.tina-prose {
  --tw-prose-body: #374151;
  --tw-prose-headings: #111827;
  --tw-prose-lead: #4b5563;
  --tw-prose-links: #111827;
  --tw-prose-bold: #111827;
  --tw-prose-counters: #6b7280;
  --tw-prose-bullets: #d1d5db;
  --tw-prose-hr: #e5e7eb;
  --tw-prose-quotes: #111827;
  --tw-prose-quote-borders: #e5e7eb;
  --tw-prose-captions: #6b7280;
  --tw-prose-code: #111827;
  --tw-prose-pre-code: #e5e7eb;
  --tw-prose-pre-bg: #1f2937;
  --tw-prose-th-borders: #d1d5db;
  --tw-prose-td-borders: #e5e7eb;
  --tw-prose-invert-body: #d1d5db;
  --tw-prose-invert-headings: #fff;
  --tw-prose-invert-lead: #9ca3af;
  --tw-prose-invert-links: #fff;
  --tw-prose-invert-bold: #fff;
  --tw-prose-invert-counters: #9ca3af;
  --tw-prose-invert-bullets: #4b5563;
  --tw-prose-invert-hr: #374151;
  --tw-prose-invert-quotes: #f3f4f6;
  --tw-prose-invert-quote-borders: #374151;
  --tw-prose-invert-captions: #9ca3af;
  --tw-prose-invert-code: #fff;
  --tw-prose-invert-pre-code: #d1d5db;
  --tw-prose-invert-pre-bg: rgb(0 0 0 / 50%);
  --tw-prose-invert-th-borders: #4b5563;
  --tw-prose-invert-td-borders: #374151;
  font-size: 1rem;
  line-height: 1.75;
}

.tina-prose :where(p):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 1.25em;
  margin-bottom: 1.25em;
}

.tina-prose :where(img):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}

.tina-prose :where(video):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}

.tina-prose :where(figure):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}

.tina-prose :where(h2 code):not(:where([class~="not-tina-prose"] *)) {
  font-size: 0.875em;
}

.tina-prose :where(h3 code):not(:where([class~="not-tina-prose"] *)) {
  font-size: 0.9em;
}

.tina-prose :where(li):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 0.5em;
  margin-bottom: 0.5em;
}

.tina-prose :where(ol > li):not(:where([class~="not-tina-prose"] *)) {
  padding-left: 0.375em;
}

.tina-prose :where(ul > li):not(:where([class~="not-tina-prose"] *)) {
  padding-left: 0.375em;
}

.tina-prose > :where(ul > li p):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 0.75em;
  margin-bottom: 0.75em;
}

.tina-prose > :where(ul > li > *:first-child):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 1.25em;
}

.tina-prose > :where(ul > li > *:last-child):not(:where([class~="not-tina-prose"] *)) {
  margin-bottom: 1.25em;
}

.tina-prose > :where(ol > li > *:first-child):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 1.25em;
}

.tina-prose > :where(ol > li > *:last-child):not(:where([class~="not-tina-prose"] *)) {
  margin-bottom: 1.25em;
}

.tina-prose :where(ul ul, ul ol, ol ul, ol ol):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 0.75em;
  margin-bottom: 0.75em;
}

.tina-prose :where(hr + *):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 0;
}

.tina-prose :where(h2 + *):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 0;
}

.tina-prose :where(h3 + *):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 0;
}

.tina-prose :where(h4 + *):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 0;
}

.tina-prose :where(thead th:first-child):not(:where([class~="not-tina-prose"] *)) {
  padding-left: 0;
}

.tina-prose :where(thead th:last-child):not(:where([class~="not-tina-prose"] *)) {
  padding-right: 0;
}

.tina-prose :where(tbody td:first-child):not(:where([class~="not-tina-prose"] *)) {
  padding-left: 0;
}

.tina-prose :where(tbody td:last-child):not(:where([class~="not-tina-prose"] *)) {
  padding-right: 0;
}

.tina-prose > :where(:first-child):not(:where([class~="not-tina-prose"] *)) {
  margin-top: 0;
}

.tina-prose > :where(:last-child):not(:where([class~="not-tina-prose"] *)) {
  margin-bottom: 0;
}

.tina-tailwind .sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.tina-tailwind .pointer-events-none {
  pointer-events: none;
}

.tina-tailwind .pointer-events-auto {
  pointer-events: auto;
}

.tina-tailwind .visible {
  visibility: visible;
}

.tina-tailwind .static {
  position: static;
}

.tina-tailwind .fixed {
  position: fixed;
}

.tina-tailwind .absolute {
  position: absolute;
}

.tina-tailwind .relative {
  position: relative;
}

.tina-tailwind .sticky {
  position: sticky;
}

.tina-tailwind .inset-0 {
  top: 0px;
  right: 0px;
  bottom: 0px;
  left: 0px;
}

.tina-tailwind .inset-y-0 {
  top: 0px;
  bottom: 0px;
}

.tina-tailwind .-bottom-0 {
  bottom: -0px;
}

.tina-tailwind .-bottom-0\\.5 {
  bottom: -2px;
}

.tina-tailwind .-bottom-1 {
  bottom: -4px;
}

.tina-tailwind .-left-0 {
  left: -0px;
}

.tina-tailwind .-left-0\\.5 {
  left: -2px;
}

.tina-tailwind .-right-0 {
  right: -0px;
}

.tina-tailwind .-right-0\\.5 {
  right: -2px;
}

.tina-tailwind .-right-3 {
  right: -12px;
}

.tina-tailwind .-top-0 {
  top: -0px;
}

.tina-tailwind .-top-0\\.5 {
  top: -2px;
}

.tina-tailwind .-top-2 {
  top: -8px;
}

.tina-tailwind .bottom-0 {
  bottom: 0px;
}

.tina-tailwind .bottom-3 {
  bottom: 12px;
}

.tina-tailwind .bottom-5 {
  bottom: 20px;
}

.tina-tailwind .left-0 {
  left: 0px;
}

.tina-tailwind .left-0\\.5 {
  left: 2px;
}

.tina-tailwind .left-1 {
  left: 4px;
}

.tina-tailwind .left-1\\.5 {
  left: 6px;
}

.tina-tailwind .left-1\\/2 {
  left: 50%;
}

.tina-tailwind .left-5 {
  left: 20px;
}

.tina-tailwind .right-0 {
  right: 0px;
}

.tina-tailwind .right-2 {
  right: 8px;
}

.tina-tailwind .right-2\\.5 {
  right: 10px;
}

.tina-tailwind .right-3 {
  right: 12px;
}

.tina-tailwind .right-5 {
  right: 20px;
}

.tina-tailwind .right-px {
  right: 1px;
}

.tina-tailwind .top-0 {
  top: 0px;
}

.tina-tailwind .top-1 {
  top: 4px;
}

.tina-tailwind .top-1\\.5 {
  top: 6px;
}

.tina-tailwind .top-1\\/2 {
  top: 50%;
}

.tina-tailwind .top-6 {
  top: 24px;
}

.tina-tailwind .top-8 {
  top: 32px;
}

.tina-tailwind .-z-1 {
  z-index: -1;
}

.tina-tailwind .z-0 {
  z-index: 0;
}

.tina-tailwind .z-10 {
  z-index: 10;
}

.tina-tailwind .z-100 {
  z-index: 100;
}

.tina-tailwind .z-20 {
  z-index: 20;
}

.tina-tailwind .z-30 {
  z-index: 30;
}

.tina-tailwind .z-40 {
  z-index: 40;
}

.tina-tailwind .z-50 {
  z-index: 50;
}

.tina-tailwind .z-\\[999999\\] {
  z-index: 999999;
}

.tina-tailwind .z-base {
  z-index: 9000;
}

.tina-tailwind .z-chrome {
  z-index: 10200;
}

.tina-tailwind .z-menu {
  z-index: 9800;
}

.tina-tailwind .z-modal {
  z-index: 10800;
}

.tina-tailwind .z-overlay {
  z-index: 10600;
}

.tina-tailwind .z-panel {
  z-index: 9400;
}

.tina-tailwind .m-0 {
  margin: 0px;
}

.tina-tailwind .-mx-0 {
  margin-left: -0px;
  margin-right: -0px;
}

.tina-tailwind .-mx-0\\.5 {
  margin-left: -2px;
  margin-right: -2px;
}

.tina-tailwind .-mx-1 {
  margin-left: -4px;
  margin-right: -4px;
}

.tina-tailwind .mx-auto {
  margin-left: auto;
  margin-right: auto;
}

.tina-tailwind .my-0 {
  margin-top: 0px;
  margin-bottom: 0px;
}

.tina-tailwind .my-10 {
  margin-top: 40px;
  margin-bottom: 40px;
}

.tina-tailwind .my-2 {
  margin-top: 8px;
  margin-bottom: 8px;
}

.tina-tailwind .my-4 {
  margin-top: 16px;
  margin-bottom: 16px;
}

.tina-tailwind .-mb-14 {
  margin-bottom: -56px;
}

.tina-tailwind .-mb-8 {
  margin-bottom: -32px;
}

.tina-tailwind .-mb-px {
  margin-bottom: -1px;
}

.tina-tailwind .-ml-0 {
  margin-left: -0px;
}

.tina-tailwind .-ml-0\\.5 {
  margin-left: -2px;
}

.tina-tailwind .-ml-1 {
  margin-left: -4px;
}

.tina-tailwind .-ml-px {
  margin-left: -1px;
}

.tina-tailwind .-mr-0 {
  margin-right: -0px;
}

.tina-tailwind .-mr-0\\.5 {
  margin-right: -2px;
}

.tina-tailwind .-mr-1 {
  margin-right: -4px;
}

.tina-tailwind .-mr-4 {
  margin-right: -16px;
}

.tina-tailwind .-mr-px {
  margin-right: -1px;
}

.tina-tailwind .-mt-0 {
  margin-top: -0px;
}

.tina-tailwind .-mt-0\\.5 {
  margin-top: -2px;
}

.tina-tailwind .-mt-1 {
  margin-top: -4px;
}

.tina-tailwind .-mt-2 {
  margin-top: -8px;
}

.tina-tailwind .-mt-8 {
  margin-top: -32px;
}

.tina-tailwind .-mt-px {
  margin-top: -1px;
}

.tina-tailwind .mb-0 {
  margin-bottom: 0px;
}

.tina-tailwind .mb-1 {
  margin-bottom: 4px;
}

.tina-tailwind .mb-1\\.5 {
  margin-bottom: 6px;
}

.tina-tailwind .mb-12 {
  margin-bottom: 48px;
}

.tina-tailwind .mb-2 {
  margin-bottom: 8px;
}

.tina-tailwind .mb-3 {
  margin-bottom: 12px;
}

.tina-tailwind .mb-4 {
  margin-bottom: 16px;
}

.tina-tailwind .mb-5 {
  margin-bottom: 20px;
}

.tina-tailwind .mb-6 {
  margin-bottom: 24px;
}

.tina-tailwind .mb-\\[6px\\] {
  margin-bottom: 6px;
}

.tina-tailwind .ml-1 {
  margin-left: 4px;
}

.tina-tailwind .ml-1\\.5 {
  margin-left: 6px;
}

.tina-tailwind .ml-2 {
  margin-left: 8px;
}

.tina-tailwind .ml-3 {
  margin-left: 12px;
}

.tina-tailwind .ml-\\[14px\\] {
  margin-left: 14px;
}

.tina-tailwind .mr-0 {
  margin-right: 0px;
}

.tina-tailwind .mr-0\\.5 {
  margin-right: 2px;
}

.tina-tailwind .mr-1 {
  margin-right: 4px;
}

.tina-tailwind .mr-1\\.5 {
  margin-right: 6px;
}

.tina-tailwind .mr-2 {
  margin-right: 8px;
}

.tina-tailwind .mr-3 {
  margin-right: 12px;
}

.tina-tailwind .mt-0 {
  margin-top: 0px;
}

.tina-tailwind .mt-0\\.5 {
  margin-top: 2px;
}

.tina-tailwind .mt-1 {
  margin-top: 4px;
}

.tina-tailwind .mt-2 {
  margin-top: 8px;
}

.tina-tailwind .mt-3 {
  margin-top: 12px;
}

.tina-tailwind .mt-4 {
  margin-top: 16px;
}

.tina-tailwind .mt-5 {
  margin-top: 20px;
}

.tina-tailwind .mt-6 {
  margin-top: 24px;
}

.tina-tailwind .mt-8 {
  margin-top: 32px;
}

.tina-tailwind .block {
  display: block;
}

.tina-tailwind .inline-block {
  display: inline-block;
}

.tina-tailwind .inline {
  display: inline;
}

.tina-tailwind .flex {
  display: flex;
}

.tina-tailwind .inline-flex {
  display: inline-flex;
}

.tina-tailwind .table {
  display: table;
}

.tina-tailwind .grid {
  display: grid;
}

.tina-tailwind .contents {
  display: contents;
}

.tina-tailwind .hidden {
  display: none;
}

.tina-tailwind .h-0 {
  height: 0px;
}

.tina-tailwind .h-10 {
  height: 40px;
}

.tina-tailwind .h-14 {
  height: 56px;
}

.tina-tailwind .h-16 {
  height: 64px;
}

.tina-tailwind .h-3 {
  height: 12px;
}

.tina-tailwind .h-3\\/4 {
  height: 75%;
}

.tina-tailwind .h-32 {
  height: 128px;
}

.tina-tailwind .h-4 {
  height: 16px;
}

.tina-tailwind .h-4\\/6 {
  height: 66.666667%;
}

.tina-tailwind .h-5 {
  height: 20px;
}

.tina-tailwind .h-6 {
  height: 24px;
}

.tina-tailwind .h-7 {
  height: 28px;
}

.tina-tailwind .h-8 {
  height: 32px;
}

.tina-tailwind .h-9 {
  height: 36px;
}

.tina-tailwind .h-\\[17px\\] {
  height: 17px;
}

.tina-tailwind .h-\\[18px\\] {
  height: 18px;
}

.tina-tailwind .h-\\[19px\\] {
  height: 19px;
}

.tina-tailwind .h-\\[22px\\] {
  height: 22px;
}

.tina-tailwind .h-auto {
  height: auto;
}

.tina-tailwind .h-full {
  height: 100%;
}

.tina-tailwind .h-screen {
  height: 100vh;
}

.tina-tailwind .max-h-48 {
  max-height: 192px;
}

.tina-tailwind .max-h-\\[10rem\\] {
  max-height: 10rem;
}

.tina-tailwind .max-h-\\[13rem\\] {
  max-height: 13rem;
}

.tina-tailwind .max-h-\\[200px\\] {
  max-height: 200px;
}

.tina-tailwind .max-h-\\[24rem\\] {
  max-height: 24rem;
}

.tina-tailwind .max-h-\\[300px\\] {
  max-height: 300px;
}

.tina-tailwind .max-h-\\[75\\%\\] {
  max-height: 75%;
}

.tina-tailwind .max-h-\\[initial\\] {
  max-height: initial;
}

.tina-tailwind .max-h-full {
  max-height: 100%;
}

.tina-tailwind .min-h-\\[100px\\] {
  min-height: 100px;
}

.tina-tailwind .min-h-\\[160px\\] {
  min-height: 160px;
}

.tina-tailwind .min-h-\\[2\\.5rem\\] {
  min-height: 2.5rem;
}

.tina-tailwind .min-h-\\[96px\\] {
  min-height: 96px;
}

.tina-tailwind .w-0 {
  width: 0px;
}

.tina-tailwind .w-1\\/2 {
  width: 50%;
}

.tina-tailwind .w-10 {
  width: 40px;
}

.tina-tailwind .w-12 {
  width: 48px;
}

.tina-tailwind .w-14 {
  width: 56px;
}

.tina-tailwind .w-16 {
  width: 64px;
}

.tina-tailwind .w-2 {
  width: 8px;
}

.tina-tailwind .w-3 {
  width: 12px;
}

.tina-tailwind .w-3\\/5 {
  width: 60%;
}

.tina-tailwind .w-32 {
  width: 128px;
}

.tina-tailwind .w-4 {
  width: 16px;
}

.tina-tailwind .w-48 {
  width: 192px;
}

.tina-tailwind .w-5 {
  width: 20px;
}

.tina-tailwind .w-5\\/6 {
  width: 83.333333%;
}

.tina-tailwind .w-56 {
  width: 224px;
}

.tina-tailwind .w-6 {
  width: 24px;
}

.tina-tailwind .w-7 {
  width: 28px;
}

.tina-tailwind .w-8 {
  width: 32px;
}

.tina-tailwind .w-9 {
  width: 36px;
}

.tina-tailwind .w-96 {
  width: 384px;
}

.tina-tailwind .w-\\[0px\\] {
  width: 0px;
}

.tina-tailwind .w-\\[17px\\] {
  width: 17px;
}

.tina-tailwind .w-\\[18px\\] {
  width: 18px;
}

.tina-tailwind .w-\\[19px\\] {
  width: 19px;
}

.tina-tailwind .w-\\[22px\\] {
  width: 22px;
}

.tina-tailwind .w-\\[30\\%\\] {
  width: 30%;
}

.tina-tailwind .w-\\[300px\\] {
  width: 300px;
}

.tina-tailwind .w-\\[35\\%\\] {
  width: 35%;
}

.tina-tailwind .w-\\[460px\\] {
  width: 460px;
}

.tina-tailwind .w-\\[48px\\] {
  width: 48px;
}

.tina-tailwind .w-auto {
  width: auto;
}

.tina-tailwind .w-full {
  width: 100%;
}

.tina-tailwind .w-px {
  width: 1px;
}

.tina-tailwind .w-screen {
  width: 100vw;
}

.tina-tailwind .min-w-0 {
  min-width: 0px;
}

.tina-tailwind .min-w-\\[12rem\\] {
  min-width: 12rem;
}

.tina-tailwind .min-w-\\[192px\\] {
  min-width: 192px;
}

.tina-tailwind .min-w-\\[200px\\] {
  min-width: 200px;
}

.tina-tailwind .min-w-\\[240px\\] {
  min-width: 240px;
}

.tina-tailwind .min-w-\\[350px\\] {
  min-width: 350px;
}

.tina-tailwind .min-w-\\[5rem\\] {
  min-width: 5rem;
}

.tina-tailwind .max-w-\\[1500px\\] {
  max-width: 1500px;
}

.tina-tailwind .max-w-\\[40\\%\\] {
  max-width: 40%;
}

.tina-tailwind .max-w-\\[400px\\] {
  max-width: 400px;
}

.tina-tailwind .max-w-\\[560px\\] {
  max-width: 560px;
}

.tina-tailwind .max-w-\\[680px\\] {
  max-width: 680px;
}

.tina-tailwind .max-w-\\[90\\%\\] {
  max-width: 90%;
}

.tina-tailwind .max-w-form {
  max-width: 900px;
}

.tina-tailwind .max-w-full {
  max-width: 100%;
}

.tina-tailwind .max-w-prose {
  max-width: 65ch;
}

.tina-tailwind .max-w-screen-xl {
  max-width: 1280px;
}

.tina-tailwind .max-w-xl {
  max-width: 36rem;
}

.tina-tailwind .flex-1 {
  flex: 1 1 0%;
}

.tina-tailwind .flex-none {
  flex: none;
}

.tina-tailwind .flex-shrink-0 {
  flex-shrink: 0;
}

.tina-tailwind .shrink {
  flex-shrink: 1;
}

.tina-tailwind .shrink-0 {
  flex-shrink: 0;
}

.tina-tailwind .flex-grow {
  flex-grow: 1;
}

.tina-tailwind .flex-grow-0 {
  flex-grow: 0;
}

.tina-tailwind .grow {
  flex-grow: 1;
}

.tina-tailwind .grow-0 {
  flex-grow: 0;
}

.tina-tailwind .basis-\\[auto\\] {
  flex-basis: auto;
}

.tina-tailwind .origin-bottom-right {
  transform-origin: bottom right;
}

.tina-tailwind .origin-center {
  transform-origin: center;
}

.tina-tailwind .origin-left {
  transform-origin: left;
}

.tina-tailwind .origin-top-left {
  transform-origin: top left;
}

.tina-tailwind .origin-top-right {
  transform-origin: top right;
}

.tina-tailwind .-translate-x-1\\/2 {
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .-translate-x-8 {
  --tw-translate-x: -32px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .-translate-x-full {
  --tw-translate-x: -100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .-translate-y-1\\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .-translate-y-2 {
  --tw-translate-y: -8px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .translate-x-0 {
  --tw-translate-x: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .translate-x-8 {
  --tw-translate-x: 32px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .translate-x-full {
  --tw-translate-x: 100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .translate-y-0 {
  --tw-translate-y: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .translate-y-1 {
  --tw-translate-y: 4px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .translate-y-full {
  --tw-translate-y: 100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .-rotate-90 {
  --tw-rotate: -90deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .rotate-45 {
  --tw-rotate: 45deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .scale-100 {
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .scale-110 {
  --tw-scale-x: 1.1;
  --tw-scale-y: 1.1;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .scale-90 {
  --tw-scale-x: .9;
  --tw-scale-y: .9;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .scale-95 {
  --tw-scale-x: .95;
  --tw-scale-y: .95;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

@keyframes slideIn {

  0% {
    opacity: 0;
    transform: translateY(-1rem);
  }

  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

.tina-tailwind .animate-slide-in {
  animation: slideIn 150ms ease-out 1 normal forwards;
}

@keyframes spin {

  to {
    transform: rotate(360deg);
  }
}

.tina-tailwind .animate-spin {
  animation: spin 1s linear infinite;
}

.tina-tailwind .cursor-\\[grab\\] {
  cursor: grab;
}

.tina-tailwind .cursor-default {
  cursor: default;
}

.tina-tailwind .cursor-not-allowed {
  cursor: not-allowed;
}

.tina-tailwind .cursor-pointer {
  cursor: pointer;
}

.tina-tailwind .cursor-wait {
  cursor: wait;
}

.tina-tailwind .select-none {
  user-select: none;
}

.tina-tailwind .resize-y {
  resize: vertical;
}

.tina-tailwind .resize {
  resize: both;
}

.tina-tailwind .list-inside {
  list-style-position: inside;
}

.tina-tailwind .list-outside {
  list-style-position: outside;
}

.tina-tailwind .list-decimal {
  list-style-type: decimal;
}

.tina-tailwind .list-disc {
  list-style-type: disc;
}

.tina-tailwind .appearance-none {
  appearance: none;
}

.tina-tailwind .auto-rows-auto {
  grid-auto-rows: auto;
}

.tina-tailwind .grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}

.tina-tailwind .flex-col {
  flex-direction: column;
}

.tina-tailwind .flex-wrap {
  flex-wrap: wrap;
}

.tina-tailwind .flex-nowrap {
  flex-wrap: nowrap;
}

.tina-tailwind .content-start {
  align-content: flex-start;
}

.tina-tailwind .items-start {
  align-items: flex-start;
}

.tina-tailwind .items-center {
  align-items: center;
}

.tina-tailwind .items-stretch {
  align-items: stretch;
}

.tina-tailwind .justify-start {
  justify-content: flex-start;
}

.tina-tailwind .justify-end {
  justify-content: flex-end;
}

.tina-tailwind .justify-center {
  justify-content: center;
}

.tina-tailwind .justify-between {
  justify-content: space-between;
}

.tina-tailwind .justify-items-start {
  justify-items: start;
}

.tina-tailwind .gap-0 {
  gap: 0px;
}

.tina-tailwind .gap-0\\.5 {
  gap: 2px;
}

.tina-tailwind .gap-1 {
  gap: 4px;
}

.tina-tailwind .gap-1\\.5 {
  gap: 6px;
}

.tina-tailwind .gap-2 {
  gap: 8px;
}

.tina-tailwind .gap-3 {
  gap: 12px;
}

.tina-tailwind .gap-4 {
  gap: 16px;
}

.tina-tailwind .gap-x-3 {
  column-gap: 12px;
}

.tina-tailwind .gap-y-1 {
  row-gap: 4px;
}

.tina-tailwind .space-x-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(4px * var(--tw-space-x-reverse));
  margin-left: calc(4px * calc(1 - var(--tw-space-x-reverse)));
}

.tina-tailwind .space-y-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(16px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(16px * var(--tw-space-y-reverse));
}

.tina-tailwind .divide-x > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-x-reverse: 0;
  border-right-width: calc(1px * var(--tw-divide-x-reverse));
  border-left-width: calc(1px * calc(1 - var(--tw-divide-x-reverse)));
}

.tina-tailwind .divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}

.tina-tailwind .divide-gray-100 > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(237 236 243 / var(--tw-divide-opacity));
}

.tina-tailwind .divide-gray-150 > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(230 227 239 / var(--tw-divide-opacity));
}

.tina-tailwind .divide-gray-200 > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(225 221 236 / var(--tw-divide-opacity));
}

.tina-tailwind .self-end {
  align-self: flex-end;
}

.tina-tailwind .self-stretch {
  align-self: stretch;
}

.tina-tailwind .overflow-auto {
  overflow: auto;
}

.tina-tailwind .overflow-hidden {
  overflow: hidden;
}

.tina-tailwind .overflow-visible {
  overflow: visible;
}

.tina-tailwind .overflow-scroll {
  overflow: scroll;
}

.tina-tailwind .overflow-y-auto {
  overflow-y: auto;
}

.tina-tailwind .overflow-x-visible {
  overflow-x: visible;
}

.tina-tailwind .truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.tina-tailwind .text-ellipsis {
  text-overflow: ellipsis;
}

.tina-tailwind .whitespace-normal {
  white-space: normal;
}

.tina-tailwind .whitespace-nowrap {
  white-space: nowrap;
}

.tina-tailwind .whitespace-pre-wrap {
  white-space: pre-wrap;
}

.tina-tailwind .break-words {
  overflow-wrap: break-word;
}

.tina-tailwind .break-all {
  word-break: break-all;
}

.tina-tailwind .rounded {
  border-radius: 4px;
}

.tina-tailwind .rounded-3xl {
  border-radius: 24px;
}

.tina-tailwind .rounded-\\[50\\%\\] {
  border-radius: 50%;
}

.tina-tailwind .rounded-\\[5px\\] {
  border-radius: 5px;
}

.tina-tailwind .rounded-full {
  border-radius: 9999px;
}

.tina-tailwind .rounded-lg {
  border-radius: 8px;
}

.tina-tailwind .rounded-md {
  border-radius: 6px;
}

.tina-tailwind .rounded-none {
  border-radius: 0px;
}

.tina-tailwind .rounded-sm {
  border-radius: 2px;
}

.tina-tailwind .rounded-b-md {
  border-bottom-right-radius: 6px;
  border-bottom-left-radius: 6px;
}

.tina-tailwind .rounded-l-full {
  border-top-left-radius: 9999px;
  border-bottom-left-radius: 9999px;
}

.tina-tailwind .rounded-l-md {
  border-top-left-radius: 6px;
  border-bottom-left-radius: 6px;
}

.tina-tailwind .rounded-r-full {
  border-top-right-radius: 9999px;
  border-bottom-right-radius: 9999px;
}

.tina-tailwind .rounded-r-md {
  border-top-right-radius: 6px;
  border-bottom-right-radius: 6px;
}

.tina-tailwind .border {
  border-width: 1px;
}

.tina-tailwind .border-0 {
  border-width: 0;
}

.tina-tailwind .border-2 {
  border-width: 2px;
}

.tina-tailwind .border-b {
  border-bottom-width: 1px;
}

.tina-tailwind .border-b-\\[1px\\] {
  border-bottom-width: 1px;
}

.tina-tailwind .border-l {
  border-left-width: 1px;
}

.tina-tailwind .border-l-0 {
  border-left-width: 0;
}

.tina-tailwind .border-l-3 {
  border-left-width: 3px;
}

.tina-tailwind .border-r {
  border-right-width: 1px;
}

.tina-tailwind .border-r-0 {
  border-right-width: 0;
}

.tina-tailwind .border-t {
  border-top-width: 1px;
}

.tina-tailwind .border-t-0 {
  border-top-width: 0;
}

.tina-tailwind .border-solid {
  border-style: solid;
}

.tina-tailwind .border-none {
  border-style: none;
}

.tina-tailwind .border-\\[\\#efefef\\] {
  --tw-border-opacity: 1;
  border-color: rgb(239 239 239 / var(--tw-border-opacity));
}

.tina-tailwind .border-blue-500 {
  --tw-border-opacity: 1;
  border-color: rgb(0 132 255 / var(--tw-border-opacity));
}

.tina-tailwind .border-blue-600 {
  --tw-border-opacity: 1;
  border-color: rgb(5 116 228 / var(--tw-border-opacity));
}

.tina-tailwind .border-gray-100 {
  --tw-border-opacity: 1;
  border-color: rgb(237 236 243 / var(--tw-border-opacity));
}

.tina-tailwind .border-gray-150 {
  --tw-border-opacity: 1;
  border-color: rgb(230 227 239 / var(--tw-border-opacity));
}

.tina-tailwind .border-gray-200 {
  --tw-border-opacity: 1;
  border-color: rgb(225 221 236 / var(--tw-border-opacity));
}

.tina-tailwind .border-gray-300 {
  --tw-border-opacity: 1;
  border-color: rgb(178 173 190 / var(--tw-border-opacity));
}

.tina-tailwind .border-gray-50 {
  --tw-border-opacity: 1;
  border-color: rgb(246 246 249 / var(--tw-border-opacity));
}

.tina-tailwind .border-green-200 {
  --tw-border-opacity: 1;
  border-color: rgb(187 247 208 / var(--tw-border-opacity));
}

.tina-tailwind .border-green-400 {
  --tw-border-opacity: 1;
  border-color: rgb(74 222 128 / var(--tw-border-opacity));
}

.tina-tailwind .border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity));
}

.tina-tailwind .border-transparent {
  border-color: transparent;
}

.tina-tailwind .border-yellow-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 240 138 / var(--tw-border-opacity));
}

.tina-tailwind .border-yellow-500 {
  --tw-border-opacity: 1;
  border-color: rgb(234 179 8 / var(--tw-border-opacity));
}

.tina-tailwind .border-b-\\[\\#edecf3\\] {
  --tw-border-opacity: 1;
  border-bottom-color: rgb(237 236 243 / var(--tw-border-opacity));
}

.tina-tailwind .border-t-gray-100 {
  --tw-border-opacity: 1;
  border-top-color: rgb(237 236 243 / var(--tw-border-opacity));
}

.tina-tailwind .border-t-white {
  --tw-border-opacity: 1;
  border-top-color: rgb(255 255 255 / var(--tw-border-opacity));
}

.tina-tailwind .bg-blue-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 238 255 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-blue-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(0 132 255 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(237 236 243 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-gray-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(225 221 236 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-gray-250 {
  --tw-bg-opacity: 1;
  background-color: rgb(201 197 213 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-gray-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(246 246 249 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-green-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(220 252 231 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-green-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(134 239 172 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-red-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 242 242 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-red-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(239 68 68 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-transparent {
  background-color: transparent;
}

.tina-tailwind .bg-white {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-yellow-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(250 204 21 / var(--tw-bg-opacity));
}

.tina-tailwind .bg-opacity-90 {
  --tw-bg-opacity: .9;
}

.tina-tailwind .bg-gradient-to-b {
  background-image: linear-gradient(to bottom, var(--tw-gradient-stops));
}

.tina-tailwind .bg-gradient-to-br {
  background-image: linear-gradient(to bottom right, var(--tw-gradient-stops));
}

.tina-tailwind .bg-gradient-to-r {
  background-image: linear-gradient(to right, var(--tw-gradient-stops));
}

.tina-tailwind .bg-gradient-to-t {
  background-image: linear-gradient(to top, var(--tw-gradient-stops));
}

.tina-tailwind .bg-none {
  background-image: none;
}

.tina-tailwind .from-blue-600 {
  --tw-gradient-from: #0574e4;
  --tw-gradient-to: rgb(5 116 228 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}

.tina-tailwind .from-gray-200 {
  --tw-gradient-from: #E1DDEC;
  --tw-gradient-to: rgb(225 221 236 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}

.tina-tailwind .from-gray-50 {
  --tw-gradient-from: #F6F6F9;
  --tw-gradient-to: rgb(246 246 249 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}

.tina-tailwind .from-gray-50\\/50 {
  --tw-gradient-from: rgb(246 246 249 / .5);
  --tw-gradient-to: rgb(246 246 249 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}

.tina-tailwind .from-gray-800 {
  --tw-gradient-from: #363145;
  --tw-gradient-to: rgb(54 49 69 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}

.tina-tailwind .from-white {
  --tw-gradient-from: #fff;
  --tw-gradient-to: rgb(255 255 255 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}

.tina-tailwind .from-yellow-50 {
  --tw-gradient-from: #fefce8;
  --tw-gradient-to: rgb(254 252 232 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}

.tina-tailwind .via-gray-900 {
  --tw-gradient-to: rgb(37 35 54 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), #252336, var(--tw-gradient-to);
}

.tina-tailwind .via-red-50 {
  --tw-gradient-to: rgb(254 242 242 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), #fef2f2, var(--tw-gradient-to);
}

.tina-tailwind .via-white {
  --tw-gradient-to: rgb(255 255 255 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), #fff, var(--tw-gradient-to);
}

.tina-tailwind .to-black {
  --tw-gradient-to: #000;
}

.tina-tailwind .to-gray-50 {
  --tw-gradient-to: #F6F6F9;
}

.tina-tailwind .to-gray-50\\/50 {
  --tw-gradient-to: rgb(246 246 249 / .5);
}

.tina-tailwind .to-red-100 {
  --tw-gradient-to: #fee2e2;
}

.tina-tailwind .to-transparent {
  --tw-gradient-to: transparent;
}

.tina-tailwind .to-white {
  --tw-gradient-to: #fff;
}

.tina-tailwind .to-yellow-100 {
  --tw-gradient-to: #fef9c3;
}

.tina-tailwind .bg-\\[length\\:auto_18px\\] {
  background-size: auto 18px;
}

.tina-tailwind .bg-auto {
  background-size: auto;
}

.tina-tailwind .bg-center {
  background-position: center;
}

.tina-tailwind .bg-no-repeat {
  background-repeat: no-repeat;
}

.tina-tailwind .fill-blue-500 {
  fill: #0084FF;
}

.tina-tailwind .fill-current {
  fill: currentColor;
}

.tina-tailwind .fill-gray-300 {
  fill: #b2adbe;
}

.tina-tailwind .fill-gray-400 {
  fill: #918c9e;
}

.tina-tailwind .fill-white {
  fill: #fff;
}

.tina-tailwind .object-contain {
  object-fit: contain;
}

.tina-tailwind .object-cover {
  object-fit: cover;
}

.tina-tailwind .object-center {
  object-position: center;
}

.tina-tailwind .p-0 {
  padding: 0px;
}

.tina-tailwind .p-1 {
  padding: 4px;
}

.tina-tailwind .p-12 {
  padding: 48px;
}

.tina-tailwind .p-2 {
  padding: 8px;
}

.tina-tailwind .p-3 {
  padding: 12px;
}

.tina-tailwind .p-4 {
  padding: 16px;
}

.tina-tailwind .p-5 {
  padding: 20px;
}

.tina-tailwind .p-6 {
  padding: 24px;
}

.tina-tailwind .px-0 {
  padding-left: 0px;
  padding-right: 0px;
}

.tina-tailwind .px-1 {
  padding-left: 4px;
  padding-right: 4px;
}

.tina-tailwind .px-1\\.5 {
  padding-left: 6px;
  padding-right: 6px;
}

.tina-tailwind .px-2 {
  padding-left: 8px;
  padding-right: 8px;
}

.tina-tailwind .px-2\\.5 {
  padding-left: 10px;
  padding-right: 10px;
}

.tina-tailwind .px-3 {
  padding-left: 12px;
  padding-right: 12px;
}

.tina-tailwind .px-4 {
  padding-left: 16px;
  padding-right: 16px;
}

.tina-tailwind .px-5 {
  padding-left: 20px;
  padding-right: 20px;
}

.tina-tailwind .px-6 {
  padding-left: 24px;
  padding-right: 24px;
}

.tina-tailwind .py-0 {
  padding-top: 0px;
  padding-bottom: 0px;
}

.tina-tailwind .py-0\\.5 {
  padding-top: 2px;
  padding-bottom: 2px;
}

.tina-tailwind .py-1 {
  padding-top: 4px;
  padding-bottom: 4px;
}

.tina-tailwind .py-1\\.5 {
  padding-top: 6px;
  padding-bottom: 6px;
}

.tina-tailwind .py-2 {
  padding-top: 8px;
  padding-bottom: 8px;
}

.tina-tailwind .py-2\\.5 {
  padding-top: 10px;
  padding-bottom: 10px;
}

.tina-tailwind .py-3 {
  padding-top: 12px;
  padding-bottom: 12px;
}

.tina-tailwind .py-4 {
  padding-top: 16px;
  padding-bottom: 16px;
}

.tina-tailwind .py-5 {
  padding-top: 20px;
  padding-bottom: 20px;
}

.tina-tailwind .py-8 {
  padding-top: 32px;
  padding-bottom: 32px;
}

.tina-tailwind .pb-12 {
  padding-bottom: 48px;
}

.tina-tailwind .pb-16 {
  padding-bottom: 64px;
}

.tina-tailwind .pb-2 {
  padding-bottom: 8px;
}

.tina-tailwind .pb-3 {
  padding-bottom: 12px;
}

.tina-tailwind .pb-5 {
  padding-bottom: 20px;
}

.tina-tailwind .pb-\\[100\\%\\] {
  padding-bottom: 100%;
}

.tina-tailwind .pl-1 {
  padding-left: 4px;
}

.tina-tailwind .pl-1\\.5 {
  padding-left: 6px;
}

.tina-tailwind .pl-10 {
  padding-left: 40px;
}

.tina-tailwind .pl-12 {
  padding-left: 48px;
}

.tina-tailwind .pl-14 {
  padding-left: 56px;
}

.tina-tailwind .pl-18 {
  padding-left: 72px;
}

.tina-tailwind .pl-2 {
  padding-left: 8px;
}

.tina-tailwind .pl-2\\.5 {
  padding-left: 10px;
}

.tina-tailwind .pl-3 {
  padding-left: 12px;
}

.tina-tailwind .pl-4 {
  padding-left: 16px;
}

.tina-tailwind .pl-6 {
  padding-left: 24px;
}

.tina-tailwind .pr-0 {
  padding-right: 0px;
}

.tina-tailwind .pr-1 {
  padding-right: 4px;
}

.tina-tailwind .pr-10 {
  padding-right: 40px;
}

.tina-tailwind .pr-2 {
  padding-right: 8px;
}

.tina-tailwind .pr-24 {
  padding-right: 96px;
}

.tina-tailwind .pr-4 {
  padding-right: 16px;
}

.tina-tailwind .pr-5 {
  padding-right: 20px;
}

.tina-tailwind .pr-6 {
  padding-right: 24px;
}

.tina-tailwind .pr-8 {
  padding-right: 32px;
}

.tina-tailwind .pt-0 {
  padding-top: 0px;
}

.tina-tailwind .pt-0\\.5 {
  padding-top: 2px;
}

.tina-tailwind .pt-1 {
  padding-top: 4px;
}

.tina-tailwind .pt-16 {
  padding-top: 64px;
}

.tina-tailwind .pt-3 {
  padding-top: 12px;
}

.tina-tailwind .pt-4 {
  padding-top: 16px;
}

.tina-tailwind .pt-6 {
  padding-top: 24px;
}

.tina-tailwind .text-left {
  text-align: left;
}

.tina-tailwind .text-center {
  text-align: center;
}

.tina-tailwind .text-right {
  text-align: right;
}

.tina-tailwind .align-baseline {
  vertical-align: baseline;
}

.tina-tailwind .align-top {
  vertical-align: top;
}

.tina-tailwind .font-mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}

.tina-tailwind .font-sans {
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
}

.tina-tailwind .text-2xl {
  font-size: 24px;
  line-height: 1.33;
}

.tina-tailwind .text-3xl {
  font-size: 30px;
  line-height: 1.2;
}

.tina-tailwind .text-4xl {
  font-size: 36px;
  line-height: 1.1;
}

.tina-tailwind .text-\\[10px\\] {
  font-size: 10px;
}

.tina-tailwind .text-\\[12px\\] {
  font-size: 12px;
}

.tina-tailwind .text-\\[13px\\] {
  font-size: 13px;
}

.tina-tailwind .text-\\[15px\\] {
  font-size: 15px;
}

.tina-tailwind .text-\\[16px\\] {
  font-size: 16px;
}

.tina-tailwind .text-\\[24px\\] {
  font-size: 24px;
}

.tina-tailwind .text-\\[40px\\] {
  font-size: 40px;
}

.tina-tailwind .text-base {
  font-size: 16px;
  line-height: 1.5;
}

.tina-tailwind .text-lg {
  font-size: 18px;
  line-height: 1.55;
}

.tina-tailwind .text-sm {
  font-size: 14px;
  line-height: 1.43;
}

.tina-tailwind .text-xl {
  font-size: 20px;
  line-height: 1.4;
}

.tina-tailwind .text-xs {
  font-size: 13px;
  line-height: 1.33;
}

.tina-tailwind .font-bold {
  font-weight: 700;
}

.tina-tailwind .font-light {
  font-weight: 300;
}

.tina-tailwind .font-medium {
  font-weight: 500;
}

.tina-tailwind .font-normal {
  font-weight: 400;
}

.tina-tailwind .font-semibold {
  font-weight: 600;
}

.tina-tailwind .uppercase {
  text-transform: uppercase;
}

.tina-tailwind .capitalize {
  text-transform: capitalize;
}

.tina-tailwind .italic {
  font-style: italic;
}

.tina-tailwind .not-italic {
  font-style: normal;
}

.tina-tailwind .leading-5 {
  line-height: 20px;
}

.tina-tailwind .leading-6 {
  line-height: 24px;
}

.tina-tailwind .leading-\\[1\\.35\\] {
  line-height: 1.35;
}

.tina-tailwind .leading-none {
  line-height: 1;
}

.tina-tailwind .leading-tight {
  line-height: 1.25;
}

.tina-tailwind .tracking-\\[0\\.01em\\] {
  letter-spacing: 0.01em;
}

.tina-tailwind .tracking-wide {
  letter-spacing: 0.025em;
}

.tina-tailwind .text-blue-400 {
  --tw-text-opacity: 1;
  color: rgb(34 150 254 / var(--tw-text-opacity));
}

.tina-tailwind .text-blue-500 {
  --tw-text-opacity: 1;
  color: rgb(0 132 255 / var(--tw-text-opacity));
}

.tina-tailwind .text-blue-500\\/70 {
  color: rgb(0 132 255 / .7);
}

.tina-tailwind .text-blue-600 {
  --tw-text-opacity: 1;
  color: rgb(5 116 228 / var(--tw-text-opacity));
}

.tina-tailwind .text-blue-800 {
  --tw-text-opacity: 1;
  color: rgb(20 70 150 / var(--tw-text-opacity));
}

.tina-tailwind .text-gray-200 {
  --tw-text-opacity: 1;
  color: rgb(225 221 236 / var(--tw-text-opacity));
}

.tina-tailwind .text-gray-300 {
  --tw-text-opacity: 1;
  color: rgb(178 173 190 / var(--tw-text-opacity));
}

.tina-tailwind .text-gray-400 {
  --tw-text-opacity: 1;
  color: rgb(145 140 158 / var(--tw-text-opacity));
}

.tina-tailwind .text-gray-500 {
  --tw-text-opacity: 1;
  color: rgb(113 108 127 / var(--tw-text-opacity));
}

.tina-tailwind .text-gray-600 {
  --tw-text-opacity: 1;
  color: rgb(86 81 101 / var(--tw-text-opacity));
}

.tina-tailwind .text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(67 62 82 / var(--tw-text-opacity));
}

.tina-tailwind .text-gray-800 {
  --tw-text-opacity: 1;
  color: rgb(54 49 69 / var(--tw-text-opacity));
}

.tina-tailwind .text-gray-900 {
  --tw-text-opacity: 1;
  color: rgb(37 35 54 / var(--tw-text-opacity));
}

.tina-tailwind .text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity));
}

.tina-tailwind .text-green-600 {
  --tw-text-opacity: 1;
  color: rgb(22 163 74 / var(--tw-text-opacity));
}

.tina-tailwind .text-indigo-600 {
  --tw-text-opacity: 1;
  color: rgb(79 70 229 / var(--tw-text-opacity));
}

.tina-tailwind .text-red-400 {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity));
}

.tina-tailwind .text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity));
}

.tina-tailwind .text-red-600 {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity));
}

.tina-tailwind .text-red-700 {
  --tw-text-opacity: 1;
  color: rgb(185 28 28 / var(--tw-text-opacity));
}

.tina-tailwind .text-red-800 {
  --tw-text-opacity: 1;
  color: rgb(153 27 27 / var(--tw-text-opacity));
}

.tina-tailwind .text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity));
}

.tina-tailwind .text-yellow-400 {
  --tw-text-opacity: 1;
  color: rgb(250 204 21 / var(--tw-text-opacity));
}

.tina-tailwind .text-yellow-600 {
  --tw-text-opacity: 1;
  color: rgb(202 138 4 / var(--tw-text-opacity));
}

.tina-tailwind .text-yellow-700 {
  --tw-text-opacity: 1;
  color: rgb(161 98 7 / var(--tw-text-opacity));
}

.tina-tailwind .underline {
  text-decoration-line: underline;
}

.tina-tailwind .no-underline {
  text-decoration-line: none;
}

.tina-tailwind .decoration-blue-200 {
  text-decoration-color: #85C5FE;
}

.tina-tailwind .placeholder-gray-200::placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(225 221 236 / var(--tw-placeholder-opacity));
}

.tina-tailwind .placeholder-gray-400::placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(145 140 158 / var(--tw-placeholder-opacity));
}

.tina-tailwind .opacity-0 {
  opacity: 0;
}

.tina-tailwind .opacity-10 {
  opacity: .1;
}

.tina-tailwind .opacity-100 {
  opacity: 1;
}

.tina-tailwind .opacity-30 {
  opacity: .3;
}

.tina-tailwind .opacity-50 {
  opacity: .5;
}

.tina-tailwind .opacity-70 {
  opacity: .7;
}

.tina-tailwind .opacity-80 {
  opacity: .8;
}

.tina-tailwind .opacity-90 {
  opacity: .9;
}

.tina-tailwind .shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .shadow-\\[0_2px_3px_rgba\\(0\\2c 0\\2c 0\\2c 0\\.05\\)\\] {
  --tw-shadow: 0 2px 3px rgba(0,0,0,0.05);
  --tw-shadow-colored: 0 2px 3px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .shadow-\\[0_2px_3px_rgba\\(0\\2c 0\\2c 0\\2c 0\\.12\\)\\] {
  --tw-shadow: 0 2px 3px rgba(0,0,0,0.12);
  --tw-shadow-colored: 0 2px 3px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .shadow-inner {
  --tw-shadow: inset 0 2px 4px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: inset 0 2px 4px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .shadow-md {
  --tw-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .shadow-outline {
  --tw-shadow: 0 0 0 3px rgba(66, 153, 225, 0.5);
  --tw-shadow-colored: 0 0 0 3px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .shadow-sm {
  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .outline-none {
  outline: 2px solid transparent;
  outline-offset: 2px;
}

.tina-tailwind .outline {
  outline-style: solid;
}

.tina-tailwind .ring-1 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.tina-tailwind .ring-2 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.tina-tailwind .ring-inset {
  --tw-ring-inset: inset;
}

.tina-tailwind .ring-black {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(0 0 0 / var(--tw-ring-opacity));
}

.tina-tailwind .ring-blue-100 {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(180 219 255 / var(--tw-ring-opacity));
}

.tina-tailwind .ring-opacity-5 {
  --tw-ring-opacity: .05;
}

.tina-tailwind .\\!filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow) !important;
}

.tina-tailwind .filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.tina-tailwind .transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.tina-tailwind .transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.tina-tailwind .transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.tina-tailwind .transition-none {
  transition-property: none;
}

.tina-tailwind .transition-opacity {
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.tina-tailwind .duration-100 {
  transition-duration: 100ms;
}

.tina-tailwind .duration-150 {
  transition-duration: 150ms;
}

.tina-tailwind .duration-200 {
  transition-duration: 200ms;
}

.tina-tailwind .duration-300 {
  transition-duration: 300ms;
}

.tina-tailwind .duration-500 {
  transition-duration: 500ms;
}

.tina-tailwind .duration-75 {
  transition-duration: 75ms;
}

.tina-tailwind .duration-\\[150ms\\] {
  transition-duration: 150ms;
}

.tina-tailwind .ease-in {
  transition-timing-function: cubic-bezier(0.4, 0, 1, 1);
}

.tina-tailwind .ease-in-out {
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}

.tina-tailwind .ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}

.tina-tailwind .\\@container {
  container-type: inline-size;
}

.tina-tailwind .icon-parent svg {
      fill: currentColor;
    }

.tina-tailwind {
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
  font-size: 16px;
  line-height: 1.5;
  --tw-text-opacity: 1;
  color: rgb(86 81 101 / var(--tw-text-opacity));
}

/* if the last block has margin-bottom it makes the text box larger but some of it isn't clickable */

.tina-prose [data-slate-editor='true'] {
  padding-bottom: 0.5em;
}

/* prose adds backticks, which look like they should be editable */

.tina-prose [data-slate-editor='true'] .slate-code::before {
  content: '';
}

.tina-prose [data-slate-editor='true'] .slate-code::after {
  content: '';
}

.tina-prose [data-slate-editor='true'] .slate-code_block {
  margin: 0;
}

/* code lines as part of a block don't need the same background formatting */

.tina-prose [data-slate-editor='true'] .slate-code_block .slate-code {
  background: none;
}

/* prose makes the first p in a block slightly larger */

.tina-prose [data-slate-editor='true'] p:first-of-type {
  font-size: 1em;
}

/* experimental floating toolbar doesn't need a large text area */

.with-toolbar [data-slate-editor='true'] {
  min-height: 72px;
}

.tina-tailwind .placeholder\\:text-gray-300::placeholder {
  --tw-text-opacity: 1;
  color: rgb(178 173 190 / var(--tw-text-opacity));
}

.tina-tailwind .before\\:absolute::before {
  content: var(--tw-content);
  position: absolute;
}

.tina-tailwind .before\\:bottom-0::before {
  content: var(--tw-content);
  bottom: 0px;
}

.tina-tailwind .before\\:left-1\\/2::before {
  content: var(--tw-content);
  left: 50%;
}

.tina-tailwind .before\\:top-0::before {
  content: var(--tw-content);
  top: 0px;
}

.tina-tailwind .before\\:z-10::before {
  content: var(--tw-content);
  z-index: 10;
}

.tina-tailwind .before\\:mb-\\[1px\\]::before {
  content: var(--tw-content);
  margin-bottom: 1px;
}

.tina-tailwind .before\\:mt-\\[1px\\]::before {
  content: var(--tw-content);
  margin-top: 1px;
}

.tina-tailwind .before\\:h-\\[14px\\]::before {
  content: var(--tw-content);
  height: 14px;
}

.tina-tailwind .before\\:w-\\[18px\\]::before {
  content: var(--tw-content);
  width: 18px;
}

.tina-tailwind .before\\:-translate-x-1\\/2::before {
  content: var(--tw-content);
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .before\\:-translate-y-full::before {
  content: var(--tw-content);
  --tw-translate-y: -100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .before\\:translate-y-full::before {
  content: var(--tw-content);
  --tw-translate-y: 100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .before\\:bg-gray-200::before {
  content: var(--tw-content);
  --tw-bg-opacity: 1;
  background-color: rgb(225 221 236 / var(--tw-bg-opacity));
}

.tina-tailwind .before\\:content-\\[\\"\\"\\]::before {
  --tw-content: "";
  content: var(--tw-content);
}

.tina-tailwind .after\\:absolute::after {
  content: var(--tw-content);
  position: absolute;
}

.tina-tailwind .after\\:bottom-0::after {
  content: var(--tw-content);
  bottom: 0px;
}

.tina-tailwind .after\\:left-1\\/2::after {
  content: var(--tw-content);
  left: 50%;
}

.tina-tailwind .after\\:top-0::after {
  content: var(--tw-content);
  top: 0px;
}

.tina-tailwind .after\\:z-20::after {
  content: var(--tw-content);
  z-index: 20;
}

.tina-tailwind .after\\:mb-0::after {
  content: var(--tw-content);
  margin-bottom: 0px;
}

.tina-tailwind .after\\:mb-0\\.5::after {
  content: var(--tw-content);
  margin-bottom: 2px;
}

.tina-tailwind .after\\:mt-0::after {
  content: var(--tw-content);
  margin-top: 0px;
}

.tina-tailwind .after\\:mt-0\\.5::after {
  content: var(--tw-content);
  margin-top: 2px;
}

.tina-tailwind .after\\:h-\\[13px\\]::after {
  content: var(--tw-content);
  height: 13px;
}

.tina-tailwind .after\\:w-4::after {
  content: var(--tw-content);
  width: 16px;
}

.tina-tailwind .after\\:-translate-x-1\\/2::after {
  content: var(--tw-content);
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .after\\:-translate-y-full::after {
  content: var(--tw-content);
  --tw-translate-y: -100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .after\\:translate-y-full::after {
  content: var(--tw-content);
  --tw-translate-y: 100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .after\\:bg-white::after {
  content: var(--tw-content);
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}

.tina-tailwind .after\\:pl-1::after {
  content: var(--tw-content);
  padding-left: 4px;
}

.tina-tailwind .after\\:pl-1\\.5::after {
  content: var(--tw-content);
  padding-left: 6px;
}

.tina-tailwind .after\\:content-\\[\\"\\"\\]::after {
  --tw-content: "";
  content: var(--tw-content);
}

.tina-tailwind .after\\:content-\\[\\'\\/\\'\\]::after {
  --tw-content: '/';
  content: var(--tw-content);
}

.tina-tailwind .first\\:mt-0:first-child {
  margin-top: 0px;
}

.tina-tailwind .first\\:rounded-t:first-child {
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
}

.tina-tailwind .first\\:pt-3:first-child {
  padding-top: 12px;
}

.tina-tailwind .last\\:mb-0:last-child {
  margin-bottom: 0px;
}

.tina-tailwind .last\\:rounded-b:last-child {
  border-bottom-right-radius: 4px;
  border-bottom-left-radius: 4px;
}

.tina-tailwind .last\\:pb-3:last-child {
  padding-bottom: 12px;
}

.tina-tailwind .focus-within\\:border-blue-500:focus-within {
  --tw-border-opacity: 1;
  border-color: rgb(0 132 255 / var(--tw-border-opacity));
}

.tina-tailwind .focus-within\\:text-gray-900:focus-within {
  --tw-text-opacity: 1;
  color: rgb(37 35 54 / var(--tw-text-opacity));
}

.tina-tailwind .focus-within\\:shadow-outline:focus-within {
  --tw-shadow: 0 0 0 3px rgba(66, 153, 225, 0.5);
  --tw-shadow-colored: 0 0 0 3px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .hover\\:scale-100:hover {
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .hover\\:scale-103:hover {
  --tw-scale-x: 1.03;
  --tw-scale-y: 1.03;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .hover\\:border-gray-150:hover {
  --tw-border-opacity: 1;
  border-color: rgb(230 227 239 / var(--tw-border-opacity));
}

.tina-tailwind .hover\\:border-gray-200:hover {
  --tw-border-opacity: 1;
  border-color: rgb(225 221 236 / var(--tw-border-opacity));
}

.tina-tailwind .hover\\:bg-blue-500:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(0 132 255 / var(--tw-bg-opacity));
}

.tina-tailwind .hover\\:bg-blue-600:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(5 116 228 / var(--tw-bg-opacity));
}

.tina-tailwind .hover\\:bg-gray-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(237 236 243 / var(--tw-bg-opacity));
}

.tina-tailwind .hover\\:bg-gray-400\\/10:hover {
  background-color: rgb(145 140 158 / .1);
}

.tina-tailwind .hover\\:bg-gray-50:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(246 246 249 / var(--tw-bg-opacity));
}

.tina-tailwind .hover\\:bg-gray-50\\/50:hover {
  background-color: rgb(246 246 249 / .5);
}

.tina-tailwind .hover\\:bg-gray-500:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(113 108 127 / var(--tw-bg-opacity));
}

.tina-tailwind .hover\\:bg-red-600:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(220 38 38 / var(--tw-bg-opacity));
}

.tina-tailwind .hover\\:bg-white:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}

.tina-tailwind .hover\\:fill-gray-700:hover {
  fill: #433e52;
}

.tina-tailwind .hover\\:fill-gray-900:hover {
  fill: #252336;
}

.tina-tailwind .hover\\:text-blue-400:hover {
  --tw-text-opacity: 1;
  color: rgb(34 150 254 / var(--tw-text-opacity));
}

.tina-tailwind .hover\\:text-blue-500:hover {
  --tw-text-opacity: 1;
  color: rgb(0 132 255 / var(--tw-text-opacity));
}

.tina-tailwind .hover\\:text-blue-600:hover {
  --tw-text-opacity: 1;
  color: rgb(5 116 228 / var(--tw-text-opacity));
}

.tina-tailwind .hover\\:text-gray-600:hover {
  --tw-text-opacity: 1;
  color: rgb(86 81 101 / var(--tw-text-opacity));
}

.tina-tailwind .hover\\:text-gray-900:hover {
  --tw-text-opacity: 1;
  color: rgb(37 35 54 / var(--tw-text-opacity));
}

.tina-tailwind .hover\\:text-red-500:hover {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity));
}

.tina-tailwind .hover\\:text-white:hover {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity));
}

.tina-tailwind .hover\\:underline:hover {
  text-decoration-line: underline;
}

.tina-tailwind .hover\\:decoration-blue-400:hover {
  text-decoration-color: #2296fe;
}

.tina-tailwind .hover\\:decoration-blue-500:hover {
  text-decoration-color: #0084FF;
}

.tina-tailwind .hover\\:placeholder-gray-600:hover::placeholder {
  --tw-placeholder-opacity: 1;
  color: rgb(86 81 101 / var(--tw-placeholder-opacity));
}

.tina-tailwind .hover\\:opacity-100:hover {
  opacity: 1;
}

.tina-tailwind .hover\\:opacity-60:hover {
  opacity: .6;
}

.tina-tailwind .hover\\:opacity-70:hover {
  opacity: .7;
}

.tina-tailwind .hover\\:opacity-\\[\\.6\\]:hover {
  opacity: .6;
}

.tina-tailwind .hover\\:shadow:hover {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .hover\\:shadow-md:hover {
  --tw-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .focus\\:z-10:focus {
  z-index: 10;
}

.tina-tailwind .focus\\:border-blue-300:focus {
  --tw-border-opacity: 1;
  border-color: rgb(78 171 254 / var(--tw-border-opacity));
}

.tina-tailwind .focus\\:border-blue-400:focus {
  --tw-border-opacity: 1;
  border-color: rgb(34 150 254 / var(--tw-border-opacity));
}

.tina-tailwind .focus\\:border-blue-500:focus {
  --tw-border-opacity: 1;
  border-color: rgb(0 132 255 / var(--tw-border-opacity));
}

.tina-tailwind .focus\\:border-gray-500:focus {
  --tw-border-opacity: 1;
  border-color: rgb(113 108 127 / var(--tw-border-opacity));
}

.tina-tailwind .focus\\:bg-gray-50:focus {
  --tw-bg-opacity: 1;
  background-color: rgb(246 246 249 / var(--tw-bg-opacity));
}

.tina-tailwind .focus\\:text-blue-500:focus {
  --tw-text-opacity: 1;
  color: rgb(0 132 255 / var(--tw-text-opacity));
}

.tina-tailwind .focus\\:text-gray-900:focus {
  --tw-text-opacity: 1;
  color: rgb(37 35 54 / var(--tw-text-opacity));
}

.tina-tailwind .focus\\:shadow-outline:focus {
  --tw-shadow: 0 0 0 3px rgba(66, 153, 225, 0.5);
  --tw-shadow-colored: 0 0 0 3px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.tina-tailwind .focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}

.tina-tailwind .focus\\:ring-0:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.tina-tailwind .focus\\:ring-1:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.tina-tailwind .focus\\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.tina-tailwind .focus\\:ring-blue-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(0 132 255 / var(--tw-ring-opacity));
}

.tina-tailwind .focus\\:ring-gray-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(113 108 127 / var(--tw-ring-opacity));
}

.tina-tailwind .focus\\:ring-indigo-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(99 102 241 / var(--tw-ring-opacity));
}

.tina-tailwind .focus\\:ring-red-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(239 68 68 / var(--tw-ring-opacity));
}

.tina-tailwind .focus\\:ring-offset-2:focus {
  --tw-ring-offset-width: 2px;
}

.tina-tailwind .focus\\:ring-offset-gray-100:focus {
  --tw-ring-offset-color: #EDECF3;
}

.tina-tailwind .focus-visible\\:ring-2:focus-visible {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.tina-tailwind .focus-visible\\:ring-white:focus-visible {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(255 255 255 / var(--tw-ring-opacity));
}

.tina-tailwind .focus-visible\\:ring-opacity-75:focus-visible {
  --tw-ring-opacity: .75;
}

.tina-tailwind .focus-visible\\:ring-offset-2:focus-visible {
  --tw-ring-offset-width: 2px;
}

.tina-tailwind .focus-visible\\:ring-offset-teal-300:focus-visible {
  --tw-ring-offset-color: #5eead4;
}

.tina-tailwind .active\\:outline-none:active {
  outline: 2px solid transparent;
  outline-offset: 2px;
}

.tina-tailwind .group:hover .group-hover\\:scale-110 {
  --tw-scale-x: 1.1;
  --tw-scale-y: 1.1;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.tina-tailwind .group:hover .group-hover\\:border-blue-400 {
  --tw-border-opacity: 1;
  border-color: rgb(34 150 254 / var(--tw-border-opacity));
}

.tina-tailwind .group:hover .group-hover\\:bg-blue-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(34 150 254 / var(--tw-bg-opacity));
}

.tina-tailwind .group:hover .group-hover\\:bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(237 236 243 / var(--tw-bg-opacity));
}

.tina-tailwind .group:hover .group-hover\\:text-blue-400 {
  --tw-text-opacity: 1;
  color: rgb(34 150 254 / var(--tw-text-opacity));
}

.tina-tailwind .group:hover .group-hover\\:text-blue-500 {
  --tw-text-opacity: 1;
  color: rgb(0 132 255 / var(--tw-text-opacity));
}

.tina-tailwind .group:hover .group-hover\\:text-gray-800 {
  --tw-text-opacity: 1;
  color: rgb(54 49 69 / var(--tw-text-opacity));
}

.tina-tailwind .group:hover .group-hover\\:text-inherit {
  color: inherit;
}

.tina-tailwind .group:hover .group-hover\\:opacity-0 {
  opacity: 0;
}

.tina-tailwind .group:hover .group-hover\\:opacity-100 {
  opacity: 1;
}

.tina-tailwind .group:hover .group-hover\\:opacity-50 {
  opacity: .5;
}

.tina-tailwind .group:hover .group-hover\\:opacity-80 {
  opacity: .8;
}

.tina-tailwind .group:hover .group-hover\\:opacity-90 {
  opacity: .9;
}

@container (min-width: 24rem) {

  .tina-tailwind .\\@sm\\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@container (min-width: 32rem) {

  .tina-tailwind .\\@lg\\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}

@container (min-width: 42rem) {

  .tina-tailwind .\\@2xl\\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
}

@container (min-width: 56rem) {

  .tina-tailwind .\\@4xl\\:grid-cols-6 {
    grid-template-columns: repeat(6, minmax(0, 1fr));
  }
}

@container (min-width: 72rem) {

  .tina-tailwind .\\@6xl\\:grid-cols-8 {
    grid-template-columns: repeat(8, minmax(0, 1fr));
  }
}

@media (min-width: 560px) {

  .tina-tailwind .sm\\:items-center {
    align-items: center;
  }

  .tina-tailwind .sm\\:rounded-lg {
    border-radius: 8px;
  }

  .tina-tailwind .sm\\:p-6 {
    padding: 24px;
  }

  .tina-tailwind .sm\\:px-0 {
    padding-left: 0px;
    padding-right: 0px;
  }

  .tina-tailwind .sm\\:text-sm {
    font-size: 14px;
    line-height: 1.43;
  }

  .tina-tailwind .sm\\:duration-700 {
    transition-duration: 700ms;
  }
}

@media (min-width: 720px) {

  .tina-tailwind .md\\:w-\\[calc\\(100\\%-170px\\)\\] {
    width: calc(100% - 170px);
  }
}

@media (min-width: 1030px) {

  .tina-tailwind .lg\\:px-6 {
    padding-left: 24px;
    padding-right: 24px;
  }

  .tina-tailwind .lg\\:py-4 {
    padding-top: 16px;
    padding-bottom: 16px;
  }
}

.tina-tailwind .\\[\\&\\:last-child\\]\\:rounded-\\[0_0_5px_5px\\]:last-child {
  border-radius: 0 0 5px 5px;
}
`;const Nn=({children:a,position:b})=>{const c=Me(),[e,f]=d.useState(!1);return d.createElement(En,null,d.createElement("style",null,Mn),d.createElement("link",{rel:"stylesheet",href:"https://fonts.googleapis.com/css?family=Inter:400,600",media:"all"}),d.createElement(J,null,d.createElement("div",{className:"tina-tailwind"},d.createElement(An,{alerts:c.alerts}),d.createElement(Sm,null),c.sidebar&&d.createElement(No,{resizingSidebar:e,setResizingSidebar:f,position:b,sidebar:c.sidebar}),d.createElement(Ln,null)),d.createElement("div",{className:`${e?"pointer-events-none":""}`},a)))},On=({cms:a,children:b,position:c,styled:e=!0})=>d.createElement(zn,{cms:a},d.createElement(Nn,{position:c,styled:e},b)),Pn=On;function Qn(a,b){return c=>{const e=d.useMemo(()=>new fn(b),[b]);return d.createElement(On,{cms:e},d.createElement(a,{...c}))}}const Rn=({item:a,depth:b,setActiveFormId:c})=>{const e=Me(),f=d.useMemo(()=>e.state.forms.find(({tinaForm:b})=>a.formId===b.id),[a.formId]);return d.createElement("button",{key:a.path,onClick:()=>c(a.formId),className:`${["pl-6","pl-10","pl-14"][b]||"pl-12"} pr-6 py-3 w-full h-full bg-transparent border-none text-lg text-gray-700 group hover:bg-gray-50 transition-all ease-out duration-150 flex items-center justify-between gap-2`},d.createElement(sd,{className:"opacity-70 w-5 h-auto text-blue-500 flex-none"}),d.createElement("div",{className:"flex-1 flex flex-col gap-0.5 items-start"},d.createElement("div",{className:"group-hover:text-blue-500 font-sans text-xs font-semibold text-gray-700 whitespace-normal"},f.tinaForm.label),d.createElement("div",{className:"group-hover:text-blue-500 text-base truncate leading-tight text-gray-600"},f.tinaForm.id)))},Sn=({item:a,depth:b,setActiveFormId:c})=>{var e;return d.createElement("div",{className:"divide-y divide-gray-200"},d.createElement(Rn,{setActiveFormId:c,item:a,depth:b}),a.subItems&&d.createElement("ul",{className:"divide-y divide-gray-200"},null==(e=a.subItems)?void 0:e.map(a=>{if("document"===a.type)return d.createElement("li",{key:a.formId},d.createElement(Rn,{setActiveFormId:c,depth:b+1,item:a}))})))},Tn=a=>{const b=Me();return d.createElement(d.Fragment,null,d.createElement(j.u,{appear:!0,show:!0,enter:"transition-all ease-out duration-150",enterFrom:"opacity-0 -translate-x-1/2",enterTo:"opacity-100",leave:"transition-all ease-out duration-150",className:"overflow-scroll",leaveFrom:"opacity-100",leaveTo:"opacity-0 -translate-x-1/2"},b.state.formLists.map(c=>d.createElement("div",{key:c.id,className:"pt-16"},d.createElement(Un,{isEditing:a.isEditing,setActiveFormId:a=>{b.dispatch({type:"forms:set-active-form-id",value:a})},formList:c})))))},Un=a=>{const b=Me(),c=d.useMemo(()=>{var c;const d=[],e=[],f=[];a.formList.items.forEach(a=>{if("document"===a.type){const c=b.state.forms.find(({tinaForm:b})=>b.id===a.formId);c.tinaForm.global?e.push(a):d.push(a)}else d.push(a)}),(null==(c=d[0])?void 0:c.type)==="document"&&f.push({type:"list",label:"Documents"});let g=[];return e.length&&(g=[{type:"list",label:"Global Documents"},...e]),[...f,...d,...g]},[JSON.stringify(a.formList.items)]);return d.createElement("ul",null,d.createElement("li",{className:"divide-y divide-gray-200"},c.map((b,c)=>"list"===b.type?d.createElement("div",{key:b.label,className:`relative group text-left w-full bg-white shadow-sm
   border-gray-100 px-6 -mt-px pb-3 ${c>0?"pt-6 bg-gradient-to-b from-gray-50 via-white to-white":"pt-3"}`},d.createElement("span",{className:"text-sm tracking-wide font-bold text-gray-700 uppercase"},b.label)):d.createElement(Sn,{setActiveFormId:b=>a.setActiveFormId(b),key:b.formId,item:b,depth:0}))))},Vn=({children:a})=>{var b;const c=Ta(),e=void 0===(null==(b=null==c?void 0:c.sidebar)?void 0:b.renderNav)||c.sidebar.renderNav,{setFormIsPristine:f}=d.useContext(Ho),{formsRegistering:g,setFormsRegistering:h}=d.useContext(E.WA);d.useMemo(()=>c.events.subscribe("forms:register",a=>{"start"===a.value?h(!0):h(!1)}),[]);const i=c.state.forms.length>1,j=c.state.forms.find(({tinaForm:a})=>a.id===c.state.activeFormId),k=!!j;if(!c.state.formLists.length)return g?d.createElement(ym,null):d.createElement(d.Fragment,null," ",a," ");if(i&&!j)return d.createElement(Tn,{isEditing:k});const l=c.plugins.all("form:meta");return d.createElement(d.Fragment,null,j&&d.createElement(Wn,{isEditing:k,isMultiform:i},i&&d.createElement(Xn,{renderNav:e,activeForm:j}),!i&&d.createElement(Yn,{renderNav:e,activeForm:j}),l&&l.map(a=>d.createElement(d.Fragment,{key:a.name},d.createElement(a.Component,null))),d.createElement(gd,{form:j,onPristineChange:f})))},Wn=({isEditing:a,children:b})=>d.createElement("div",{className:"flex-1 flex flex-col flex-nowrap overflow-hidden h-full w-full relative bg-white",style:a?{transform:"none",animationName:"fly-in-left",animationDuration:"150ms",animationDelay:"0",animationIterationCount:1,animationTimingFunction:"ease-out"}:{transform:"translate3d(100%, 0, 0)"}},b),Xn=({activeForm:a,renderNav:b})=>{const c=Ta(),{sidebarWidth:e,formIsPristine:f}=d.useContext(Ho);return d.createElement("div",{className:`py-4 border-b border-gray-200 bg-white ${e>Jo&&b?"px-6":b?"pl-18 pr-24":"pl-6 pr-24"}`},d.createElement("div",{className:"max-w-form mx-auto flex flex-col items-start justify-center min-h-[2.5rem]"},d.createElement("button",{className:"pointer-events-auto text-xs -mt-1 mb-1.5 text-blue-400 hover:text-blue-500 hover:underline transition-all ease-out duration-150 font-medium flex items-center justify-start gap-0.5",onClick:()=>{const b=a.tinaForm.finalForm.getState();!0===b.invalid?c.alerts.error("Cannot navigate away from an invalid form."):c.dispatch({type:"forms:set-active-form-id",value:null})}},d.createElement(pd,{className:"h-auto w-5 inline-block opacity-70 -ml-1 -mr-0.5 -mt-px"}),"Form List"),d.createElement("span",{className:"block w-full text-lg mb-2 text-gray-700 font-medium leading-tight truncate"},a.tinaForm.label||a.tinaForm.id),d.createElement(hd,{pristine:f})))},Yn=({renderNav:a,activeForm:b})=>{const{sidebarWidth:c,formIsPristine:e,displayState:f}=d.useContext(Ho),g=(0,F.useWindowWidth)(),h=!!b.tinaForm.label&&b.tinaForm.label.replace(/^.*[\\\/]/,"");return d.createElement("div",{className:`py-4 border-b border-gray-200 bg-white ${{navOpen:"px-6",navClosed:"pl-18 pr-24",noNav:"pl-6 pr-24"}[a?c>Jo&&g>Jo||"fullscreen"===f&&g>Jo?"navOpen":"navClosed":"noNav"]}`},d.createElement("div",{className:"max-w-form mx-auto  flex flex-col items-start justify-center min-h-[2.5rem]"},h&&d.createElement("span",{className:"block w-full text-lg mb-[6px] text-gray-700 font-medium leading-tight truncate"},h),d.createElement(hd,{pristine:e})))};function Zn(a){return ad({tag:"svg",attr:{version:"1.1",viewBox:"0 0 16 16"},child:[{tag:"path",attr:{d:"M14.341 5.579c-0.347-0.473-0.831-1.027-1.362-1.558s-1.085-1.015-1.558-1.362c-0.806-0.591-1.197-0.659-1.421-0.659h-5.75c-0.689 0-1.25 0.561-1.25 1.25v11.5c0 0.689 0.561 1.25 1.25 1.25h9.5c0.689 0 1.25-0.561 1.25-1.25v-7.75c0-0.224-0.068-0.615-0.659-1.421zM12.271 4.729c0.48 0.48 0.856 0.912 1.134 1.271h-2.406v-2.405c0.359 0.278 0.792 0.654 1.271 1.134v0zM14 14.75c0 0.136-0.114 0.25-0.25 0.25h-9.5c-0.136 0-0.25-0.114-0.25-0.25v-11.5c0-0.135 0.114-0.25 0.25-0.25 0 0 5.749-0 5.75 0v3.5c0 0.276 0.224 0.5 0.5 0.5h3.5v7.75z"}},{tag:"path",attr:{d:"M9.421 0.659c-0.806-0.591-1.197-0.659-1.421-0.659h-5.75c-0.689 0-1.25 0.561-1.25 1.25v11.5c0 0.604 0.43 1.109 1 1.225v-12.725c0-0.135 0.115-0.25 0.25-0.25h7.607c-0.151-0.124-0.297-0.238-0.437-0.341z"}}]})(a)}function $n(a){return ad({tag:"svg",attr:{viewBox:"0 0 1024 1024"},child:[{tag:"path",attr:{d:"M955.7 856l-416-720c-6.2-10.7-16.9-16-27.7-16s-21.6 5.3-27.7 16l-416 720C56 877.4 71.4 904 96 904h832c24.6 0 40-26.6 27.7-48zM480 416c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v184c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V416zm32 352a48.01 48.01 0 0 1 0-96 48.01 48.01 0 0 1 0 96z"}}]})(a)}const _n=()=>d.createElement("a",{className:"flex-grow-0 flex w-full text-xs items-center py-1 px-4 text-yellow-600 bg-gradient-to-r from-yellow-50 to-yellow-100 border-b border-gray-150 shadow-sm",href:"https://tina.io/docs/tina-cloud/",target:"_blank"},d.createElement($n,{className:"w-5 h-auto inline-block mr-1 opacity-70 text-yellow-600"})," ","You are currently in",d.createElement("strong",{className:"ml-1 font-bold text-yellow-700"},"Local Mode")),ao=()=>{var a;const b=Ta(),c=null==(a=null==b?void 0:b.api)?void 0:a.tina,e=(null==c?void 0:c.isLocalMode)||!1,[f,g]=d.useState(null);return(d.useEffect(()=>{const a=async()=>{if("function"!=typeof(null==c?void 0:c.getBillingState))return;const a=await (null==c?void 0:c.getBillingState());g(a)};e||a()},[]),e||!f||"current"===f.billingState)?d.createElement(d.Fragment,null):d.createElement("div",{className:"flex-grow-0 flex flex-wrap w-full text-xs items-center justify-between gap-1.5 py-1.5 px-3 text-red-700 bg-gradient-to-br from-white via-red-50 to-red-100 border-b border-red-200"},d.createElement("span",{className:"flex items-center gap-1 font-bold"},d.createElement(td,{className:"w-5 h-auto flex-shrink-0 flex-grow-0 inline-block opacity-70 text-red-600"}),d.createElement("span",{className:"flex whitespace-nowrap"},"There is an issue with your billing.")),d.createElement("a",{className:"text-xs text-blue-600 underline decoration-blue-200 hover:text-blue-500 hover:decoration-blue-500 transition-all ease-out duration-150 flex items-center gap-1 self-end",href:`https://app.tina.io/projects/${f.clientId}/billing`,target:"_blank"},"Visit Billing Page",d.createElement(Id,{className:"w-5 h-full opacity-70"})))};function bo(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"},child:[{tag:"circle",attr:{cx:"12",cy:"12",r:"10"}},{tag:"line",attr:{x1:"12",y1:"16",x2:"12",y2:"12"}},{tag:"line",attr:{x1:"12",y1:"8",x2:"12.01",y2:"8"}}]})(a)}function co(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"},child:[{tag:"circle",attr:{cx:"12",cy:"12",r:"1"}},{tag:"circle",attr:{cx:"12",cy:"5",r:"1"}},{tag:"circle",attr:{cx:"12",cy:"19",r:"1"}}]})(a)}function eo(a){return ad({tag:"svg",attr:{viewBox:"0 0 16 16",fill:"currentColor"},child:[{tag:"path",attr:{fillRule:"evenodd",clipRule:"evenodd",d:"M9.5 1.1l3.4 3.5.1.4v2h-1V6H8V2H3v11h4v1H2.5l-.5-.5v-12l.5-.5h6.7l.3.1zM9 2v3h2.9L9 2zm4 14h-1v-3H9v-1h3V9h1v3h3v1h-3v3z"}}]})(a)}const fo=({plugin:a,close:b})=>{const c=Ta(),e=(0,d.useMemo)(()=>new sb({id:"create-form-id",label:"create-form",fields:a.fields,actions:a.actions,buttons:a.buttons,initialValues:a.initialValues||{},reset:a.reset,onChange:a.onChange,onSubmit:async d=>{await a.onSubmit(d,c).then(()=>{b()})}}),[b,c,a]);return d.createElement(N,{id:"content-creator-modal",onClick:a=>a.stopPropagation()},d.createElement(Pa,null,d.createElement(La,{close:b},a.name),d.createElement(P,null,d.createElement(gd,{form:{tinaForm:e}}))))};function go(a){return ad({tag:"svg",attr:{fill:"none",viewBox:"0 0 24 24",stroke:"currentColor"},child:[{tag:"path",attr:{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"}}]})(a)}function ho(a){return ad({tag:"svg",attr:{fill:"currentColor",viewBox:"0 0 16 16"},child:[{tag:"path",attr:{d:"M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"}}]})(a)}function io(a){return ad({tag:"svg",attr:{fill:"currentColor",viewBox:"0 0 16 16"},child:[{tag:"path",attr:{d:"M11.46.146A.5.5 0 0 0 11.107 0H4.893a.5.5 0 0 0-.353.146L.146 4.54A.5.5 0 0 0 0 4.893v6.214a.5.5 0 0 0 .146.353l4.394 4.394a.5.5 0 0 0 .353.146h6.214a.5.5 0 0 0 .353-.146l4.394-4.394a.5.5 0 0 0 .146-.353V4.893a.5.5 0 0 0-.146-.353L11.46.146zM8 4c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995A.905.905 0 0 1 8 4zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"}}]})(a)}const jo=(a,b,c)=>{const[e,f]=(0,d.useState)([]),[g,h]=(0,d.useState)(void 0),[i,j]=(0,d.useState)(!0),[k,l]=(0,d.useState)(void 0);return d.useEffect(()=>{const d=async()=>{if(a.api.tina.isAuthorized()){try{const{events:d,cursor:e}=await a.api.tina.fetchEvents(15,b);f([...c,...d]),h(e)}catch(g){a.alerts.error(`[${g.name}] GetEvents failed: ${g.message}`,3e4),console.error(g),f(void 0),l(g)}j(!1)}};j(!0),d()},[a,b]),{events:e,cursor:g,loading:i,error:k}};function ko(a){const[b,c]=(0,d.useState)({state:"loading",message:"Loading..."});return d.useEffect(()=>{const b=setInterval(async()=>{if(a.api.tina.isAuthorized()){const{events:b}=await a.api.tina.fetchEvents();0===b.length?c({state:"success",message:"No Events"}):b[0].isError?c({state:"error",message:`Sync Failure ${b[0].message}`}):c({state:"success",message:"Sync Successful"})}else c({state:"unauthorized",message:"Not Authenticated"})},5e3);return()=>clearInterval(b)},[a]),b}const lo=({cms:a})=>{const b=ko(a);return"error"!==b.state?null:d.createElement("div",{title:b.message,className:"flex-grow-0 flex text-xs items-center"},d.createElement(ye,{className:"w-6 h-full ml-2 text-red-500 fill-current"}))},mo=({cms:a})=>{const[b,c]=d.useState(void 0),[e,f]=d.useState([]),{events:g,cursor:h,loading:i,error:j}=jo(a,b,e);return d.createElement("div",{className:"flex flex-col gap-4 w-full h-full grow-0"},g.length>0&&d.createElement("div",{className:"shrink grow-0 overflow-scroll w-full rounded-md shadow ring-1 ring-black ring-opacity-5"},d.createElement("table",{className:"w-full divide-y divide-gray-100"},g.map((a,b)=>{const c=new Date(a.timestamp).toDateString(),e=new Date(a.timestamp).toTimeString();return d.createElement("tr",{className:b%2==0?"":"bg-gray-50"},a.isError?d.createElement("td",{key:`${a.id}_error_icon`,className:"py-3 pl-4 pr-0 w-0"},d.createElement(io,{className:"text-red-500 fill-current w-5 h-auto"})):d.createElement("td",{key:`${a.id}_ok_icon`,className:"py-3 pl-4 pr-0 w-0"},d.createElement(ho,{className:"text-green-500 fill-current w-5 h-auto"})),d.createElement("td",{key:`${a.id}_msg`,className:"whitespace-nowrap p-3 text-base text-gray-500"},a.message,a.isError&&d.createElement("div",{className:"w-full text-gray-300 text-xs mt-0.5"},a.id)),d.createElement("td",{key:`${a.id}_ts`,className:"whitespace-nowrap py-3 pl-3 pr-4 text-sm text-gray-500"},c,d.createElement("span",{className:"w-full block text-gray-300 text-xs mt-0.5"},e)))}).flat())),i&&d.createElement("div",{className:"text-sm text-gray-400 text-center"},"Loading..."),j&&d.createElement("div",null,"Error: ",j.message),d.createElement("div",{className:"text-center flex-1"},d.createElement(Fc,{onClick:()=>{f(g),c(h)}},"Load More Events")))},no=({closeEventsModal:a,cms:b})=>d.createElement(N,null,d.createElement(Na,null,d.createElement(La,{close:a},"Event Log"),d.createElement(P,{className:"flex h-full flex-col",padded:!0},d.createElement(mo,{cms:b})))),oo=({cms:a,setEventsOpen:b})=>{var c,e;const f=ko(a);return(null==(e=null==(c=a.api)?void 0:c.tina)?void 0:e.isLocalMode)?null:d.createElement(d.Fragment,null,d.createElement("button",{className:"text-lg px-4 py-2 first:pt-3 last:pb-3 tracking-wide whitespace-nowrap flex items-center opacity-80 text-gray-600 hover:text-blue-400 hover:bg-gray-50 hover:opacity-100",onClick:function(){b(!0)}},"error"!==f.state?d.createElement(go,{className:"w-6 h-auto mr-2 text-blue-400"}):d.createElement(ye,{className:"w-6 h-auto mr-2 text-red-400"})," ","Event Log"))},po=({isLocalMode:a,className:b="",children:c,showCollections:e,collectionsInfo:f,screens:g,cloudConfigs:h,contentCreators:i,sidebarWidth:k,RenderNavSite:l,RenderNavCloud:n,RenderNavCollection:o,...p})=>{const q=Ta(),{setEdit:r}=(0,E.i)(),[s,t]=d.useState(!1);return d.createElement("div",{className:`relative z-30 flex flex-col bg-white border-r border-gray-200 w-96 h-full ${b}`,style:{maxWidth:k+"px"},...p},d.createElement("div",{className:"border-b border-gray-200"},d.createElement(m.v,{as:"div",className:"relative block"},({open:a})=>d.createElement("div",null,d.createElement(m.v.Button,{className:`group w-full px-6 py-3 gap-2 flex justify-between items-center transition-colors duration-150 ease-out ${a?"bg-gray-50":"bg-transparent"}`},d.createElement("span",{className:"text-left inline-flex items-center text-xl tracking-wide text-gray-800 flex-1 gap-1 opacity-80 group-hover:opacity-100 transition-opacity duration-150 ease-out"},d.createElement("svg",{viewBox:"0 0 32 32",fill:"#EC4815",xmlns:"http://www.w3.org/2000/svg",className:"w-10 h-auto -ml-1"},d.createElement("path",{d:"M18.6466 14.5553C19.9018 13.5141 20.458 7.36086 21.0014 5.14903C21.5447 2.9372 23.7919 3.04938 23.7919 3.04938C23.7919 3.04938 23.2085 4.06764 23.4464 4.82751C23.6844 5.58738 25.3145 6.26662 25.3145 6.26662L24.9629 7.19622C24.9629 7.19622 24.2288 7.10204 23.7919 7.9785C23.355 8.85496 24.3392 17.4442 24.3392 17.4442C24.3392 17.4442 21.4469 22.7275 21.4469 24.9206C21.4469 27.1136 22.4819 28.9515 22.4819 28.9515H21.0296C21.0296 28.9515 18.899 26.4086 18.462 25.1378C18.0251 23.8669 18.1998 22.596 18.1998 22.596C18.1998 22.596 15.8839 22.4646 13.8303 22.596C11.7767 22.7275 10.4072 24.498 10.16 25.4884C9.91287 26.4787 9.81048 28.9515 9.81048 28.9515H8.66211C7.96315 26.7882 7.40803 26.0129 7.70918 24.9206C8.54334 21.8949 8.37949 20.1788 8.18635 19.4145C7.99321 18.6501 6.68552 17.983 6.68552 17.983C7.32609 16.6741 7.97996 16.0452 10.7926 15.9796C13.6052 15.914 17.3915 15.5965 18.6466 14.5553Z"}),d.createElement("path",{d:"M11.1268 24.7939C11.1268 24.7939 11.4236 27.5481 13.0001 28.9516H14.3511C13.0001 27.4166 12.8527 23.4155 12.8527 23.4155C12.1656 23.6399 11.3045 24.3846 11.1268 24.7939Z"})),d.createElement("span",null,"Tina")),d.createElement(lo,{cms:q}),d.createElement(co,{className:`flex-0 w-6 h-full inline-block group-hover:opacity-80 transition-all duration-300 ease-in-out transform ${a?"opacity-100 text-blue-400":"text-gray-400 opacity-50 hover:opacity-70"}`})),d.createElement("div",{className:"transform translate-y-full absolute bottom-3 right-5 z-50"},d.createElement(j.u,{enter:"transition duration-150 ease-out",enterFrom:"transform opacity-0 -translate-y-2",enterTo:"transform opacity-100 translate-y-0",leave:"transition duration-75 ease-in",leaveFrom:"transform opacity-100 translate-y-0",leaveTo:"transform opacity-0 -translate-y-2"},d.createElement(m.v.Items,{className:"bg-white border border-gray-150 rounded-lg shadow-lg flex flex-col items-stretch overflow-hidden"},d.createElement(m.v.Item,null,d.createElement("button",{className:"text-lg px-4 py-2 first:pt-3 last:pb-3 tracking-wide whitespace-nowrap flex items-center opacity-80 text-gray-600 hover:text-blue-400 hover:bg-gray-50 hover:opacity-100",onClick:async()=>{var a,b,c,d,e,f;Qo({displayState:"closed",sidebarWidth:null,resizingSidebar:!1}),(null==(b=null==(a=null==q?void 0:q.api)?void 0:a.tina)?void 0:b.logout)&&(await q.api.tina.logout(),(null==(d=null==(c=null==q?void 0:q.api)?void 0:c.tina)?void 0:d.onLogout)&&await (null==(f=null==(e=null==q?void 0:q.api)?void 0:e.tina)?void 0:f.onLogout())),r(!1)}},d.createElement(ud,{className:"w-6 h-auto mr-2 text-blue-400"})," Log Out")),d.createElement(m.v.Item,null,d.createElement(oo,{cms:q,setEventsOpen:t})))))))),s&&d.createElement(no,{cms:q,closeEventsModal:function(){t(!1)}}),c,d.createElement("div",{className:"px-6 flex-1 overflow-auto"},e&&d.createElement(d.Fragment,null,d.createElement("h4",{className:"flex space-x-1 justify-items-start uppercase font-sans font-bold text-sm mb-3 mt-8 text-gray-700"},d.createElement("span",null,"Collections"),a&&d.createElement("span",{className:"flex items-center"},d.createElement("a",{href:"https://tina.io/docs/schema/#defining-collections",target:"_blank"},d.createElement(bo,null)))),d.createElement(qo,{RenderNavCollection:o,...f})),(g.length>0||i.length)>0&&d.createElement(d.Fragment,null,d.createElement("h4",{className:"uppercase font-sans font-bold text-sm mb-3 mt-8 text-gray-700"},"Site"),d.createElement("ul",{className:"flex flex-col gap-4"},g.map(a=>d.createElement("li",{key:`nav-site-${a.name}`},d.createElement(l,{view:a}))),i.map((a,b)=>d.createElement(ro,{key:`plugin-${b}`,plugin:a})))),!!(null==h?void 0:h.length)&&d.createElement(d.Fragment,null,d.createElement("h4",{className:"uppercase font-sans font-bold text-sm mb-3 mt-8 text-gray-700"},"Cloud"),d.createElement("ul",{className:"flex flex-col gap-4"},h.map(a=>d.createElement("li",{key:`nav-site-${a.name}`},d.createElement(n,{config:a})))))))},qo=({collections:a,RenderNavCollection:b})=>0===a.length?d.createElement("div",null,"No collections found"):d.createElement("ul",{className:"flex flex-col gap-4"},a.map(a=>d.createElement("li",{key:`nav-collection-${a.name}`},d.createElement(b,{collection:a})))),ro=({plugin:a})=>{const[b,c]=d.useState(!1);return d.createElement("li",{key:a.name},d.createElement("button",{className:"text-base tracking-wide text-gray-500 hover:text-blue-600 flex items-center opacity-90 hover:opacity-100",onClick:()=>{c(!0)}},d.createElement(eo,{className:"mr-3 h-6 opacity-80 w-auto"})," ",a.name),b&&d.createElement(fo,{plugin:a,close:()=>c(!1)}))},so=()=>{const{resizingSidebar:a,setResizingSidebar:b,fullscreen:c,setSidebarWidth:e,displayState:f}=d.useContext(Ho);return(d.useEffect(()=>{const a=()=>b(!1);return window.addEventListener("mouseup",a),()=>{window.removeEventListener("mouseup",a)}},[]),d.useEffect(()=>{const b=a=>{e(b=>{const c=b+a.movementX,d=window.innerWidth-8;return c<Io?Io:c>d?d:c})};return a&&(window.addEventListener("mousemove",b),document.body.classList.add("select-none")),()=>{window.removeEventListener("mousemove",b),document.body.classList.remove("select-none")}},[a]),c)?null:d.createElement("div",{onMouseDown:()=>b(!0),className:`z-100 absolute top-1/2 right-px w-2 h-32 bg-white rounded-r-md border border-gray-150 shadow-sm hover:shadow-md origin-left transition-all duration-150 ease-out transform translate-x-full -translate-y-1/2 group hover:bg-gray-50 ${"closed"!==f?"opacity-100":"opacity-0"} ${a?"scale-110":"scale-90 hover:scale-100"}`,style:{cursor:"grab"}},d.createElement("span",{className:"absolute top-1/2 left-1/2 h-4/6 w-px bg-gray-200 transform -translate-y-1/2 -translate-x-1/2 opacity-30 transition-opacity duration-150 ease-out group-hover:opacity-100"}))},to=d.createContext({currentBranch:null,setCurrentBranch:a=>{console.warn("BranchContext not initialized")}}),uo=({currentBranch:a,setCurrentBranch:b,children:c})=>d.createElement(to.Provider,{value:{currentBranch:a,setCurrentBranch:b}},c),vo=()=>{const a=d.useContext(to),{dispatch:b}=Wa("branch:change");return d.useEffect(()=>{b({branchName:a.currentBranch})},[a.currentBranch]),a};function wo(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{fill:"none",stroke:"#000",strokeWidth:"2",d:"M12,22 C17.5228475,22 22,17.5228475 22,12 C22,6.4771525 17.5228475,2 12,2 C6.4771525,2 2,6.4771525 2,12 C2,17.5228475 6.4771525,22 12,22 Z M12,15 L12,14 C12,13 12,12.5 13,12 C14,11.5 15,11 15,9.5 C15,8.5 14,7 12,7 C10,7 9,8.26413718 9,10 M12,16 L12,18"}}]})(a)}function xo(a){return ad({tag:"svg",attr:{viewBox:"0 0 512 512"},child:[{tag:"path",attr:{d:"M304 48c0 26.51-21.49 48-48 48s-48-21.49-48-48 21.49-48 48-48 48 21.49 48 48zm-48 368c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48zm208-208c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48zM96 256c0-26.51-21.49-48-48-48S0 229.49 0 256s21.49 48 48 48 48-21.49 48-48zm12.922 99.078c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48c0-26.509-21.491-48-48-48zm294.156 0c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48c0-26.509-21.49-48-48-48zM108.922 60.922c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.491-48-48-48z"}}]})(a)}function yo(a){const b=a.replace(/[^/\w-]+/g,"");return b.toLowerCase()}const zo=({listBranches:a,createBranch:b,chooseBranch:c})=>{var e,f;const g=Ta(),h=null==(f=null==(e=g.api)?void 0:e.tina)?void 0:f.isLocalMode,[i,j]=d.useState("loading"),[k,l]=d.useState([]),{currentBranch:m}=vo(),n=d.useMemo(()=>m,[]);d.useEffect(()=>()=>{n!=m&&window.location.reload()},[m]);const o=d.useCallback(a=>{j("loading"),b({branchName:yo(a),baseBranch:m}).then(async a=>{g.alerts.success("Branch created."),l(b=>[...b,{indexStatus:{status:"unknown"},name:a}]),j("ready")})},[]),p=d.useCallback(async()=>{j("loading"),await a().then(a=>{l(a),j("ready")}).catch(()=>j("error"))},[]);return d.useEffect(()=>{p()},[]),d.useEffect(()=>{if("ready"===i){const a=[];return k.filter(a=>{var b,c;return(null==(b=null==a?void 0:a.indexStatus)?void 0:b.status)==="inprogress"||(null==(c=null==a?void 0:a.indexStatus)?void 0:c.status)==="unknown"}).forEach(async b=>{const[c,d]=g.api.tina.waitForIndexStatus({ref:b.name});a.push(d),c.then(a=>{l(c=>{const d=Array.from(c),e=d.findIndex(a=>a.name===b.name);return d[e].indexStatus=a,d})}).catch(a=>{"AsyncPoller: cancelled"!==a.message&&console.error(a)})}),()=>{a.forEach(a=>{a()})}}},[i,k.length]),d.createElement("div",{className:"w-full flex justify-center p-5"},d.createElement("div",{className:"w-full max-w-form"},h?d.createElement("div",{className:"px-6 py-8 w-full h-full flex flex-col items-center justify-center"},d.createElement("p",{className:"text-base mb-4 text-center"},d.createElement($n,{className:"w-7 h-auto inline-block mr-0.5 opacity-70 text-yellow-600"})),d.createElement("p",{className:"text-base mb-6 text-center"},"Tina's branch switcher isn't available in local mode."," ",d.createElement("a",{target:"_blank",className:"transition-all duration-150 ease-out text-blue-600 hover:text-blue-400 hover:underline no-underline",href:"https://tina.io/docs/tina-cloud/"},"Learn more about moving to production with Tina Cloud.")),d.createElement("p",null,d.createElement(Fc,{href:"https://tina.io/docs/tina-cloud/",target:"_blank",as:"a"},"Read Our Docs"," ",d.createElement(xe,{className:"w-5 h-auto ml-1.5 opacity-80"})))):"loading"===i?d.createElement("div",{style:{margin:"32px auto",textAlign:"center"}},d.createElement(Kc,{color:"var(--tina-color-primary)"})):d.createElement(d.Fragment,null,"ready"===i?d.createElement(Bo,{currentBranch:m,branchList:k,onCreateBranch:a=>{o(a)},onChange:a=>{c(a)}}):d.createElement("div",{className:"px-6 py-8 w-full h-full flex flex-col items-center justify-center"},d.createElement("p",{className:"text-base mb-4 text-center"},"An error occurred while retrieving the branch list."),d.createElement(Fc,{className:"mb-4",onClick:p},"Try again ",d.createElement(Hd,{className:"w-6 h-full ml-1 opacity-70"}))))))},Ao=(a,b,c)=>{const d=a.filter(a=>!b||a.name.includes(b)||a.name===c),e=a.find(a=>a.name===c);return[e||{name:c,indexStatus:{status:"failed"}},...d.filter(a=>a.name!==c)]},Bo=({branchList:a,currentBranch:b,onCreateBranch:c,onChange:e})=>{const[f,g]=d.useState(""),[h,i]=d.useState(""),j=Ao(a,h,b);return d.createElement("div",{className:"flex flex-col gap-3"},d.createElement("div",{className:"block relative group"},d.createElement(ie,{placeholder:"Search",value:h,onChange:a=>i(a.target.value)}),""===h?d.createElement(Jd,{className:"absolute right-3 top-1/2 -translate-y-1/2 w-5 h-auto text-blue-500 opacity-70 group-hover:opacity-100 transition-all ease-out duration-150"}):d.createElement("button",{onClick:()=>{i("")},className:"outline-none focus:outline-none bg-transparent border-0 p-0 m-0 absolute right-2.5 top-1/2 -translate-y-1/2 opacity-50 hover:opacity-100 transition-all ease-out duration-150"},d.createElement(ze,{className:"w-5 h-auto text-gray-600"}))),0===j.length&&d.createElement("div",{className:"block relative text-gray-300 italic py-1"},"No branches to display"),j.length>0&&d.createElement("div",{className:"min-w-[192px] max-h-[24rem] overflow-y-auto flex flex-col w-full h-full rounded-lg shadow-inner bg-white border border-gray-200"},j.map(a=>{var c;const f=a.name===b,g=null==(c=null==a?void 0:a.indexStatus)?void 0:c.status;return d.createElement("div",{className:`relative text-base py-1.5 px-3 flex items-center gap-1.5 border-l-0 border-t-0 border-r-0 border-b border-gray-50 w-full outline-none transition-all ease-out duration-150 ${"complete"!==g?"bg-gray-50 text-gray-400 pointer-events-none":f?"cursor-pointer bg-blue-50 text-blue-800 pointer-events-none hover:text-blue-500 focus:text-blue-500 focus:bg-gray-50 hover:bg-gray-50":"cursor-pointer hover:text-blue-500 focus:text-blue-500 focus:bg-gray-50 hover:bg-gray-50"}`,key:a.name,onClick:()=>{"complete"===g&&e(a.name)}},f&&d.createElement(zd,{className:"w-5 h-auto text-blue-500/70"}),a.name,"unknown"===g&&d.createElement("span",{className:"flex-1 w-full flex justify-end items-center gap-2 text-blue-500"},d.createElement("span",{className:"opacity-50 italic"},"Unknown"),d.createElement(wo,{className:"w-5 h-auto opacity-70"})),"inprogress"===g&&d.createElement("span",{className:"flex-1 w-full flex justify-end items-center gap-2 text-blue-500"},d.createElement("span",{className:"opacity-50 italic"},"Indexing"),d.createElement(xo,{className:"w-5 h-auto opacity-70 animate-spin"})),"failed"===g&&d.createElement("span",{className:"flex-1 w-full flex justify-end items-center gap-2 text-red-500"},d.createElement("span",{className:"opacity-50 italic"},"Indexing failed"),d.createElement(td,{className:"w-5 h-auto opacity-70"})),"timeout"===g&&d.createElement("span",{className:"flex-1 w-full flex justify-end items-center gap-2 text-red-500"},d.createElement("span",{className:"opacity-50 italic"},"Indexing timed out"),d.createElement(td,{className:"w-5 h-auto opacity-70"})),f&&d.createElement("span",{className:"opacity-70 italic"}," (current)"))})),d.createElement("div",{className:"border-t border-gray-150 pt-4 mt-3 flex flex-col gap-3"},d.createElement("div",{className:"text-sm"},"Create a new branch from ",d.createElement("b",null,b),". Once created you will need to wait for indexing to complete before you can switch branches."),d.createElement("div",{className:"flex justify-between items-center w-full gap-3"},d.createElement(ie,{placeholder:"Branch Name",value:f,onChange:a=>g(a.target.value)}),d.createElement(Fc,{className:"flex-0 flex items-center gap-2 whitespace-nowrap",size:"medium",variant:"white",disabled:""===f,onClick:()=>c(f)},d.createElement(Gd,{className:"w-5 h-auto opacity-70"})," Create Branch"))))};class Co{constructor(Do){this.__type="screen",this.Icon=function(a){return ad({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M5.559 8.855c.166 1.183.789 3.207 3.087 4.079C11 13.829 11 14.534 11 15v.163c-1.44.434-2.5 1.757-2.5 3.337 0 1.93 1.57 3.5 3.5 3.5s3.5-1.57 3.5-3.5c0-1.58-1.06-2.903-2.5-3.337V15c0-.466 0-1.171 2.354-2.065 2.298-.872 2.921-2.896 3.087-4.079C19.912 8.441 21 7.102 21 5.5 21 3.57 19.43 2 17.5 2S14 3.57 14 5.5c0 1.552 1.022 2.855 2.424 3.313-.146.735-.565 1.791-1.778 2.252-1.192.452-2.053.953-2.646 1.536-.593-.583-1.453-1.084-2.646-1.536-1.213-.461-1.633-1.517-1.778-2.252C8.978 8.355 10 7.052 10 5.5 10 3.57 8.43 2 6.5 2S3 3.57 3 5.5c0 1.602 1.088 2.941 2.559 3.355zM17.5 4c.827 0 1.5.673 1.5 1.5S18.327 7 17.5 7 16 6.327 16 5.5 16.673 4 17.5 4zm-4 14.5c0 .827-.673 1.5-1.5 1.5s-1.5-.673-1.5-1.5.673-1.5 1.5-1.5 1.5.673 1.5 1.5zM6.5 4C7.327 4 8 4.673 8 5.5S7.327 7 6.5 7 5 6.327 5 5.5 5.673 4 6.5 4z"}}]})(a)},this.name="Select Branch",this.layout="popup",this.Component=()=>d.createElement(zo,{listBranches:this.listBranches,createBranch:this.createBranch,chooseBranch:this.chooseBranch}),this.listBranches=Do.listBranches,this.createBranch=Do.createBranch,this.chooseBranch=Do.chooseBranch}}const Eo=()=>{const[a,b]=d.useState(!1),{currentBranch:c}=vo();return d.createElement(d.Fragment,null,d.createElement("div",{className:"flex-grow-0 flex justify-between items-center gap-2 w-full max-w-full text-xs items-center py-2 px-4 text-gray-500 bg-gradient-to-r from-white to-gray-50 border-b border-gray-150 gap-2"},d.createElement(zd,{className:"shrink-0 w-5 h-auto text-blue-500/70"})," ",d.createElement("span",{className:"shrink-"},"Branch"),d.createElement("div",{className:"flex-1 min-w-0 flex items-center justify-start"},d.createElement(Fo,{currentBranch:c,openModal:()=>b(!0)}))),a&&d.createElement(Go,{close:()=>{b(!1)}}))},Fo=({currentBranch:a="main",openModal:b})=>d.createElement("button",{className:"flex min-w-0\tshrink gap-1.5 items-center justify-between form-select h-7 px-2.5 border border-gray-200 bg-white text-gray-700 hover:text-blue-500 transition-color duration-150 ease-out rounded-md shadow-sm focus:outline-none focus:shadow-outline-blue focus:border-blue-300 transition duration-150 ease-in-out text-[12px] leading-tight capitalize min-w-[5rem]",onClick:b},d.createElement("span",{className:"truncate max-w-full"},a),d.createElement(od,{className:"-mr-1 -ml-1 h-4 w-4 opacity-70 shrink-0","aria-hidden":"true"})),Go=({close:a})=>{const b=Me().api.tina,{setCurrentBranch:c}=vo();return d.createElement(N,null,d.createElement(Pa,null,d.createElement(La,{close:a},"Select Branch"),d.createElement(P,{padded:!1},d.createElement(zo,{listBranches:b.listBranches.bind(b),createBranch:async a=>await b.createBranch(a),chooseBranch:c}))))},Ho=d.createContext(null),Io=360,Jo=1e3,Ko="tina.sidebarState",Lo="tina.sidebarWidth",Mo="open";function No({position:a="displace",resizingSidebar:b,setResizingSidebar:c,defaultWidth:e=440,sidebar:f}){var g,h,i;sc(f);const j=Ta();return j.enabled?d.createElement(Po,{position:(null==(g=null==j?void 0:j.sidebar)?void 0:g.position)||a,defaultWidth:(null==(h=null==j?void 0:j.sidebar)?void 0:h.defaultWidth)||e,resizingSidebar:b,setResizingSidebar:c,renderNav:void 0===(null==(i=null==j?void 0:j.sidebar)?void 0:i.renderNav)||j.sidebar.renderNav,sidebar:f}):null}const Oo=a=>({collections:a.api.admin.fetchCollections(),loading:!1}),Po=({sidebar:a,defaultWidth:b,position:c,renderNav:e,resizingSidebar:f,setResizingSidebar:g})=>{var h,i,k,l,m,n;const o=Ta(),p=Oo(o),[q,r]=d.useState(()=>o.flags.get("branch-switcher"));d.useEffect(()=>{o.events.subscribe("flag:set",({key:a,value:b})=>{"branch-switcher"===a&&r(b)})},[o.events]);const s=o.plugins.getType("screen"),t=o.plugins.getType("cloud-config");sc(a),sc(s);const u=s.all(),v=t.all(),[w,x]=(0,d.useState)(!1),[y,z]=(0,d.useState)(null),[A,B]=d.useState(b),[C,D]=d.useState(!0),E=a=>o.dispatch({type:"sidebar:set-display-state",value:a}),G=o.state.sidebarDisplayState;d.useEffect(()=>{if("undefined"!=typeof window){const a=window.localStorage.getItem(Ko),b=window.localStorage.getItem(Lo);null!==a&&E(JSON.parse(a)),null!==b&&B(JSON.parse(b))}},[]),d.useEffect(()=>{if("undefined"!=typeof window){const a=window.localStorage.getItem(Ko);null===a&&E(Mo)}},[Mo]),d.useEffect(()=>{"undefined"!=typeof window&&o.enabled&&window.localStorage.setItem(Ko,JSON.stringify(G))},[G,o]),d.useEffect(()=>{f&&window.localStorage.setItem(Lo,JSON.stringify(A))},[A,f]);const H=!1!==o.flags.get("tina-admin"),I=H?[]:o.plugins.getType("content-creator").all();d.useEffect(()=>{const a=()=>{"fullscreen"!==G&&Qo({position:c,displayState:G,sidebarWidth:A,resizingSidebar:f})};return a(),window.addEventListener("resize",a),()=>{window.removeEventListener("resize",a)}},[G,c,A,f]);const J=(0,F.useWindowWidth)(),K=e&&(A>Jo&&J>Jo||"fullscreen"===G&&J>Jo);return d.createElement(Ho.Provider,{value:{sidebarWidth:A,setSidebarWidth:B,displayState:G,setDisplayState:E,position:c,toggleFullscreen:()=>{"fullscreen"===G?E("open"):E("fullscreen")},toggleSidebarOpen:()=>{o.dispatch({type:"toggle-edit-state"})},resizingSidebar:f,setResizingSidebar:g,menuIsOpen:w,setMenuIsOpen:x,toggleMenu:()=>{x(a=>!a)},setActiveView:z,formIsPristine:C,setFormIsPristine:D}},d.createElement(d.Fragment,null,d.createElement(Wo,null,d.createElement(Vo,null),K&&d.createElement(po,{isLocalMode:null==(i=null==(h=o.api)?void 0:h.tina)?void 0:i.isLocalMode,showCollections:H,collectionsInfo:p,screens:u,cloudConfigs:v,contentCreators:I,sidebarWidth:A,RenderNavSite:({view:a})=>d.createElement(So,{view:a,onClick:()=>{z(a),x(!1)}}),RenderNavCloud:({config:a})=>d.createElement(To,{config:a}),RenderNavCollection:({collection:a})=>d.createElement(Uo,{onClick:()=>{x(!1)},collection:a})}),d.createElement(Xo,null,d.createElement(Ro,{displayNav:K,renderNav:e,isLocalMode:null==(l=null==(k=o.api)?void 0:k.tina)?void 0:l.isLocalMode,branchingEnabled:q}),d.createElement(Vn,null,d.createElement(a.placeholder,null)),y&&d.createElement(Ki,{screen:y,close:()=>z(null)})),d.createElement(so,null)),e&&(A<Jo+1||J<Jo+1)&&d.createElement(j.u,{show:w},d.createElement(j.u.Child,{as:d.Fragment,enter:"transform transition-all ease-out duration-300",enterFrom:"opacity-0 -translate-x-full",enterTo:"opacity-100 translate-x-0",leave:"transform transition-all ease-in duration-200",leaveFrom:"opacity-100 translate-x-0",leaveTo:"opacity-0 -translate-x-full"},d.createElement("div",{className:"fixed left-0 top-0 z-overlay h-full transform"},d.createElement(po,{isLocalMode:null==(n=null==(m=o.api)?void 0:m.tina)?void 0:n.isLocalMode,className:"rounded-r-md",showCollections:H,collectionsInfo:p,screens:u,cloudConfigs:v,contentCreators:I,sidebarWidth:A,RenderNavSite:({view:a})=>d.createElement(So,{view:a,onClick:()=>{z(a),x(!1)}}),RenderNavCloud:({config:a})=>d.createElement(To,{config:a}),RenderNavCollection:({collection:a})=>d.createElement(Uo,{onClick:()=>{x(!1)},collection:a})},d.createElement("div",{className:"absolute top-8 right-0 transform translate-x-full overflow-hidden"},d.createElement(Fc,{rounded:"right",variant:"secondary",onClick:()=>{x(!1)},className:"transition-opacity duration-150 ease-out"},d.createElement(cd,{className:"h-5 w-auto text-blue-500"})))))),d.createElement(j.u.Child,{as:d.Fragment,enter:"ease-out duration-300",enterFrom:"opacity-0",enterTo:"opacity-80",entered:"opacity-80",leave:"ease-in duration-200",leaveFrom:"opacity-80",leaveTo:"opacity-0"},d.createElement("div",{onClick:()=>{x(!1)},className:"fixed z-menu inset-0 bg-gradient-to-br from-gray-800 via-gray-900 to-black"})))))},Qo=({position:a="overlay",displayState:b,sidebarWidth:c,resizingSidebar:d})=>{const e=document.getElementsByTagName("body")[0],f=window.innerWidth;if("displace"===a)if(e.style.transition=d?"":"fullscreen"===b?"padding 0ms 150ms":"closed"===b?"padding 0ms 0ms":"padding 0ms 300ms","open"===b){const g=Math.min(c,f-440);e.style.paddingLeft=g+"px"}else e.style.paddingLeft="0";else e.style.transition="",e.style.paddingLeft="0"},Ro=({branchingEnabled:a,renderNav:b,displayNav:c,isLocalMode:e})=>{const{toggleFullscreen:f,displayState:g,setMenuIsOpen:h,toggleSidebarOpen:i}=d.useContext(Ho);return d.createElement("div",{className:"flex-grow-0 w-full overflow-visible z-20"},e&&d.createElement(_n,null),!e&&d.createElement(ao,null),a&&!e&&d.createElement(Eo,null),d.createElement("div",{className:"mt-4 -mb-14 w-full flex items-center justify-between pointer-events-none"},b&&!c&&d.createElement(Fc,{rounded:"right",variant:"secondary",onClick:()=>{h(!0)},className:"pointer-events-auto -ml-px"},d.createElement(Ed,{className:"h-6 w-auto text-blue-500"})),d.createElement("div",{className:"flex-1"}),d.createElement("div",{className:"flex items-center pointer-events-auto transition-opacity duration-150 ease-in-out -mr-px"},d.createElement(Fc,{rounded:"left",variant:"secondary",onClick:i,"aria-label":"closes cms sidebar"},d.createElement(Be,{className:"h-[18px] w-auto -mr-1 text-blue-500"})),d.createElement(Fc,{rounded:"custom",variant:"secondary",onClick:f},"fullscreen"===g?d.createElement("svg",{className:"h-5 w-auto -mx-1 text-blue-500",stroke:"currentColor",fill:"currentColor","stroke-width":"0",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},d.createElement("path",{d:"M2 15h7v7h2v-9H2v2zM15 2h-2v9h9V9h-7V2z"})):d.createElement(vd,{className:"h-5 -mx-1 w-auto text-blue-500"})))))},So=({view:a,onClick:b})=>d.createElement("button",{className:"text-base tracking-wide text-gray-500 hover:text-blue-600 flex items-center opacity-90 hover:opacity-100",value:a.name,onClick:b},d.createElement(a.Icon,{className:"mr-2 h-6 opacity-80 w-auto"})," ",a.name),To=({config:a})=>a.text?d.createElement("span",{className:"text-base tracking-wide text-gray-500 flex items-center opacity-90"},a.text," ",d.createElement("a",{target:"_blank",className:"ml-1 text-blue-600 hover:opacity-60",href:a.link.href},a.link.text)):d.createElement("span",{className:"text-base tracking-wide text-gray-500 hover:text-blue-600 flex items-center opacity-90 hover:opacity-100"},d.createElement(a.Icon,{className:"mr-2 h-6 opacity-80 w-auto"}),d.createElement("a",{target:"_blank",href:a.link.href},a.link.text)),Uo=({collection:a,onClick:b})=>{const c=Ta(),e=c.flags.get("tina-preview")||!1;return d.createElement("a",{onClick:b,href:`${e?`/${e}/index.html#`:"/admin#"}/collections/${a.name}/~`,className:"text-base tracking-wide text-gray-500 hover:text-blue-600 flex items-center opacity-90 hover:opacity-100"},d.createElement(Zn,{className:"mr-2 h-6 opacity-80 w-auto"})," ",a.label?a.label:a.name)},Vo=({})=>{const{displayState:a,toggleSidebarOpen:b}=d.useContext(Ho);return d.createElement(Fc,{rounded:"right",variant:"primary",size:"custom",onClick:b,className:`z-chrome absolute top-6 right-0 translate-x-full text-sm h-10 pl-3 pr-4 transition-all duration-300 ${"closed"!==a?"opacity-0 ease-in pointer-events-none":"ease-out pointer-events-auto"}`,"aria-label":"opens cms sidebar"},d.createElement(Fd,{className:"h-6 w-auto"}))},Wo=({children:a})=>{const{displayState:b,sidebarWidth:c,resizingSidebar:e}=d.useContext(Ho);return d.createElement("div",{className:`fixed top-0 left-0 h-screen z-base ${"closed"===b?"pointer-events-none":""}`},d.createElement("div",{className:`relative h-screen transform flex ${"closed"!==b?"":"-translate-x-full"} ${e?"transition-none":"closed"===b?"transition-all duration-300 ease-in":"fullscreen"===b?"transition-all duration-150 ease-out":"transition-all duration-300 ease-out"}`,style:{width:"fullscreen"===b?"100vw":c+"px",maxWidth:"fullscreen"===b?"100vw":"calc(100vw - 8px)",minWidth:"360px"}},a))},Xo=({children:a})=>d.createElement("div",{className:"relative left-0 w-full h-full flex flex-col items-stretch bg-white border-r border-gray-200 overflow-hidden"},a);class Yo{constructor(Zo){this.__type="form:meta",this.name=Zo.name,this.Component=Zo.Component}}function $o(a,b){const[c,e]=d.useState(b);return d.useEffect(()=>{const b=window.localStorage&&window.localStorage.getItem(a);null!=b&& void 0!=b&&e(JSON.parse(b))},[a]),[c,b=>{try{const d=b instanceof Function?b(c):b;e(d),localStorage.setItem(a,JSON.stringify(d))}catch(f){console.log(f)}}]}}}])