"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[379],{21118:function(a,b,c){c.r(b),c.d(b,{ActionButton:function(){return e.Kkx},AddIcon:function(){return e.dtP},AlertIcon:function(){return e.zMQ},Alerts:function(){return e.pCK},AlignCenter:function(){return e.Uns},AlignLeft:function(){return e.NiS},AlignRight:function(){return e.EL5},BaseTextField:function(){return e.QSS},BillingWarning:function(){return e.VaG},BlocksField:function(){return e.i6Q},BlocksFieldPlugin:function(){return e.S6J},BoldIcon:function(){return e.mY4},BranchBanner:function(){return e.HVU},BranchDataProvider:function(){return e.Tof},BranchSwitcher:function(){return e.Mr_},BranchSwitcherPlugin:function(){return e.Acx},Button:function(){return e.zxk},ButtonToggle:function(){return e.Fm0},ButtonToggleField:function(){return e.lh4},ButtonToggleFieldPlugin:function(){return e.t3t},CMSContext:function(){return e.if1},CheckboxGroup:function(){return e.cOn},CheckboxGroupField:function(){return e.csZ},CheckboxGroupFieldPlugin:function(){return e.Yqy},ChevronDownIcon:function(){return e.v4q},ChevronLeftIcon:function(){return e.wyc},ChevronRightIcon:function(){return e.XCv},ChevronUpIcon:function(){return e.g8U},Circle:function(){return e.Cdc},CircleCheck:function(){return e.yGk},CloseIcon:function(){return e.Two},CodeIcon:function(){return e.dNJ},ColorField:function(){return e.SGL},ColorFieldPlugin:function(){return e.X8T},ColorPicker:function(){return e.zH8},CursorPaginator:function(){return e.r9b},DEFAULT_MEDIA_UPLOAD_TYPES:function(){return e.HcM},DateField:function(){return e.Nnh},DateFieldPlugin:function(){return e.wIr},DeleteImageButton:function(){return e.wAQ},Dismissible:function(){return e.FRx},DragHandle:function(){return e.DUz},DragIcon:function(){return e.Vni},DummyMediaStore:function(){return e.V92},DuplicateIcon:function(){return e.NAN},ERROR_MISSING_CMS:function(){return e.ASJ},EditIcon:function(){return e.dY8},EllipsisVerticalIcon:function(){return e.zGg},ErrorIcon:function(){return e.Pz_},EventBus:function(){return e.Ndp},ExitIcon:function(){return e.iz5},FieldDescription:function(){return e.DE$},FieldError:function(){return e.cp7},FieldLabel:function(){return e.Qyk},FieldMeta:function(){return e.hfx},FieldWrapper:function(){return e.n2V},FieldsBuilder:function(){return e.g6G},FieldsGroup:function(){return e.H_J},File:function(){return e.$BE},Folder:function(){return e.gt0},FontLoader:function(){return e.JfN},Form:function(){return e.l09},FormActionMenu:function(){return e.qbs},FormBuilder:function(){return e.quP},FormLegacy:function(){return e.SkI},FormMetaPlugin:function(){return e._pg},FormPortalProvider:function(){return e.heb},FormStatus:function(){return e.PXv},FormWrapper:function(){return e.n51},FullscreenModal:function(){return e.OWb},GlobalFormPlugin:function(){return e.PHR},Group:function(){return e.ZAu},GroupField:function(){return e.Ngj},GroupFieldPlugin:function(){return e.sNi},GroupLabel:function(){return e.iGZ},GroupListField:function(){return e.L7U},GroupListFieldPlugin:function(){return e.q1h},GroupPanel:function(){return e._7A},HamburgerIcon:function(){return e.Uq7},HeadingIcon:function(){return e.bHp},HiddenField:function(){return e.SWv},HiddenFieldPlugin:function(){return e.$FD},IconButton:function(){return e.hU},ImageField:function(){return e.Mkw},ImageFieldPlugin:function(){return e.Tdy},ImageUpload:function(){return e.Urx},InfoIcon:function(){return e.szr},Input:function(){return e.IIB},ItalicIcon:function(){return e.h32},ItemClickTarget:function(){return e.Gvc},ItemDeleteButton:function(){return e.ItB},ItemHeader:function(){return e.sDB},LeftArrowIcon:function(){return e.qg},LinkIcon:function(){return e.xPt},ListField:function(){return e.NJp},ListFieldPlugin:function(){return e.XvI},LoadingDots:function(){return e.xgg},LocalWarning:function(){return e.DrE},LockIcon:function(){return e.mBM},MarkdownIcon:function(){return e.BuP},MdxFieldPlugin:function(){return e.EX8},MediaIcon:function(){return e.g4X},MediaListError:function(){return e.qlk},MediaManager:function(){return e.bae},Modal:function(){return e.u_l},ModalActions:function(){return e.nK9},ModalBody:function(){return e.fef},ModalFullscreen:function(){return e.Sb7},ModalHeader:function(){return e.xBx},ModalOverlay:function(){return e.ZAr},ModalPopup:function(){return e.ah7},ModalProvider:function(){return e.DYV},Nav:function(){return e.JL8},NumberField:function(){return e.Ki0},NumberFieldPlugin:function(){return e.gbx},NumberInput:function(){return e.Y2U},OrderedListIcon:function(){return e.GXq},OverflowMenu:function(){return e.PQB},PanelBody:function(){return e.Nak},PanelHeader:function(){return e.V9q},PopupModal:function(){return e.pdg},PullRequestIcon:function(){return e.ppW},QuoteIcon:function(){return e.PEf},RadioGroup:function(){return e.Eep},RadioGroupField:function(){return e.ofH},RadioGroupFieldPlugin:function(){return e.OWT},ReactDateTimeWithStyles:function(){return e.qpW},RedoIcon:function(){return e.zGS},Reference:function(){return e.s30},ReferenceField:function(){return e.je2},ReferenceFieldPlugin:function(){return e.P45},ReorderIcon:function(){return e.qnd},ReorderRowIcon:function(){return e.PaJ},ResetForm:function(){return e.z1H},ResetIcon:function(){return e.X5P},RightArrowIcon:function(){return e.ADv},Select:function(){return e.PhF},SelectField:function(){return e.mgC},SelectFieldPlugin:function(){return e.L8C},SettingsIcon:function(){return e.ewm},StrikethroughIcon:function(){return e.dwl},SyncStatus:function(){return e.wRo},TableIcon:function(){return e.$eq},TagsField:function(){return e.Lu6},TagsFieldPlugin:function(){return e.h2h},TextArea:function(){return e.Kx8},TextField:function(){return e.nvn},TextFieldPlugin:function(){return e.c9v},TextareaField:function(){return e.XLE},TextareaFieldPlugin:function(){return e.rkX},Tina:function(){return e.Dtb},TinaCMS:function(){return e.GRk},TinaCMSProvider:function(){return e.dwG},TinaField:function(){return e.BgQ},TinaForm:function(){return e.QMD},TinaIcon:function(){return e.AsI},TinaMediaStore:function(){return e.$z_},TinaProvider:function(){return e.H1r},TinaUI:function(){return e.OIE},Toggle:function(){return e.ZDl},ToggleField:function(){return e.gEl},ToggleFieldPlugin:function(){return e.gIn},TrashIcon:function(){return e.XHJ},UnderlineIcon:function(){return e.Adg},UndoIcon:function(){return e.UEU},UnorderedListIcon:function(){return e.JZr},UploadIcon:function(){return e.rG2},WarningIcon:function(){return e.aNP},classNames:function(){return e.AKq},formatBranchName:function(){return e.Mgf},getFilteredBranchList:function(){return e.zTE},selectFieldClasses:function(){return e.ngV},textFieldClasses:function(){return e.LsZ},useBranchData:function(){return e.Kz5},useCMS:function(){return e.kNL},useCMSEvent:function(){return e.fMb},useDismissible:function(){return e.bZA},useForm:function(){return e.cIP},useFormPortal:function(){return e.vqF},useFormScreenPlugin:function(){return e.OPS},useGlobalForm:function(){return e.t7j},useLocalForm:function(){return e.YL_},useLocalStorage:function(){return e._aR},useModalContainer:function(){return e.vz0},usePlugin:function(){return e.j7J},usePlugins:function(){return e._m2},useScreenPlugin:function(){return e.qS6},useSubscribable:function(){return e.eMv},useWatchFormValues:function(){return e.ws8},withPlugin:function(){return e.rWp},withPlugins:function(){return e.ABh},withTina:function(){return e.QQK},wrapFieldWithError:function(){return e.On},wrapFieldsWithMeta:function(){return e.ZeD},MdxFieldPluginExtendible:function(){return e.Pl1},NAMER:function(){return l.XA},resolveField:function(){return l.z8},AuthWallInner:function(){return Bc},Client:function(){return C},DEFAULT_LOCAL_TINA_GQL_SERVER_URL:function(){return Ib},LocalClient:function(){return Kb},RouteMappingPlugin:function(){return Ee},TinaAdmin:function(){return Be},TinaAdminApi:function(){return Ub},TinaCMSProvider2:function(){return $c},TinaCloudAuthWall:function(){return Dc},TinaCloudProvider:function(){return Cc},assertShape:function(){return Sb},asyncPoll:function(){return B},createClient:function(){return Rb},"default":function(){return $c},defineConfig:function(){return Je},defineLegacyConfig:function(){return He},defineSchema:function(){return Ge},defineStaticConfig:function(){return Ie},getStaticPropsForTina:function(){return ad},gql:function(){return cd},safeAssertShape:function(){return Tb},staticRequest:function(){return bd},useDocumentCreatorPlugin:function(){return Tc},useTinaAuthRedirect:function(){return Qb}});var d=c(1604),e=c(94382),f=c(82254),g=c(99120),h=c(39011),i=c(80622),j=c(49597),k=c(31230),l=c(88438),m=c(67294),n=c(7258),o=c(33680),p=c(41015),q=c(39711),r=c(96974),s=c(17106),t=c(72510),u=c(65440);const v="tinacms-auth",w=(a,b)=>new Promise(c=>{let d;window.addEventListener("message",function(a){"tinaCloudLogin"===a.data.source&&(d&&d.close(),c({id_token:a.data.id_token,access_token:a.data.access_token,refresh_token:a.data.refresh_token}))});const e=`${window.location.protocol}//${window.location.host}`;d=(function(a,b,c,d,e){const f=c.top.outerHeight/2+c.top.screenY-e/2,g=c.top.outerWidth/2+c.top.screenX-d/2;return c.open(a,b,"toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width="+d+", height="+e+", top="+f+", left="+g)})(`${b}/signin?clientId=${a}&origin=${e}`,"_blank",window,1e3,700)}),x=/^refs\/heads\/(.*)/,y=a=>{const b=a.match(x);return b[1]},z=d.z.object({name:d.z.string()}).array(),A=d.z.object({status:d.z.union([d.z.literal("complete"),d.z.literal("unknown"),d.z.literal("failed"),d.z.literal("inprogress")]).optional(),timestamp:d.z.number().optional()});function B(a,b=5e3,c=3e4){const d=new Date().getTime()+c;let e=!1;const f=(c,g)=>{Promise.resolve(a()).then(a=>{const h=new Date().getTime();e?g(new Error("AsyncPoller: cancelled")):a.done?c(a.data):h<d?setTimeout(f,b,c,g):g(new Error("AsyncPoller: reached timeout"))}).catch(a=>{g(a)})};return[new Promise(f),()=>{e=!0}]}class C{constructor({tokenStorage:D="MEMORY",...E}){var F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,$,_,aa,ba,ca,da,ea,fa,ga,ha,ia,ja,ka,la,ma,na,oa,pa,qa,ra,sa;if(this.events=new e.Ndp(),this.addPendingContent=async a=>{const b=`#graphql
mutation addPendingDocumentMutation(
  $relativePath: String!
  $collection: String!
  $template: String
) {
  addPendingDocument(
    relativePath: $relativePath
    template: $template
    collection: $collection
  ) {
    ... on Document {
      _sys {
        relativePath
        path
        breadcrumbs
        collection {
          slug
        }
      }
    }
  }
}`,c=await this.request(b,{variables:a});return c},this.getSchema=async()=>{if(!this.gqlSchema){const a=await this.request((0,f.K)(),{variables:{}});this.gqlSchema=(0,g.Z)(a)}return this.gqlSchema},this.getOptimizedQuery=async a=>{const b=await this.request(`query GetOptimizedQuery($queryString: String!) {
        getOptimizedQuery(queryString: $queryString)
      }`,{variables:{queryString:(0,h.S)(a)}});return(0,i.Qc)(b.getOptimizedQuery)},this.tinaGraphQLVersion=E.tinaGraphQLVersion,this.onLogin=null==(I=null==(H=null==(G=null==(F=E.schema)?void 0:F.config)?void 0:G.admin)?void 0:H.auth)?void 0:I.onLogin,this.onLogout=null==(M=null==(L=null==(K=null==(J=E.schema)?void 0:J.config)?void 0:K.admin)?void 0:L.auth)?void 0:M.onLogout,(null==(Q=null==(P=null==(O=null==(N=E.schema)?void 0:N.config)?void 0:O.admin)?void 0:P.auth)?void 0:Q.logout)&&(this.onLogout=null==(U=null==(T=null==(S=null==(R=E.schema)?void 0:R.config)?void 0:S.admin)?void 0:T.auth)?void 0:U.logout),(null==(Y=null==(X=null==(W=null==(V=E.schema)?void 0:V.config)?void 0:W.admin)?void 0:X.auth)?void 0:Y.getUser)&&(this.getUser=null==(aa=null==(_=null==($=null==(Z=E.schema)?void 0:Z.config)?void 0:$.admin)?void 0:_.auth)?void 0:aa.getUser),(null==(ea=null==(da=null==(ca=null==(ba=E.schema)?void 0:ba.config)?void 0:ca.admin)?void 0:da.auth)?void 0:ea.authenticate)&&(this.authenticate=null==(ia=null==(ha=null==(ga=null==(fa=E.schema)?void 0:fa.config)?void 0:ga.admin)?void 0:ha.auth)?void 0:ia.authenticate),E.schema){const ta=new l.dU({version:{fullVersion:"",major:"",minor:"",patch:""},meta:{flags:[]},...(0,l.oP)({...E.schema},[])});this.schema=ta}switch(this.options=E,(null==(ka=null==(ja=E.schema)?void 0:ja.config)?void 0:ka.contentApiUrlOverride)&&(this.options.customContentApiUrl=E.schema.config.contentApiUrlOverride),this.setBranch(E.branch),this.events.subscribe("branch:change",({branchName:a})=>{this.setBranch(a)}),this.clientId=E.clientId,D){case"LOCAL_STORAGE":this.getToken=async function(){const a=localStorage.getItem(v)||null;return a?await this.getRefreshedToken(a):{access_token:null,id_token:null,refresh_token:null}},this.setToken=function(a){localStorage.setItem(v,JSON.stringify(a,null,2))};break;case"MEMORY":this.getToken=async()=>this.token?await this.getRefreshedToken(this.token):{access_token:null,id_token:null,refresh_token:null},this.setToken=a=>{this.token=JSON.stringify(a,null,2)};break;case"CUSTOM":if(!E.getTokenFn)throw new Error("When CUSTOM token storage is selected, a getTokenFn must be provided");this.getToken=E.getTokenFn;break}(null==(oa=null==(na=null==(ma=null==(la=E.schema)?void 0:la.config)?void 0:ma.admin)?void 0:na.auth)?void 0:oa.getToken)&&(this.getToken=null==(sa=null==(ra=null==(qa=null==(pa=E.schema)?void 0:pa.config)?void 0:qa.admin)?void 0:ra.auth)?void 0:sa.getToken)}get isLocalMode(){return!1}setBranch(ua){var va,wa,xa,ya;const za=encodeURIComponent(ua);this.branch=za,this.assetsApiUrl=(null==(va=this.options.tinaioConfig)?void 0:va.assetsApiUrlOverride)||"https://assets.tinajs.io",this.frontendUrl=(null==(wa=this.options.tinaioConfig)?void 0:wa.frontendUrlOverride)||"https://app.tina.io",this.identityApiUrl=(null==(xa=this.options.tinaioConfig)?void 0:xa.identityApiUrlOverride)||"https://identity.tinajs.io",this.contentApiBase=(null==(ya=this.options.tinaioConfig)?void 0:ya.contentApiUrlOverride)||"https://content.tinajs.io",this.contentApiUrl=this.options.customContentApiUrl||`${this.contentApiBase}/${this.tinaGraphQLVersion}/content/${this.options.clientId}/github/${za}`}async request(Aa,{variables:Ba}){const Ca=await this.getToken(),Da={"Content-Type":"application/json"};(null==Ca?void 0:Ca.id_token)&&(Da.Authorization="Bearer "+(null==Ca?void 0:Ca.id_token));const Ea=await fetch(this.contentApiUrl,{method:"POST",headers:Da,body:JSON.stringify({query:"function"==typeof Aa?(0,h.S)(Aa(k.default)):Aa,variables:Ba})});if(200!==Ea.status){let Fa=`Unable to complete request, ${Ea.statusText}`;const Ga=await Ea.json();throw Ga.message&&(Fa=`${Fa}, Response: ${Ga.message}`),Fa=`${Fa}, Please check that the following information is correct: 
	clientId: ${this.options.clientId}
	branch: ${this.branch}.`,"main"!==this.branch&&(Fa=`${Fa}
	Note: This error can occur if the branch does not exist on GitHub or on Tina Cloud`),new Error(Fa)}const Ha=await Ea.json();if(Ha.errors)throw new Error(`Unable to fetch, errors: 
	${Ha.errors.map(a=>a.message).join("\n")}`);return Ha.data}get appDashboardLink(){return`${this.frontendUrl}/projects/${this.clientId}`}async checkSyncStatus({assetsSyncing:Ia}){const Ja=await this.fetchWithToken(`${this.assetsApiUrl}/v1/${this.clientId}/syncStatus`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({assetsSyncing:Ia})}),Ka=await Ja.json();return Ka}async fetchEvents(La,Ma){return this.isLocalMode?{events:[]}:(await this.fetchWithToken(`${this.contentApiBase}/events/${this.clientId}/${this.branch}?limit=${La||1}${Ma?`&cursor=${Ma}`:""}`,{method:"GET"})).json()}parseJwt(Na){const Oa=Na.split(".")[1],Pa=Oa.replace(/-/g,"+").replace(/_/g,"/"),Qa=decodeURIComponent(atob(Pa).split("").map(function(a){return"%"+("00"+a.charCodeAt(0).toString(16)).slice(-2)}).join(""));return JSON.parse(Qa)}async getProject(){const Ra=await this.fetchWithToken(`${this.identityApiUrl}/v2/apps/${this.clientId}`,{method:"GET"});return Ra.json()}async getRefreshedToken(Sa){const{access_token:Ta,id_token:Ua,refresh_token:Va}=JSON.parse(Sa),{exp:Wa,iss:Xa,client_id:Ya}=this.parseJwt(Ta);if(Date.now()/1e3>=Wa-120){const Za=await fetch(Xa,{method:"POST",headers:{"Content-Type":"application/x-amz-json-1.1","x-amz-target":"AWSCognitoIdentityProviderService.InitiateAuth"},body:JSON.stringify({ClientId:Ya,AuthFlow:"REFRESH_TOKEN_AUTH",AuthParameters:{REFRESH_TOKEN:Va,DEVICE_KEY:null}})});if(200!==Za.status)throw new Error("Unable to refresh auth tokens");const $a=await Za.json(),_a={access_token:$a.AuthenticationResult.AccessToken,id_token:$a.AuthenticationResult.IdToken,refresh_token:Va};return this.setToken(_a),Promise.resolve(_a)}return Promise.resolve({access_token:Ta,id_token:Ua,refresh_token:Va})}async isAuthorized(){return this.isAuthenticated()}async isAuthenticated(){return!!await this.getUser()}async logout(){this.setToken(null)}async authenticate(){const ab=await w(this.clientId,this.frontendUrl);return this.setToken(ab),ab}async fetchWithToken(bb,cb){const db=(null==cb?void 0:cb.headers)||{},eb=await this.getToken();return(null==eb?void 0:eb.id_token)&&(db.Authorization="Bearer "+(null==eb?void 0:eb.id_token)),await fetch(bb,{...cb,headers:new Headers(db)})}async getUser(){if(!this.clientId)return null;const fb=`${this.identityApiUrl}/v2/apps/${this.clientId}/currentUser`;try{const gb=await this.fetchWithToken(fb,{method:"GET"}),hb=await gb.json();if(!gb.status.toString().startsWith("2"))return console.error(hb.error),null;return hb}catch(ib){return console.error(ib),null}}async getBillingState(){if(!this.clientId)return null;const jb=`${this.identityApiUrl}/v2/apps/${this.clientId}/billing/state`;try{const kb=await this.fetchWithToken(jb,{method:"GET"}),lb=await kb.json();if(!kb.status.toString().startsWith("2"))return console.error(lb.error),null;return{clientId:lb.clientId||this.clientId,delinquencyDate:lb.delinquencyDate,billingState:lb.billingState}}catch(mb){return console.error(mb),null}}waitForIndexStatus({ref:nb}){try{const[ob,pb]=B(async()=>{try{const a=await this.getIndexStatus({ref:nb});if(!("inprogress"===a.status||"unknown"===a.status))return Promise.resolve({done:!0,data:a});return Promise.resolve({done:!1})}catch(b){return Promise.reject(b)}},5e3,9e5);return[ob,pb]}catch(qb){if("AsyncPoller: reached timeout"===qb.message)return console.warn(qb),{status:"timeout"};throw qb}}async getIndexStatus({ref:rb}){const sb=`${this.contentApiBase}/db/${this.clientId}/status/${rb}`,tb=await this.fetchWithToken(sb),ub=await tb.json(),vb=A.parse(ub);return vb}async listBranches(){try{const wb=`${this.contentApiBase}/github/${this.clientId}/list_branches`,xb=await this.fetchWithToken(wb,{method:"GET"}),yb=await xb.json(),zb=z.parse(yb),Ab=zb.map(async a=>{const b=await this.getIndexStatus({ref:a.name});return{...a,indexStatus:b}}),Bb=await Promise.all(Ab);return Bb}catch(Cb){throw console.error("There was an error listing branches.",Cb),Cb}}async createBranch({baseBranch:Db,branchName:Eb}){const Fb=`${this.contentApiBase}/github/${this.clientId}/create_branch`;try{const Gb=await this.fetchWithToken(Fb,{method:"POST",body:JSON.stringify({baseBranch:Db,branchName:Eb}),headers:{"Content-Type":"application/json"}});return await Gb.json().then(a=>y(a.data.ref))}catch(Hb){return console.error("There was an error creating a new branch.",Hb),null}}}const Ib="http://localhost:4001/graphql",Jb="tina.local.isLogedIn";class Kb extends C{constructor(Lb){const Mb={...Lb,clientId:"",branch:"",tinaGraphQLVersion:"",customContentApiUrl:Lb&&Lb.customContentApiUrl?Lb.customContentApiUrl:Ib};super(Mb)}get isLocalMode(){return!0}async logout(){localStorage.removeItem(Jb)}async authenticate(){return localStorage.setItem(Jb,"true"),{access_token:"LOCAL",id_token:"LOCAL",refresh_token:"LOCAL"}}async getUser(){return"true"===localStorage.getItem(Jb)}}function Nb(a){return m.createElement(e.u_l,null,m.createElement(e.ah7,null,m.createElement(e.xBx,null,a.title),m.createElement(e.fef,{padded:!0},m.createElement("p",null,a.message),a.error&&m.createElement(Ob,null,a.error)),m.createElement(e.nK9,null,a.actions.map(a=>m.createElement(Pb,{key:a.name,...a})))))}const Ob=({style:a={},...b})=>m.createElement("p",{style:{...a,color:"var(--tina-color-error)"},...b}),Pb=({name:a,primary:b,action:c})=>{const[d,f]=(0,m.useState)(!1),g=(0,m.useCallback)(async()=>{f(!0);try{await c(),f(!1)}catch(a){throw f(!1),a}},[c,f]);return m.createElement(e.zxk,{"data-test":a.replace(/\s/g,"-").toLowerCase(),variant:b?"primary":"secondary",onClick:g,busy:d,disabled:d},d&&m.createElement(e.xgg,null),!d&&a)},Qb=()=>{(0,m.useEffect)(()=>{const a=new URLSearchParams(window.location.search),b={code:a.get("code")||"",scope:a.get("scope")||"email",state:a.get("state")};b.code&&(localStorage.tina_auth_config=JSON.stringify(b))},[])},Rb=({clientId:a,isLocalClient:b=!0,branch:c,tinaioConfig:d,schema:e,apiUrl:f,tinaGraphQLVersion:g})=>b?new Kb({customContentApiUrl:f,schema:e}):new C({clientId:a||"",branch:c||"main",tokenStorage:"LOCAL_STORAGE",tinaioConfig:d,schema:e,tinaGraphQLVersion:g});function Sb(a,b,c){const d=b(n);try{d.validateSync(a)}catch(e){const f=c||`Failed to assertShape - ${e.message}`;throw new Error(f)}}function Tb(a,b){try{return Sb(a,b),!0}catch(c){return!1}}class Ub{constructor(Vb){this.api=Vb.api.tina,this.schema=Vb.api.tina.schema}async isAuthenticated(){return await this.api.isAuthenticated()}async checkGraphqlSchema({localSchema:Wb}){const Xb=await this.api.getSchema(),Yb=(0,j.I)((0,h.S)(Wb)),Zb=await (0,p.H)(Xb,Yb);return!(Zb.length>0)}fetchCollections(){return this.schema.getCollections()}async renameDocument({collection:$b,relativePath:_b,newRelativePath:ac}){await this.api.request(`#graphql
              mutation RenameDocument($collection: String!, $relativePath: String! $newRelativePath: String!) {
                updateDocument(collection: $collection, relativePath: $relativePath, params: {relativePath: $newRelativePath}){
    __typename
  }
              }
            `,{variables:{collection:$b,relativePath:_b,newRelativePath:ac}})}async deleteDocument({collection:bc,relativePath:cc}){await this.api.request(`#graphql
      mutation DeleteDocument($collection: String!, $relativePath: String!  ){
  deleteDocument(collection: $collection, relativePath: $relativePath){
    __typename
  }
}`,{variables:{collection:bc,relativePath:cc}})}async fetchCollection(dc,ec,fc="",gc,hc,ic,jc){let kc=null;const lc=null==jc?void 0:jc.filterField;if(lc&&(kc={[dc]:{[lc]:{}}}),lc&&(null==jc?void 0:jc.startsWith)&&(kc[dc][lc]={...kc[dc][lc]||{},startsWith:jc.startsWith}),lc&&(null==jc?void 0:jc.before)&&(kc[dc][lc]={...kc[dc][lc]||{},before:jc.before}),lc&&(null==jc?void 0:jc.after)&&(kc[dc][lc]={...kc[dc][lc]||{},after:jc.after}),lc&&(null==jc?void 0:jc.booleanEquals)!==null&&(null==jc?void 0:jc.booleanEquals)!==void 0&&(kc[dc][lc]={...kc[dc][lc]||{},eq:jc.booleanEquals}),!0===ec){const mc=hc||this.schema.getIsTitleFieldName(dc),nc="asc"===ic?await this.api.request(`#graphql
      query($collection: String!, $includeDocuments: Boolean!, $sort: String,  $limit: Float, $after: String, $filter: DocumentFilter, $folder: String){
        collection(collection: $collection){
          name
          label
          format
          templates
          documents(sort: $sort, after: $after, first: $limit, filter: $filter, folder: $folder) @include(if: $includeDocuments) {
            totalCount
            pageInfo {
              hasPreviousPage
              hasNextPage
              startCursor
              endCursor
            }
            edges {
              node {
                __typename
                ... on Folder {
                    name
                    path
                }
                ... on Document {
                  _sys {
                    title
                    template
                    breadcrumbs
                    path
                    basename
                    relativePath
                    filename
                    extension
                  }
                }
              }
            }
          }
        }
      }`,{variables:{collection:dc,includeDocuments:ec,folder:fc,sort:mc,limit:50,after:gc,filter:kc}}):await this.api.request(`#graphql
      query($collection: String!, $includeDocuments: Boolean!, $sort: String,  $limit: Float, $after: String, $filter: DocumentFilter, $folder: String) {
        collection(collection: $collection){
          name
          label
          format
          templates
          documents(sort: $sort, before: $after, last: $limit, filter: $filter, folder: $folder) @include(if: $includeDocuments) {
            totalCount
            pageInfo {
              hasPreviousPage
              hasNextPage
              startCursor
              endCursor
            }
            edges {
              node {
                __typename
                ... on Folder {
                    name
                    path
                }
                ... on Document {
                  _sys {
                    title
                    template
                    breadcrumbs
                    path
                    basename
                    relativePath
                    filename
                    extension
                  }
                }
              }
            }
          }
        }
      }`,{variables:{collection:dc,includeDocuments:ec,folder:fc,sort:mc,limit:50,after:gc,filter:kc}});return nc.collection}try{const oc=this.schema.getCollection(dc);return oc}catch(pc){console.error(`[TinaAdminAPI] Unable to fetchCollection(): ${pc.message}`);return}}async fetchDocument(qc,rc){const sc=await this.api.request(`#graphql
      query($collection: String!, $relativePath: String!) {
        document(collection:$collection, relativePath:$relativePath) {
          ... on Document {
            _values
          }
        }
      }`,{variables:{collection:qc,relativePath:rc}});return sc}async createDocument(tc,uc,vc){const wc=await this.api.request(`#graphql
      mutation($collection: String!, $relativePath: String!, $params: DocumentMutation!) {
        createDocument(
          collection: $collection,
          relativePath: $relativePath,
          params: $params
        ){__typename}
      }`,{variables:{collection:tc,relativePath:uc,params:vc}});return wc}async updateDocument(xc,yc,zc){const Ac=await this.api.request(`#graphql
      mutation($collection: String!, $relativePath: String!, $params: DocumentUpdateMutation!) {
        updateDocument(
          collection: $collection,
          relativePath: $relativePath,
          params: $params
        ){__typename}
      }`,{variables:{collection:xc,relativePath:yc,params:zc}});return Ac}}const Bc=({children:a,cms:b,loginScreen:c,getModalActions:d})=>{var e,f,g,h,i;const j=b.api.tina,k=!j.isLocalMode&&!(null==(i=null==(h=null==(g=null==(f=null==(e=j.schema)?void 0:e.config)?void 0:f.config)?void 0:g.admin)?void 0:h.auth)?void 0:i.customAuth),[l,n]=(0,m.useState)(null),[p,q]=(0,m.useState)(!1);m.useEffect(()=>{j.isAuthenticated().then(a=>{a?(q(!0),b.enable()):new Promise(a=>setTimeout(a,500)).then(()=>{n("authenticate")})})},[]);const r=async()=>{if(await j.isAuthenticated())q(!0),n(null);else throw new Error("No access to repo")},s=d?d({closeModal:()=>{n(null)}}):[];return m.createElement(m.Fragment,null,"authenticate"===l&&m.createElement(Nb,{title:k?"Tina Cloud Authorization":"Enter into edit mode",message:k?"To save edits, Tina Cloud authorization is required. On save, changes will get commited using your account.":"To save edits, enter into edit mode. On save, changes will saved to the local filesystem.",close,actions:[...s,{action:async()=>{(0,o.D_)(!1),window.location.reload()},name:"Close",primary:!1},{name:k?"Continue to Tina Cloud":"Enter Edit Mode",action:async()=>{const a=await j.authenticate();"function"==typeof(null==j?void 0:j.onLogin)&&await (null==j?void 0:j.onLogin({token:a})),r()},primary:!0}]}),p?a:c||null)},Cc=a=>{const b=a.branch||"main",[c,d]=(0,e._aR)("tinacms-current-branch",b);Qb();const f=m.useMemo(()=>a.cms||new e.GRk({enabled:!0,sidebar:!0,isLocalClient:a.isLocalClient,clientId:a.clientId}),[a.cms]);f.api.tina?f.api.tina.setBranch(c):f.registerApi("tina",Rb({...a,branch:c})),f.api.admin||f.registerApi("admin",new Ub(f));const g=async()=>{var b,c,d,g,h,i,j;const k=Boolean(null==(c=null==(b=a.schema.config)?void 0:b.media)?void 0:c.tina);if(k)f.media.store=new e.$z_(f);else if((null==(g=null==(d=a.schema.config)?void 0:d.media)?void 0:g.loadCustomStore)||a.mediaStore){const l=(null==(i=null==(h=a.schema.config)?void 0:h.media)?void 0:i.loadCustomStore)||a.mediaStore;if(null==(j=l.prototype)?void 0:j.persist)f.media.store=new l(f.api.tina);else{const m=await l();f.media.store=new m(f.api.tina)}}else f.media.store=new e.V92()},h=async()=>{const{owner:b,repo:c}=a,d=await f.api.tina.listBranches({owner:b,repo:c});return Array.isArray(d)?d:[]},i=async a=>{const b=await f.api.tina.createBranch(a);return b};g();const[j,k]=m.useState(()=>f.flags.get("branch-switcher"));return m.useEffect(()=>{f.events.subscribe("flag:set",({key:a,value:b})=>{"branch-switcher"===a&&k(b)})},[f.events]),m.useEffect(()=>{let a;return j&&(a=new e.Acx({listBranches:h,createBranch:i,chooseBranch:d}),f.plugins.add(a)),()=>{j&&a&&f.plugins.remove(a)}},[j,a.branch]),m.useEffect(()=>{a.cmsCallback&&a.cmsCallback(f)},[]),m.createElement(e.Tof,{currentBranch:c,setCurrentBranch:a=>{d(a)}},m.createElement(e.H1r,{cms:f},m.createElement(Bc,{...a,cms:f})))},Dc=Cc;var Ec=`.tina-tailwind {
  line-height: 1.5;
  -webkit-text-size-adjust: 100%;
  -moz-tab-size: 4;
  tab-size: 4;
}

  .tina-tailwind *,
  .tina-tailwind ::before,
  .tina-tailwind ::after {
    box-sizing: border-box;
    border-width: 0;
    border-style: solid;
    border-color: transparent;
  }

  .tina-tailwind ::before,
  .tina-tailwind ::after {
    --tw-content: '';
  }

  .tina-tailwind hr {
    height: 0; /* 1 */
    color: inherit; /* 2 */
    border-top-width: 1px; /* 3 */
  }

  .tina-tailwind abbr:where([title]) {
    text-decoration: underline dotted;
  }

  .tina-tailwind h1,
  .tina-tailwind h2,
  .tina-tailwind h3,
  .tina-tailwind h4,
  .tina-tailwind h5,
  .tina-tailwind h6 {
    font-size: inherit;
    font-weight: inherit;
  }

  .tina-tailwind a {
    color: inherit;
    text-decoration: inherit;
  }

  .tina-tailwind b,
  .tina-tailwind strong {
    font-weight: bolder;
  }

  .tina-tailwind code,
  .tina-tailwind kbd,
  .tina-tailwind samp,
  .tina-tailwind pre {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; /* 1 */
    font-size: 1em; /* 2 */
  }

  .tina-tailwind small {
    font-size: 80%;
  }

  .tina-tailwind sub,
  .tina-tailwind sup {
    font-size: 75%;
    line-height: 0;
    position: relative;
    vertical-align: baseline;
  }

  .tina-tailwind sub {
    bottom: -0.25em;
  }

  .tina-tailwind sup {
    top: -0.5em;
  }

  .tina-tailwind table {
    text-indent: 0; /* 1 */
    border-color: inherit; /* 2 */
    border-collapse: collapse; /* 3 */
  }

  .tina-tailwind button,
  .tina-tailwind input,
  .tina-tailwind optgroup,
  .tina-tailwind select,
  .tina-tailwind textarea {
    font-family: inherit; /* 1 */
    font-size: 100%; /* 1 */
    line-height: inherit; /* 1 */
    color: inherit; /* 1 */
    margin: 0; /* 2 */
    padding: 0; /* 3 */
  }

  .tina-tailwind button,
  .tina-tailwind select {
    text-transform: none;
  }

  .tina-tailwind button,
  .tina-tailwind [type='button'],
  .tina-tailwind [type='reset'],
  .tina-tailwind [type='submit'] {
    -webkit-appearance: button; /* 1 */
    background-color: transparent; /* 2 */
    background-image: none; /* 2 */
  }

  .tina-tailwind :-moz-focusring {
    outline: auto;
  }

  .tina-tailwind :-moz-ui-invalid {
    box-shadow: none;
  }

  .tina-tailwind progress {
    vertical-align: baseline;
  }

  .tina-tailwind ::-webkit-inner-spin-button,
  .tina-tailwind ::-webkit-outer-spin-button {
    height: auto;
  }

  .tina-tailwind [type='search'] {
    -webkit-appearance: textfield; /* 1 */
    outline-offset: -2px; /* 2 */
  }

  .tina-tailwind ::-webkit-search-decoration {
    -webkit-appearance: none;
  }

  .tina-tailwind ::-webkit-file-upload-button {
    -webkit-appearance: button; /* 1 */
    font: inherit; /* 2 */
  }

  .tina-tailwind summary {
    display: list-item;
  }

  .tina-tailwind blockquote,
  .tina-tailwind dl,
  .tina-tailwind dd,
  .tina-tailwind h1,
  .tina-tailwind h2,
  .tina-tailwind h3,
  .tina-tailwind h4,
  .tina-tailwind h5,
  .tina-tailwind h6,
  .tina-tailwind hr,
  .tina-tailwind figure,
  .tina-tailwind p,
  .tina-tailwind pre {
    margin: 0;
  }

  .tina-tailwind fieldset {
    margin: 0;
    padding: 0;
  }

  .tina-tailwind legend {
    padding: 0;
  }

  .tina-tailwind ol,
  .tina-tailwind ul,
  .tina-tailwind menu {
    list-style: none;
    margin: 0;
    padding: 0;
  }

  .tina-tailwind li:before {
    display: none;
  }

  .tina-tailwind textarea {
    resize: vertical;
  }

  .tina-tailwind input::placeholder,
  .tina-tailwind textarea::placeholder {
    opacity: 1; /* 1 */
    color: #918c9e; /* 2 */
  }

  .tina-tailwind button,
  .tina-tailwind [role='button'] {
    cursor: pointer;
  }

  .tina-tailwind :disabled {
    cursor: default;
  }

  .tina-tailwind img,
  .tina-tailwind svg,
  .tina-tailwind video,
  .tina-tailwind canvas,
  .tina-tailwind audio,
  .tina-tailwind iframe,
  .tina-tailwind embed,
  .tina-tailwind object {
    display: block; /* 1 */
    vertical-align: middle; /* 2 */
  }

  .tina-tailwind img,
  .tina-tailwind video {
    max-width: 100%;
    height: auto;
  }

  .tina-tailwind [hidden] {
    display: none;
  }
*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(0 132 255 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
}
::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(0 132 255 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
}
.tina-tailwind .pointer-events-none {
  pointer-events: none;
}
.tina-tailwind .pointer-events-auto {
  pointer-events: auto;
}
.tina-tailwind .static {
  position: static;
}
.tina-tailwind .fixed {
  position: fixed;
}
.tina-tailwind .absolute {
  position: absolute;
}
.tina-tailwind .relative {
  position: relative;
}
.tina-tailwind .inset-0 {
  top: 0px;
  right: 0px;
  bottom: 0px;
  left: 0px;
}
.tina-tailwind .left-0 {
  left: 0px;
}
.tina-tailwind .left-2 {
  left: 8px;
}
.tina-tailwind .right-0 {
  right: 0px;
}
.tina-tailwind .top-0 {
  top: 0px;
}
.tina-tailwind .top-1\\/2 {
  top: 50%;
}
.tina-tailwind .top-10 {
  top: 40px;
}
.tina-tailwind .top-4 {
  top: 16px;
}
.tina-tailwind .top-8 {
  top: 32px;
}
.tina-tailwind .z-50 {
  z-index: 50;
}
.tina-tailwind .z-menu {
  z-index: 9800;
}
.tina-tailwind .z-overlay {
  z-index: 10600;
}
.tina-tailwind .mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.tina-tailwind .-ml-px {
  margin-left: -1px;
}
.tina-tailwind .-mt-0 {
  margin-top: -0px;
}
.tina-tailwind .-mt-0\\.5 {
  margin-top: -2px;
}
.tina-tailwind .mb-1 {
  margin-bottom: 4px;
}
.tina-tailwind .mb-2 {
  margin-bottom: 8px;
}
.tina-tailwind .mb-4 {
  margin-bottom: 16px;
}
.tina-tailwind .mb-6 {
  margin-bottom: 24px;
}
.tina-tailwind .mb-8 {
  margin-bottom: 32px;
}
.tina-tailwind .ml-1 {
  margin-left: 4px;
}
.tina-tailwind .ml-1\\.5 {
  margin-left: 6px;
}
.tina-tailwind .mr-1 {
  margin-right: 4px;
}
.tina-tailwind .mr-1\\.5 {
  margin-right: 6px;
}
.tina-tailwind .mr-2 {
  margin-right: 8px;
}
.tina-tailwind .mt-2 {
  margin-top: 8px;
}
.tina-tailwind .block {
  display: block;
}
.tina-tailwind .inline-block {
  display: inline-block;
}
.tina-tailwind .flex {
  display: flex;
}
.tina-tailwind .inline-flex {
  display: inline-flex;
}
.tina-tailwind .table {
  display: table;
}
.tina-tailwind .grid {
  display: grid;
}
.tina-tailwind .h-10 {
  height: 40px;
}
.tina-tailwind .h-12 {
  height: 48px;
}
.tina-tailwind .h-5 {
  height: 20px;
}
.tina-tailwind .h-6 {
  height: 24px;
}
.tina-tailwind .h-7 {
  height: 28px;
}
.tina-tailwind .h-auto {
  height: auto;
}
.tina-tailwind .h-full {
  height: 100%;
}
.tina-tailwind .h-screen {
  height: 100vh;
}
.tina-tailwind .w-0 {
  width: 0px;
}
.tina-tailwind .w-10 {
  width: 40px;
}
.tina-tailwind .w-12 {
  width: 48px;
}
.tina-tailwind .w-5 {
  width: 20px;
}
.tina-tailwind .w-56 {
  width: 224px;
}
.tina-tailwind .w-6 {
  width: 24px;
}
.tina-tailwind .w-7 {
  width: 28px;
}
.tina-tailwind .w-\\[15\\%\\] {
  width: 15%;
}
.tina-tailwind .w-auto {
  width: auto;
}
.tina-tailwind .w-full {
  width: 100%;
}
.tina-tailwind .max-w-0 {
  max-width: 0rem;
}
.tina-tailwind .max-w-form {
  max-width: 900px;
}
.tina-tailwind .max-w-full {
  max-width: 100%;
}
.tina-tailwind .max-w-lg {
  max-width: 32rem;
}
.tina-tailwind .max-w-screen-xl {
  max-width: 1280px;
}
.tina-tailwind .flex-1 {
  flex: 1 1 0%;
}
.tina-tailwind .flex-shrink-0 {
  flex-shrink: 0;
}
.tina-tailwind .shrink-0 {
  flex-shrink: 0;
}
.tina-tailwind .flex-grow-0 {
  flex-grow: 0;
}
.tina-tailwind .table-auto {
  table-layout: auto;
}
.tina-tailwind .origin-top-right {
  transform-origin: top right;
}
.tina-tailwind .-translate-x-full {
  --tw-translate-x: -100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.tina-tailwind .-translate-y-1\\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.tina-tailwind .translate-x-0 {
  --tw-translate-x: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.tina-tailwind .translate-x-full {
  --tw-translate-x: 100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.tina-tailwind .scale-100 {
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.tina-tailwind .scale-95 {
  --tw-scale-x: .95;
  --tw-scale-y: .95;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.tina-tailwind .transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.tina-tailwind .cursor-pointer {
  cursor: pointer;
}
.tina-tailwind .grid-flow-col {
  grid-auto-flow: column;
}
.tina-tailwind .flex-col {
  flex-direction: column;
}
.tina-tailwind .flex-wrap {
  flex-wrap: wrap;
}
.tina-tailwind .items-start {
  align-items: flex-start;
}
.tina-tailwind .items-end {
  align-items: flex-end;
}
.tina-tailwind .items-center {
  align-items: center;
}
.tina-tailwind .items-stretch {
  align-items: stretch;
}
.tina-tailwind .justify-start {
  justify-content: flex-start;
}
.tina-tailwind .justify-end {
  justify-content: flex-end;
}
.tina-tailwind .justify-center {
  justify-content: center;
}
.tina-tailwind .justify-between {
  justify-content: space-between;
}
.tina-tailwind .gap-0 {
  gap: 0px;
}
.tina-tailwind .gap-0\\.5 {
  gap: 2px;
}
.tina-tailwind .gap-1 {
  gap: 4px;
}
.tina-tailwind .gap-2 {
  gap: 8px;
}
.tina-tailwind .gap-3 {
  gap: 12px;
}
.tina-tailwind .gap-4 {
  gap: 16px;
}
.tina-tailwind .divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}
.tina-tailwind .divide-gray-150 > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(230 227 239 / var(--tw-divide-opacity));
}
.tina-tailwind .self-end {
  align-self: flex-end;
}
.tina-tailwind .justify-self-end {
  justify-self: end;
}
.tina-tailwind .overflow-hidden {
  overflow: hidden;
}
.tina-tailwind .overflow-y-auto {
  overflow-y: auto;
}
.tina-tailwind .truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.tina-tailwind .whitespace-normal {
  white-space: normal;
}
.tina-tailwind .whitespace-nowrap {
  white-space: nowrap;
}
.tina-tailwind .rounded {
  border-radius: 4px;
}
.tina-tailwind .rounded-full {
  border-radius: 9999px;
}
.tina-tailwind .rounded-lg {
  border-radius: 8px;
}
.tina-tailwind .rounded-md {
  border-radius: 6px;
}
.tina-tailwind .rounded-r-md {
  border-top-right-radius: 6px;
  border-bottom-right-radius: 6px;
}
.tina-tailwind .border {
  border-width: 1px;
}
.tina-tailwind .border-0 {
  border-width: 0;
}
.tina-tailwind .border-b {
  border-bottom-width: 1px;
}
.tina-tailwind .border-r {
  border-right-width: 1px;
}
.tina-tailwind .border-gray-100 {
  --tw-border-opacity: 1;
  border-color: rgb(237 236 243 / var(--tw-border-opacity));
}
.tina-tailwind .border-gray-150 {
  --tw-border-opacity: 1;
  border-color: rgb(230 227 239 / var(--tw-border-opacity));
}
.tina-tailwind .border-gray-200 {
  --tw-border-opacity: 1;
  border-color: rgb(225 221 236 / var(--tw-border-opacity));
}
.tina-tailwind .bg-blue-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(0 132 255 / var(--tw-bg-opacity));
}
.tina-tailwind .bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(237 236 243 / var(--tw-bg-opacity));
}
.tina-tailwind .bg-gray-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(246 246 249 / var(--tw-bg-opacity));
}
.tina-tailwind .bg-gray-50\\/30 {
  background-color: rgb(246 246 249 / .3);
}
.tina-tailwind .bg-transparent {
  background-color: transparent;
}
.tina-tailwind .bg-white {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}
.tina-tailwind .bg-gradient-to-b {
  background-image: linear-gradient(to bottom, var(--tw-gradient-stops));
}
.tina-tailwind .bg-gradient-to-br {
  background-image: linear-gradient(to bottom right, var(--tw-gradient-stops));
}
.tina-tailwind .from-blue-900 {
  --tw-gradient-from: #1D2C6C;
  --tw-gradient-to: rgb(29 44 108 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}
.tina-tailwind .from-gray-50\\/50 {
  --tw-gradient-from: rgb(246 246 249 / .5);
  --tw-gradient-to: rgb(246 246 249 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}
.tina-tailwind .from-gray-800 {
  --tw-gradient-from: #363145;
  --tw-gradient-to: rgb(54 49 69 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}
.tina-tailwind .via-gray-900 {
  --tw-gradient-to: rgb(37 35 54 / 0);
  --tw-gradient-stops: var(--tw-gradient-from), #252336, var(--tw-gradient-to);
}
.tina-tailwind .to-black {
  --tw-gradient-to: #000;
}
.tina-tailwind .to-gray-50 {
  --tw-gradient-to: #F6F6F9;
}
.tina-tailwind .to-gray-900 {
  --tw-gradient-to: #252336;
}
.tina-tailwind .fill-current {
  fill: currentColor;
}
.tina-tailwind .p-0 {
  padding: 0px;
}
.tina-tailwind .px-12 {
  padding-left: 48px;
  padding-right: 48px;
}
.tina-tailwind .px-20 {
  padding-left: 80px;
  padding-right: 80px;
}
.tina-tailwind .px-3 {
  padding-left: 12px;
  padding-right: 12px;
}
.tina-tailwind .px-4 {
  padding-left: 16px;
  padding-right: 16px;
}
.tina-tailwind .px-5 {
  padding-left: 20px;
  padding-right: 20px;
}
.tina-tailwind .px-6 {
  padding-left: 24px;
  padding-right: 24px;
}
.tina-tailwind .py-1 {
  padding-top: 4px;
  padding-bottom: 4px;
}
.tina-tailwind .py-10 {
  padding-top: 40px;
  padding-bottom: 40px;
}
.tina-tailwind .py-2 {
  padding-top: 8px;
  padding-bottom: 8px;
}
.tina-tailwind .py-3 {
  padding-top: 12px;
  padding-bottom: 12px;
}
.tina-tailwind .py-4 {
  padding-top: 16px;
  padding-bottom: 16px;
}
.tina-tailwind .py-5 {
  padding-top: 20px;
  padding-bottom: 20px;
}
.tina-tailwind .py-6 {
  padding-top: 24px;
  padding-bottom: 24px;
}
.tina-tailwind .py-8 {
  padding-top: 32px;
  padding-bottom: 32px;
}
.tina-tailwind .pl-18 {
  padding-left: 72px;
}
.tina-tailwind .pl-3 {
  padding-left: 12px;
}
.tina-tailwind .pl-5 {
  padding-left: 20px;
}
.tina-tailwind .pl-8 {
  padding-left: 32px;
}
.tina-tailwind .pr-0 {
  padding-right: 0px;
}
.tina-tailwind .pr-0\\.5 {
  padding-right: 2px;
}
.tina-tailwind .pr-3 {
  padding-right: 12px;
}
.tina-tailwind .pt-12 {
  padding-top: 48px;
}
.tina-tailwind .pt-4 {
  padding-top: 16px;
}
.tina-tailwind .text-left {
  text-align: left;
}
.tina-tailwind .text-center {
  text-align: center;
}
.tina-tailwind .font-sans {
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
}
.tina-tailwind .text-2xl {
  font-size: 24px;
  line-height: 1.33;
}
.tina-tailwind .text-4xl {
  font-size: 36px;
  line-height: 1.1;
}
.tina-tailwind .text-base {
  font-size: 16px;
  line-height: 1.5;
}
.tina-tailwind .text-md {
  font-size: 16px;
  line-height: 1.5;
}
.tina-tailwind .text-sm {
  font-size: 14px;
  line-height: 1.43;
}
.tina-tailwind .text-xl {
  font-size: 20px;
  line-height: 1.4;
}
.tina-tailwind .text-xs {
  font-size: 13px;
  line-height: 1.33;
}
.tina-tailwind .font-medium {
  font-weight: 500;
}
.tina-tailwind .font-semibold {
  font-weight: 600;
}
.tina-tailwind .uppercase {
  text-transform: uppercase;
}
.tina-tailwind .italic {
  font-style: italic;
}
.tina-tailwind .leading-5 {
  line-height: 20px;
}
.tina-tailwind .leading-normal {
  line-height: 1.5;
}
.tina-tailwind .leading-tight {
  line-height: 1.25;
}
.tina-tailwind .tracking-wide {
  letter-spacing: 0.025em;
}
.tina-tailwind .text-blue-400 {
  --tw-text-opacity: 1;
  color: rgb(34 150 254 / var(--tw-text-opacity));
}
.tina-tailwind .text-blue-500 {
  --tw-text-opacity: 1;
  color: rgb(0 132 255 / var(--tw-text-opacity));
}
.tina-tailwind .text-blue-600 {
  --tw-text-opacity: 1;
  color: rgb(5 116 228 / var(--tw-text-opacity));
}
.tina-tailwind .text-current {
  color: currentColor;
}
.tina-tailwind .text-gray-200 {
  --tw-text-opacity: 1;
  color: rgb(225 221 236 / var(--tw-text-opacity));
}
.tina-tailwind .text-gray-300 {
  --tw-text-opacity: 1;
  color: rgb(178 173 190 / var(--tw-text-opacity));
}
.tina-tailwind .text-gray-400 {
  --tw-text-opacity: 1;
  color: rgb(145 140 158 / var(--tw-text-opacity));
}
.tina-tailwind .text-gray-500 {
  --tw-text-opacity: 1;
  color: rgb(113 108 127 / var(--tw-text-opacity));
}
.tina-tailwind .text-gray-600 {
  --tw-text-opacity: 1;
  color: rgb(86 81 101 / var(--tw-text-opacity));
}
.tina-tailwind .text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(67 62 82 / var(--tw-text-opacity));
}
.tina-tailwind .text-gray-900 {
  --tw-text-opacity: 1;
  color: rgb(37 35 54 / var(--tw-text-opacity));
}
.tina-tailwind .text-red-400 {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity));
}
.tina-tailwind .text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity));
}
.tina-tailwind .text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity));
}
.tina-tailwind .underline {
  text-decoration-line: underline;
}
.tina-tailwind .decoration-blue-200 {
  text-decoration-color: #85C5FE;
}
.tina-tailwind .decoration-1 {
  text-decoration-thickness: 1px;
}
.tina-tailwind .underline-offset-2 {
  text-underline-offset: 2px;
}
.tina-tailwind .opacity-0 {
  opacity: 0;
}
.tina-tailwind .opacity-100 {
  opacity: 1;
}
.tina-tailwind .opacity-20 {
  opacity: .2;
}
.tina-tailwind .opacity-50 {
  opacity: .5;
}
.tina-tailwind .opacity-70 {
  opacity: .7;
}
.tina-tailwind .opacity-80 {
  opacity: .8;
}
.tina-tailwind .opacity-90 {
  opacity: .9;
}
.tina-tailwind .shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.tina-tailwind .shadow-2xl {
  --tw-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.25);
  --tw-shadow-colored: 0 25px 50px -12px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.tina-tailwind .shadow-inner {
  --tw-shadow: inset 0 2px 4px 0 rgb(0 0 0 / 0.05);
  --tw-shadow-colored: inset 0 2px 4px 0 var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.tina-tailwind .shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.tina-tailwind .outline {
  outline-style: solid;
}
.tina-tailwind .ring-1 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.tina-tailwind .ring-black {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(0 0 0 / var(--tw-ring-opacity));
}
.tina-tailwind .ring-opacity-5 {
  --tw-ring-opacity: .05;
}
.tina-tailwind .filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.tina-tailwind .transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.tina-tailwind .transition-all {
  transition-property: all;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.tina-tailwind .transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.tina-tailwind .transition-opacity {
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.tina-tailwind .duration-100 {
  transition-duration: 100ms;
}
.tina-tailwind .duration-150 {
  transition-duration: 150ms;
}
.tina-tailwind .duration-200 {
  transition-duration: 200ms;
}
.tina-tailwind .duration-300 {
  transition-duration: 300ms;
}
.tina-tailwind .duration-75 {
  transition-duration: 75ms;
}
.tina-tailwind .ease-in {
  transition-timing-function: cubic-bezier(0.4, 0, 1, 1);
}
.tina-tailwind .ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.tina-tailwind .icon-parent svg {
      fill: currentColor;
    }
.tina-tailwind {
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
  font-size: 16px;
  line-height: 1.5;
  --tw-text-opacity: 1;
  color: rgb(86 81 101 / var(--tw-text-opacity));
}
.tina-tailwind .hover\\:bg-blue-600:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(5 116 228 / var(--tw-bg-opacity));
}
.tina-tailwind .hover\\:bg-gray-50\\/50:hover {
  background-color: rgb(246 246 249 / .5);
}
.tina-tailwind .hover\\:text-blue-400:hover {
  --tw-text-opacity: 1;
  color: rgb(34 150 254 / var(--tw-text-opacity));
}
.tina-tailwind .hover\\:text-blue-500:hover {
  --tw-text-opacity: 1;
  color: rgb(0 132 255 / var(--tw-text-opacity));
}
.tina-tailwind .hover\\:text-blue-600:hover {
  --tw-text-opacity: 1;
  color: rgb(5 116 228 / var(--tw-text-opacity));
}
.tina-tailwind .hover\\:decoration-blue-400:hover {
  text-decoration-color: #2296fe;
}
.tina-tailwind .hover\\:opacity-100:hover {
  opacity: 1;
}
.tina-tailwind .hover\\:opacity-60:hover {
  opacity: .6;
}
.tina-tailwind .focus\\:border-blue-500:focus {
  --tw-border-opacity: 1;
  border-color: rgb(0 132 255 / var(--tw-border-opacity));
}
.tina-tailwind .focus\\:text-blue-400:focus {
  --tw-text-opacity: 1;
  color: rgb(34 150 254 / var(--tw-text-opacity));
}
.tina-tailwind .focus\\:text-gray-900:focus {
  --tw-text-opacity: 1;
  color: rgb(37 35 54 / var(--tw-text-opacity));
}
.tina-tailwind .focus\\:underline:focus {
  text-decoration-line: underline;
}
.tina-tailwind .focus\\:shadow-outline:focus {
  --tw-shadow: 0 0 0 3px rgba(66, 153, 225, 0.5);
  --tw-shadow-colored: 0 0 0 3px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.tina-tailwind .focus\\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}
.tina-tailwind .focus\\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.tina-tailwind .focus\\:ring-blue-500:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(0 132 255 / var(--tw-ring-opacity));
}
.tina-tailwind .group:hover .group-hover\\:border-gray-200 {
  --tw-border-opacity: 1;
  border-color: rgb(225 221 236 / var(--tw-border-opacity));
}
.tina-tailwind .group:hover .group-hover\\:bg-white {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}
.tina-tailwind .group:hover .group-hover\\:text-gray-600 {
  --tw-text-opacity: 1;
  color: rgb(86 81 101 / var(--tw-text-opacity));
}
.tina-tailwind .group:hover .group-hover\\:opacity-0 {
  opacity: 0;
}
.tina-tailwind .group:hover .group-hover\\:opacity-80 {
  opacity: .8;
}
.tina-tailwind .group:active .group-active\\:opacity-0 {
  opacity: 0;
}
.tina-tailwind .group:active .group-active\\:opacity-80 {
  opacity: .8;
}
`;class Fc{constructor(Gc){this.__type="content-creator",this.fields=Gc.fields,this.name=Gc.label,this.onNewDocument=Gc.onNewDocument,this.collections=Gc.collections,this.onChange=Gc.onChange,this.initialValues=Gc.initialValues}async onSubmit({collection:Hc,template:Ic,relativePath:Jc},Kc){try{const Lc=this.collections.find(a=>a.slug===Hc),Mc=Lc.format,Nc=-1*(Mc.length+1);let Oc=Jc;Oc=Jc.slice(Nc).toLocaleLowerCase()===`.${Mc}`?`${Jc.slice(0,-3)}.${Mc}`:`${Jc}.${Mc}`;const Pc={relativePath:Oc,collection:Hc,template:Ic};try{const Qc=await Kc.api.tina.addPendingContent(Pc);Qc.errors?Qc.errors.map(a=>{Kc.alerts.error(a.message)}):(Kc.alerts.info("Document created!"),"function"==typeof this.onNewDocument&&this.onNewDocument(Qc.addPendingDocument._sys))}catch(Rc){Kc.alerts.error(Rc.message)}}catch(Sc){Kc.alerts.error(Sc.message)}}}const Tc=a=>{const b=(0,e.kNL)(),[c,d]=m.useState({}),[f,g]=m.useState(null);m.useEffect(()=>{const e=async()=>{var e;const f=await b.api.tina.request(a=>a`
          {
            collections {
              label
              slug
              format
              templates
            }
          }
        `,{variables:{}}),h=[];f.collections.forEach(a=>{const b=a.slug,c=`${a.label}`;h.push({value:b,label:c})});let i;if(a&&a.filterCollections&&"function"==typeof a.filterCollections){const j=a.filterCollections(h);i=[{value:"",label:"Choose Collection"},...j]}else i=[{value:"",label:"Choose Collection"},...h];const k=[{value:"",label:"Choose Template"}];if(c.collection){const l=f.collections.find(a=>a.slug===c.collection);null==(e=null==l?void 0:l.templates)||e.forEach(a=>{k.push({value:a.name,label:a.label})})}g(new Fc({label:"Add Document",onNewDocument:a&&a.onNewDocument,collections:f.collections,onChange:async({values:a})=>{d(a)},initialValues:c,fields:[{component:"select",name:"collection",label:"Collection",description:"Select the collection.",options:i,validate:async(a,b,c)=>{if(!a)return!0}},{component:"select",name:"template",label:"Template",description:"Select the template.",options:k,validate:async(a,b,c)=>{if(!a&&k.length>1)return!c.dirty||"Required"}},{component:"text",name:"relativePath",label:"Name",description:"A unique name for the content. Example: \"newPost\" or \"blog_022021",placeholder:"newPost",validate:(a,b,c)=>{if(!a)return!c.dirty||"Required";const d=/^[_a-zA-Z0-9][\-_a-zA-Z0-9]*$/.test(a);if(a&&!d)return"Must begin with a-z, A-Z, 0-9, or _ and contain only a-z, A-Z, 0-9, - or _"}}]}))};e()},[b]),m.useEffect(()=>(f&&b.plugins.add(f),()=>{f&&b.plugins.remove(f)}),[f])},Uc={background:"#eb6337",padding:"12px 18px",cursor:"pointer",borderRadius:"50px",textTransform:"uppercase",letterSpacing:"2px",fontWeight:"bold",border:"none",color:"white",margin:"1rem 0"};class Vc extends m.Component{constructor(Wc){super(Wc),this.state={hasError:Wc.hasError,message:"",pageRefresh:!1}}static getDerivedStateFromError(Xc){return{hasError:!0,message:Xc.message}}render(){const Yc=window.localStorage&&window.localStorage.getItem("tinacms-current-branch"),Zc=Yc&&Yc.length>0;return this.state.hasError&&!this.state.pageRefresh?m.createElement("div",{style:{background:"#efefef",height:"100vh",display:"flex",alignItems:"center",justifyContent:"center"}},m.createElement("style",null,"            body {              margin: 0;            }          "),m.createElement("div",{style:{background:"#fff",maxWidth:"400px",padding:"20px",fontFamily:"'Inter', sans-serif",borderRadius:"5px",boxShadow:"0 6px 24px rgb(0 37 91 / 5%), 0 2px 4px rgb(0 37 91 / 3%)"}},m.createElement("h3",{style:{color:"#eb6337"}},"TinaCMS Render Error"),m.createElement("p",null,"Tina caught an error while updating the page:"),m.createElement("pre",{style:{marginTop:"1rem",overflowX:"auto"}},this.state.message),m.createElement("br",null),m.createElement("p",null,"If you've just updated the form, undo your most recent changes and click \"refresh\". If after a few refreshes, you're still encountering this error. There is a bigger issue with the site. Please reach out to your site admin."),m.createElement("p",null,"See our"," ",m.createElement("a",{className:"text-gray-600",style:{textDecoration:"underline"},href:"https://tina.io/docs/errors/faq/",target:"_blank"}," ","Error FAQ"," ")," ","for more information."),m.createElement("button",{style:Uc,onClick:()=>{this.setState({pageRefresh:!0}),setTimeout(()=>this.setState({hasError:!1,pageRefresh:!1}),3e3)}},"Refresh"),Zc&&m.createElement(m.Fragment,null,m.createElement("p",null,"If you're using the branch switcher, you may currently be on a \"stale\" branch that has been deleted or whose content is not compatible with the latest version of the site's layout. Click the button below to switch back to the default branch for this deployment."),m.createElement("p",null,"See our"," ",m.createElement("a",{className:"text-gray-600",style:{textDecoration:"underline"},href:"https://tina.io/docs/errors/faq/",target:"_blank"}," ","Error FAQ"," ")," ","for more information."),m.createElement("button",{style:Uc,onClick:()=>{window.localStorage.removeItem("tinacms-current-branch"),window.location.reload()}},"Switch to default branch")))):this.state.pageRefresh?m.createElement(_c,null,"Let's try that again."):this.props.children}}const $c=({query:a,documentCreatorCallback:b,formifyCallback:c,schema:d,...e})=>{var f,g,h,i,j;(null==e?void 0:e.apiURL)&&console.warn("The apiURL prop is deprecated. Please see https://tina.io/blog/tina-v-0.68.14 for information on how to upgrade to the new API");const k=(null==(f=null==e?void 0:e.client)?void 0:f.apiUrl)||(null==e?void 0:e.apiURL),n=null==(i=null==(h=null==(g=null==d?void 0:d.config)?void 0:g.admin)?void 0:h.auth)?void 0:i.useLocalAuth,{branch:o,clientId:p,isLocalClient:q}=k?(0,l.Lk)(k):{branch:e.branch,clientId:e.clientId,isLocalClient:null==e?void 0:e.isLocalClient};if(void 0===q|| !q&&(!o||!p)&&!d.config.contentApiUrlOverride)throw new Error("Invalid setup. See https://tina.io/docs/tina-cloud/connecting-site/ for more information.");if(!d)throw new Error("`schema` is required to be passed as a property to `TinaProvider`.  You can learn more about this change here: https://github.com/tinacms/tinacms/pull/2823");return m.createElement(m.Fragment,null,m.createElement(Cc,{branch:o,clientId:p||(null==(j=null==d?void 0:d.config)?void 0:j.clientId),tinaioConfig:e.tinaioConfig,isLocalClient:n||q,cmsCallback:e.cmsCallback,mediaStore:e.mediaStore,apiUrl:k,schema:{...d,config:{...d.config,...e}},tinaGraphQLVersion:e.tinaGraphQLVersion},m.createElement("style",null,Ec),m.createElement(Vc,null,e.children)))},_c=a=>m.createElement(m.Fragment,null,m.createElement("div",{style:{position:"fixed",background:"rgba(0, 0, 0, 0.5)",inset:0,zIndex:200,opacity:"0.8",display:"flex",alignItems:"center",justifyContent:"center",padding:"40px"}},m.createElement("div",{style:{background:"#f6f6f9",boxShadow:"0px 2px 3px rgba(0, 0, 0, 0.05), 0 4px 12px rgba(0, 0, 0, 0.1)",borderRadius:"5px",padding:"40px 32px",width:"460px",maxWidth:"90%",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column"}},m.createElement("svg",{style:{width:"64px",color:"#2296fe",marginTop:"-8px",marginBottom:"16px"},version:"1.1",id:"L5",xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",x:"0px",y:"0px",viewBox:"0 0 100 64",enableBackground:"new 0 0 0 0",xmlSpace:"preserve"},m.createElement("circle",{fill:"currentColor",stroke:"none",cx:6,cy:32,r:6},m.createElement("animateTransform",{attributeName:"transform",dur:"1s",type:"translate",values:"0 15 ; 0 -15; 0 15",calcMode:"spline",keySplines:"0.8 0 0.4 1; 0.4 0 0.2 1",repeatCount:"indefinite",begin:"0.1"})),m.createElement("circle",{fill:"currentColor",stroke:"none",cx:30,cy:32,r:6},m.createElement("animateTransform",{attributeName:"transform",dur:"1s",type:"translate",values:"0 15 ; 0 -10; 0 15",calcMode:"spline",keySplines:"0.8 0 0.4 1; 0.4 0 0.2 1",repeatCount:"indefinite",begin:"0.2"})),m.createElement("circle",{fill:"currentColor",stroke:"none",cx:54,cy:32,r:6},m.createElement("animateTransform",{attributeName:"transform",dur:"1s",type:"translate",values:"0 15 ; 0 -5; 0 15",calcMode:"spline",keySplines:"0.8 0 0.4 1; 0.4 0 0.2 1",repeatCount:"indefinite",begin:"0.3"}))),m.createElement("p",{style:{fontSize:"18px",color:"#252336",textAlign:"center",lineHeight:"1.3",fontFamily:"'Inter', sans-serif",fontWeight:"normal"}},"Please wait, Tina is loading data..."))),a.children),ad=async({query:a,variables:b})=>{try{const c=await bd({query:a,variables:b});return JSON.parse(JSON.stringify({data:c,query:a,variables:b}))}catch(d){return JSON.parse(JSON.stringify({data:{},query:a,variables:b}))}},bd=async({query:a,variables:b})=>{const c=new Kb();return"undefined"!=typeof window&&window.document&&console.warn(`Whoops! Looks like you are using \`staticRequest\` in the browser to fetch data.

The local server is not available outside of \`getStaticProps\` or \`getStaticPaths\` functions.
This function should only be called on the server at build time.

This will work when developing locally but NOT when deployed to production.
`),c.request(a,{variables:b})};function cd(a,...b){let c="";return a.forEach((a,d)=>{c+=a+(b[d]||"")}),c}const dd=({children:a})=>m.createElement(m.Fragment,null,m.createElement("style",null,Ec),m.createElement("div",{className:"tina-tailwind",style:{position:"fixed",top:0,left:0,width:"100%",height:"100%",overflow:"auto",background:"#F6F6F9",fontFamily:"'Inter', sans-serif",zIndex:9999}},a));var ed={color:void 0,size:void 0,className:void 0,style:void 0,attr:void 0},fd=m.createContext&&m.createContext(ed),gd=globalThis&&globalThis.__assign||function(){return(gd=Object.assign||function(a){for(var b,c=1,d=arguments.length;c<d;c++)for(var e in b=arguments[c])Object.prototype.hasOwnProperty.call(b,e)&&(a[e]=b[e]);return a}).apply(this,arguments)},hd=globalThis&&globalThis.__rest||function(a,b){var c={};for(var d in a)Object.prototype.hasOwnProperty.call(a,d)&&0>b.indexOf(d)&&(c[d]=a[d]);if(null!=a&&"function"==typeof Object.getOwnPropertySymbols)for(var e=0,d=Object.getOwnPropertySymbols(a);e<d.length;e++)0>b.indexOf(d[e])&&Object.prototype.propertyIsEnumerable.call(a,d[e])&&(c[d[e]]=a[d[e]]);return c};function id(a){return a&&a.map(function(a,b){return m.createElement(a.tag,gd({key:b},a.attr),id(a.child))})}function jd(a){return function(b){return m.createElement(kd,gd({attr:gd({},a.attr)},b),id(a.child))}}function kd(a){var b=function(b){var c,d=a.attr,e=a.size,f=a.title,g=hd(a,["attr","size","title"]),h=e||b.size||"1em";return b.className&&(c=b.className),a.className&&(c=(c?c+" ":"")+a.className),m.createElement("svg",gd({stroke:"currentColor",fill:"currentColor",strokeWidth:"0"},b.attr,d,g,{className:c,style:gd(gd({color:a.color||b.color},b.style),a.style),height:h,width:h,xmlns:"http://www.w3.org/2000/svg"}),f&&m.createElement("title",null,f),a.children)};return void 0!==fd?m.createElement(fd.Consumer,null,function(a){return b(a)}):b(ed)}function ld(a){return jd({tag:"svg",attr:{version:"1.1",viewBox:"0 0 16 16"},child:[{tag:"path",attr:{d:"M14.341 5.579c-0.347-0.473-0.831-1.027-1.362-1.558s-1.085-1.015-1.558-1.362c-0.806-0.591-1.197-0.659-1.421-0.659h-5.75c-0.689 0-1.25 0.561-1.25 1.25v11.5c0 0.689 0.561 1.25 1.25 1.25h9.5c0.689 0 1.25-0.561 1.25-1.25v-7.75c0-0.224-0.068-0.615-0.659-1.421zM12.271 4.729c0.48 0.48 0.856 0.912 1.134 1.271h-2.406v-2.405c0.359 0.278 0.792 0.654 1.271 1.134v0zM14 14.75c0 0.136-0.114 0.25-0.25 0.25h-9.5c-0.136 0-0.25-0.114-0.25-0.25v-11.5c0-0.135 0.114-0.25 0.25-0.25 0 0 5.749-0 5.75 0v3.5c0 0.276 0.224 0.5 0.5 0.5h3.5v7.75z"}},{tag:"path",attr:{d:"M9.421 0.659c-0.806-0.591-1.197-0.659-1.421-0.659h-5.75c-0.689 0-1.25 0.561-1.25 1.25v11.5c0 0.604 0.43 1.109 1 1.225v-12.725c0-0.135 0.115-0.25 0.25-0.25h7.607c-0.151-0.124-0.297-0.238-0.437-0.341z"}}]})(a)}const md=a=>{const b=new Ub(a);return{collections:b.fetchCollections()}};function nd(a){return jd({tag:"svg",attr:{viewBox:"0 0 512 512"},child:[{tag:"path",attr:{d:"M405 136.798L375.202 107 256 226.202 136.798 107 107 136.798 226.202 256 107 375.202 136.798 405 256 285.798 375.202 405 405 375.202 285.798 256z"}}]})(a)}function od(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M21 11H6.414l5.293-5.293-1.414-1.414L2.586 12l7.707 7.707 1.414-1.414L6.414 13H21z"}}]})(a)}function pd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M20 2H10c-1.103 0-2 .897-2 2v4H4c-1.103 0-2 .897-2 2v10c0 1.103.897 2 2 2h10c1.103 0 2-.897 2-2v-4h4c1.103 0 2-.897 2-2V4c0-1.103-.897-2-2-2zM4 20V10h10l.002 10H4zm16-6h-4v-4c0-1.103-.897-2-2-2h-4V4h10v10z"}}]})(a)}function qd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"m7 17.013 4.413-.015 9.632-9.54c.378-.378.586-.88.586-1.414s-.208-1.036-.586-1.414l-1.586-1.586c-.756-.756-2.075-.752-2.825-.003L7 12.583v4.43zM18.045 4.458l1.589 1.583-1.597 1.582-1.586-1.585 1.594-1.58zM9 13.417l6.03-5.973 1.586 1.586-6.029 5.971L9 15.006v-1.589z"}},{tag:"path",attr:{d:"M5 21h14c1.103 0 2-.897 2-2v-8.668l-2 2V19H8.158c-.026 0-.053.01-.079.01-.033 0-.066-.009-.1-.01H5V5h6.847l2-2H5c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2z"}}]})(a)}function rd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M11.001 10h2v5h-2zM11 16h2v2h-2z"}},{tag:"path",attr:{d:"M13.768 4.2C13.42 3.545 12.742 3.138 12 3.138s-1.42.407-1.768 1.063L2.894 18.064a1.986 1.986 0 0 0 .054 1.968A1.984 1.984 0 0 0 4.661 21h14.678c.708 0 1.349-.362 1.714-.968a1.989 1.989 0 0 0 .054-1.968L13.768 4.2zM4.661 19 12 5.137 19.344 19H4.661z"}}]})(a)}function sd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M19.903 8.586a.997.997 0 0 0-.196-.293l-6-6a.997.997 0 0 0-.293-.196c-.03-.014-.062-.022-.094-.033a.991.991 0 0 0-.259-.051C13.04 2.011 13.021 2 13 2H6c-1.103 0-2 .897-2 2v16c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2V9c0-.021-.011-.04-.013-.062a.952.952 0 0 0-.051-.259c-.01-.032-.019-.063-.033-.093zM16.586 8H14V5.414L16.586 8zM6 20V4h6v5a1 1 0 0 0 1 1h5l.002 10H6z"}},{tag:"path",attr:{d:"M8 12h8v2H8zm0 4h8v2H8zm0-8h2v2H8z"}}]})(a)}function td(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M20 5h-8.586L9.707 3.293A.997.997 0 0 0 9 3H4c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V7c0-1.103-.897-2-2-2zM4 19V7h16l.002 12H4z"}}]})(a)}function ud(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"m13 16 5-4-5-4v3H4v2h9z"}},{tag:"path",attr:{d:"M20 3h-9c-1.103 0-2 .897-2 2v4h2V5h9v14h-9v-4H9v4c0 1.103.897 2 2 2h9c1.103 0 2-.897 2-2V5c0-1.103-.897-2-2-2z"}}]})(a)}function vd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M16 13v-2H7V8l-5 4 5 4v-3z"}},{tag:"path",attr:{d:"M20 3h-9c-1.103 0-2 .897-2 2v4h2V5h9v14h-9v-4H9v4c0 1.103.897 2 2 2h9c1.103 0 2-.897 2-2V5c0-1.103-.897-2-2-2z"}}]})(a)}function wd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"}}]})(a)}function xd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M19 11h-6V5h-2v6H5v2h6v6h2v-6h6z"}}]})(a)}function yd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M20.005 5.995h-1v2h1v8h-1v2h1c1.103 0 2-.897 2-2v-8c0-1.102-.898-2-2-2zm-14 4H15v4H6.005z"}},{tag:"path",attr:{d:"M17.005 17.995V4H20V2h-8v2h3.005v1.995h-11c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h11V20H12v2h8v-2h-2.995v-2.005zm-13-2v-8h11v8h-11z"}}]})(a)}function zd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M10 18a7.952 7.952 0 0 0 4.897-1.688l4.396 4.396 1.414-1.414-4.396-4.396A7.952 7.952 0 0 0 18 10c0-4.411-3.589-8-8-8s-8 3.589-8 8 3.589 8 8 8zm0-14c3.309 0 6 2.691 6 6s-2.691 6-6 6-6-2.691-6-6 2.691-6 6-6z"}}]})(a)}function Ad(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"m13 7.101.01.001a4.978 4.978 0 0 1 2.526 1.362 5.005 5.005 0 0 1 1.363 2.528 5.061 5.061 0 0 1-.001 2.016 4.976 4.976 0 0 1-1.363 2.527l1.414 1.414a7.014 7.014 0 0 0 1.908-3.54 6.98 6.98 0 0 0 0-2.819 6.957 6.957 0 0 0-1.907-3.539 6.97 6.97 0 0 0-2.223-1.5 6.921 6.921 0 0 0-1.315-.408c-.137-.028-.275-.043-.412-.063V2L9 6l4 4V7.101zm-7.45 7.623c.174.412.392.812.646 1.19.249.37.537.718.854 1.034a7.036 7.036 0 0 0 2.224 1.501c.425.18.868.317 1.315.408.167.034.338.056.508.078v2.944l4-4-4-4v3.03c-.035-.006-.072-.003-.107-.011a4.978 4.978 0 0 1-2.526-1.362 4.994 4.994 0 0 1 .001-7.071L7.051 7.05a7.01 7.01 0 0 0-1.5 2.224A6.974 6.974 0 0 0 5 12a6.997 6.997 0 0 0 .55 2.724z"}}]})(a)}function Bd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M5 20a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8h2V6h-4V4a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v2H3v2h2zM9 4h6v2H9zM8 8h9v12H7V8z"}},{tag:"path",attr:{d:"M9 10h2v8H9zm4 0h2v8h-2z"}}]})(a)}function Cd(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"m16.192 6.344-4.243 4.242-4.242-4.242-1.414 1.414L10.535 12l-4.242 4.242 1.414 1.414 4.242-4.242 4.243 4.242 1.414-1.414L13.364 12l4.242-4.242z"}}]})(a)}const Dd=a=>a.toString().toLowerCase().trim().replace(/[^\w\s-]/g,"").replace(/[\s_-]+/g,"_").replace(/^-+|-+$/g,""),Ed=({cms:a})=>{var b,c;const d=md(a),f=a.plugins.getType("screen").all(),g=a.plugins.getType("cloud-config").all(),[h,i]=m.useState(!1),j=null==(c=null==(b=a.api)?void 0:b.tina)?void 0:c.isLocalMode,k=(0,u.useWindowWidth)(),l=k>1e3;return m.createElement(m.Fragment,null,l&&m.createElement(e.JL8,{isLocalMode:j,sidebarWidth:360,showCollections:!0,collectionsInfo:d,screens:f,cloudConfigs:g,contentCreators:[],RenderNavSite:({view:a})=>m.createElement(Fd,{label:a.name,to:`/screens/${Dd(a.name)}`,Icon:a.Icon?a.Icon:ld}),RenderNavCloud:({config:a})=>m.createElement(Gd,{config:a}),RenderNavCollection:({collection:a})=>m.createElement(Fd,{label:a.label?a.label:a.name,to:`/collections/${a.name}/~`,Icon:ld})}),!l&&m.createElement(s.u,{show:h},m.createElement(s.u.Child,{as:m.Fragment,enter:"transform transition-all ease-out duration-300",enterFrom:"opacity-0 -translate-x-full",enterTo:"opacity-100 translate-x-0",leave:"transform transition-all ease-in duration-200",leaveFrom:"opacity-100 translate-x-0",leaveTo:"opacity-0 -translate-x-full"},m.createElement("div",{className:"fixed left-0 top-0 z-overlay h-full transform"},m.createElement(e.JL8,{isLocalMode:j,className:"rounded-r-md",sidebarWidth:360,showCollections:!0,collectionsInfo:d,screens:f,cloudConfigs:g,contentCreators:[],RenderNavSite:({view:a})=>m.createElement(Fd,{label:a.name,to:`/screens/${Dd(a.name)}`,Icon:a.Icon?a.Icon:ld,onClick:()=>{i(!1)}}),RenderNavCloud:({config:a})=>m.createElement(Gd,{config:a}),RenderNavCollection:({collection:a})=>m.createElement(Fd,{label:a.label?a.label:a.name,to:`/collections/${a.name}/~`,Icon:ld,onClick:()=>{i(!1)}})},m.createElement("div",{className:"absolute top-8 right-0 transform translate-x-full overflow-hidden"},m.createElement(e.zxk,{rounded:"right",variant:"secondary",onClick:()=>{i(!1)},className:"transition-opacity duration-150 ease-out"},m.createElement(nd,{className:"h-6 w-auto"})))))),m.createElement(s.u.Child,{as:m.Fragment,enter:"ease-out duration-300",enterFrom:"opacity-0",enterTo:"opacity-80",entered:"opacity-80",leave:"ease-in duration-200",leaveFrom:"opacity-80",leaveTo:"opacity-0"},m.createElement("div",{onClick:()=>{i(!1)},className:"fixed z-menu inset-0 bg-gradient-to-br from-gray-800 via-gray-900 to-black"}))),!l&&m.createElement(e.zxk,{rounded:"right",variant:"secondary",onClick:()=>{i(!0)},className:`pointer-events-auto -ml-px absolute left-0 z-50 ${j?"top-10":"top-4"}`},m.createElement(wd,{className:"h-7 w-auto"})))},Fd=a=>{const{to:b,label:c,Icon:d}=a;return m.createElement(q.NavLink,{className:({isActive:a})=>`text-base tracking-wide ${a?"text-blue-600":"text-gray-500"} hover:text-blue-600 flex items-center opacity-90 hover:opacity-100`,onClick:a.onClick?a.onClick:()=>{},to:b},m.createElement(d,{className:"mr-2 h-6 opacity-80 w-auto"})," ",c)},Gd=({config:a})=>a.text?m.createElement("span",{className:"text-base tracking-wide text-gray-500 flex items-center opacity-90"},a.text," ",m.createElement("a",{target:"_blank",className:"ml-1 text-blue-600 hover:opacity-60",href:a.link.href},a.link.text)):m.createElement("span",{className:"text-base tracking-wide text-gray-500 hover:text-blue-600 flex items-center opacity-90 hover:opacity-100"},m.createElement(a.Icon,{className:"mr-2 h-6 opacity-80 w-auto"}),m.createElement("a",{target:"_blank",href:a.link.href},a.link.text)),Hd=({children:a})=>{try{const b=(0,e.kNL)();return m.createElement(m.Fragment,null,a(b))}catch(c){return null}};function Id(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"path",attr:{fill:"none",d:"M0 0h24v24H0V0z"}},{tag:"path",attr:{d:"M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"}}]})(a)}const Jd=({message:a,children:b})=>m.createElement("div",{className:"h-screen w-full bg-gradient-to-b from-blue-900 to-gray-900 flex items-center justify-center px-4 py-6"},m.createElement("div",{className:"bg-white rounded-lg overflow-hidden shadow-lg w-full max-w-lg"},m.createElement("div",{className:"px-5 py-4 border-b border-gray-150"},m.createElement("h2",{className:"text-2xl font-sans tracking-wide text-gray-700 flex items-center gap-0.5"},m.createElement("svg",{viewBox:"0 0 32 32",fill:"#EC4815",xmlns:"http://www.w3.org/2000/svg",className:"w-10 h-auto"},m.createElement("path",{d:"M18.6466 14.5553C19.9018 13.5141 20.458 7.36086 21.0014 5.14903C21.5447 2.9372 23.7919 3.04938 23.7919 3.04938C23.7919 3.04938 23.2085 4.06764 23.4464 4.82751C23.6844 5.58738 25.3145 6.26662 25.3145 6.26662L24.9629 7.19622C24.9629 7.19622 24.2288 7.10204 23.7919 7.9785C23.355 8.85496 24.3392 17.4442 24.3392 17.4442C24.3392 17.4442 21.4469 22.7275 21.4469 24.9206C21.4469 27.1136 22.4819 28.9515 22.4819 28.9515H21.0296C21.0296 28.9515 18.899 26.4086 18.462 25.1378C18.0251 23.8669 18.1998 22.596 18.1998 22.596C18.1998 22.596 15.8839 22.4646 13.8303 22.596C11.7767 22.7275 10.4072 24.498 10.16 25.4884C9.91287 26.4787 9.81048 28.9515 9.81048 28.9515H8.66211C7.96315 26.7882 7.40803 26.0129 7.70918 24.9206C8.54334 21.8949 8.37949 20.1788 8.18635 19.4145C7.99321 18.6501 6.68552 17.983 6.68552 17.983C7.32609 16.6741 7.97996 16.0452 10.7926 15.9796C13.6052 15.914 17.3915 15.5965 18.6466 14.5553Z"}),m.createElement("path",{d:"M11.1268 24.7939C11.1268 24.7939 11.4236 27.5481 13.0001 28.9516H14.3511C13.0001 27.4166 12.8527 23.4155 12.8527 23.4155C12.1656 23.6399 11.3045 24.3846 11.1268 24.7939Z"})),m.createElement("span",null,"Tina"))),a&&m.createElement("div",{className:"px-5 pt-4"},m.createElement("p",{className:"text-base font-sans leading-normal"},a)),m.createElement("div",{className:"px-5 py-4 flex gap-4 w-full justify-between"},b))),Kd=()=>{const{setEdit:a}=(0,o.i)(),b=()=>a(!0);return m.createElement(Jd,null,m.createElement("div",{className:"flex w-full flex-1 gap-4 items-center justify-end"},m.createElement(e.zxk,{onClick:()=>{window.location.href="/"},variant:"white",size:"custom",className:"text-base h-12 px-6 flex-shrink-0 flex-grow-0"},m.createElement(Id,{className:"w-6 h-auto mr-1.5 opacity-80"})," Back To Site"),m.createElement(e.zxk,{onClick:()=>b(),variant:"primary",size:"custom",className:"text-base h-12 px-6 flex-1",type:"submit"},m.createElement(ud,{className:"w-6 h-auto mr-2 opacity-80"})," Edit With Tina")))},Ld=()=>{const a=(0,e.kNL)(),{setEdit:b}=(0,o.i)(),[c]=(0,q.useSearchParams)(),d=c.get("slug")||"/",f=async()=>{var c,d,e,f,g,h;(null==(d=null==(c=null==a?void 0:a.api)?void 0:c.tina)?void 0:d.logout)&&(await a.api.tina.logout(),(null==(f=null==(e=null==a?void 0:a.api)?void 0:e.tina)?void 0:f.onLogout)&&await (null==(h=null==(g=null==a?void 0:a.api)?void 0:g.tina)?void 0:h.onLogout())),b(!1)};return(0,m.useEffect)(()=>{f().then(()=>{window.location.href=d})},[]),m.createElement("div",null,"Redirecting to ",d," ...")},Md=()=>{(0,o.D_)(!1),window.location.href="/"},Nd=()=>m.createElement(Jd,null,m.createElement("div",{className:"flex w-full flex-1 gap-4 items-center justify-end"},m.createElement(e.zxk,{onClick:()=>{window.location.href="/"},variant:"white",size:"custom",className:"text-base h-12 px-6 flex-shrink-0 flex-grow-0"},m.createElement(Id,{className:"w-6 h-auto mr-1.5 opacity-80"})," Back To Site"),m.createElement(e.zxk,{onClick:()=>Md(),type:"submit",variant:"primary",size:"custom",className:"text-base h-12 px-6 flex-1"},m.createElement(vd,{className:"w-6 h-auto mr-1.5 opacity-80"})," Log Out of Tina"))),Od=({children:a})=>{var b,c;const d=(0,e.kNL)(),f=null==(c=null==(b=d.api)?void 0:b.tina)?void 0:c.isLocalMode,[g,h]=m.useState(()=>d.flags.get("branch-switcher"));return m.useEffect(()=>{d.events.subscribe("flag:set",({key:a,value:b})=>{"branch-switcher"===a&&h(b)})},[d.events]),m.createElement("div",{className:"relative left-0 w-full h-full bg-gradient-to-b from-gray-50/50 to-gray-50 shadow-2xl overflow-y-auto transition-opacity duration-300 ease-out flex flex-col opacity-100"},g&&!f&&m.createElement(e.HVU,null),a)},Pd=({isLocalMode:a,children:b})=>m.createElement(m.Fragment,null,a&&m.createElement(e.DrE,null),!a&&m.createElement(e.VaG,null),m.createElement("div",{className:"pt-12 px-12"},m.createElement("div",{className:"w-full mx-auto max-w-screen-xl"},m.createElement("div",{className:"w-full flex justify-between items-end"},b)))),Qd=({children:a})=>m.createElement("div",{className:"py-8 px-12"},a),Rd=({children:a})=>m.createElement("div",{className:"py-10 px-12"},m.createElement("div",{className:"w-full mx-auto max-w-screen-xl"},a)),Sd=()=>m.createElement(Hd,null,a=>{var b,c;return m.createElement(Od,null,m.createElement(m.Fragment,null,m.createElement(Pd,{isLocalMode:null==(c=null==(b=a.api)?void 0:b.tina)?void 0:c.isLocalMode},m.createElement("h3",{className:"text-2xl font-sans text-gray-700"},"Welcome to Tina!")),m.createElement(Rd,null,"This is your dashboard for editing or creating content. Select a collection on the left to begin.")))});function Td(a){return jd({tag:"svg",attr:{viewBox:"0 0 24 24"},child:[{tag:"g",attr:{},child:[{tag:"path",attr:{fill:"none",d:"M0 0h24v24H0z"}},{tag:"path",attr:{d:"M19 21H5a1 1 0 0 1-1-1v-9H1l10.327-9.388a1 1 0 0 1 1.346 0L23 11h-3v9a1 1 0 0 1-1 1zM6 19h12V9.157l-6-5.454-6 5.454V19z"}}]}]})(a)}const Ud=()=>m.createElement(m.Fragment,null,m.createElement("div",{style:{position:"absolute",top:0,left:0,width:"100%",height:"100%",zIndex:200,opacity:"0.8",display:"flex",alignItems:"start",justifyContent:"center",padding:"120px 40px 40px 40px"}},m.createElement("div",{style:{background:"#FFF",border:"1px solid #EDECF3",boxShadow:"0px 2px 3px rgba(0, 0, 0, 0.05), 0 4px 12px rgba(0, 0, 0, 0.1)",borderRadius:"8px",padding:"32px 24px",width:"460px",maxWidth:"90%",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column"}},m.createElement("svg",{style:{width:"64px",color:"#2296fe",marginTop:"-8px",marginBottom:"16px"},version:"1.1",id:"L5",xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",x:"0px",y:"0px",viewBox:"0 0 100 64",enableBackground:"new 0 0 0 0",xmlSpace:"preserve"},m.createElement("circle",{fill:"currentColor",stroke:"none",cx:6,cy:32,r:6},m.createElement("animateTransform",{attributeName:"transform",dur:"1s",type:"translate",values:"0 15 ; 0 -15; 0 15",calcMode:"spline",keySplines:"0.8 0 0.4 1; 0.4 0 0.2 1",repeatCount:"indefinite",begin:"0.1"})),m.createElement("circle",{fill:"currentColor",stroke:"none",cx:30,cy:32,r:6},m.createElement("animateTransform",{attributeName:"transform",dur:"1s",type:"translate",values:"0 15 ; 0 -10; 0 15",calcMode:"spline",keySplines:"0.8 0 0.4 1; 0.4 0 0.2 1",repeatCount:"indefinite",begin:"0.2"})),m.createElement("circle",{fill:"currentColor",stroke:"none",cx:54,cy:32,r:6},m.createElement("animateTransform",{attributeName:"transform",dur:"1s",type:"translate",values:"0 15 ; 0 -5; 0 15",calcMode:"spline",keySplines:"0.8 0 0.4 1; 0.4 0 0.2 1",repeatCount:"indefinite",begin:"0.3"}))),m.createElement("p",{style:{fontSize:"16px",color:"#716c7f",textAlign:"center",lineHeight:"1.3",fontFamily:"'Inter', sans-serif",fontWeight:"normal"}},"Please wait, Tina is loading data...")))),Vd=({title:a="Error",errorMessage:b="It looks like something went wrong."})=>m.createElement("div",{className:"flex flex-col justify-center items-center h-screen bg-gray-100"},m.createElement("div",{className:"text-red-500 text-4xl mb-6 flex items-center"},m.createElement(rd,{className:"w-12 h-auto fill-current text-red-400 opacity-70 mr-1"})," ",a),m.createElement("p",{className:"text-gray-700 text-xl mb-8"},b),m.createElement(e.zxk,{variant:"danger",onClick:()=>window.location.reload()},m.createElement(Ad,{className:"w-7 h-auto fill-current opacity-70 mr-1"})," Reload")),Wd=(a,b,c=!0,d,e="",f,g)=>{const h=new Ub(a),i=a.api.tina.schema,j=i.getCollection(b),[k,l]=(0,m.useState)(void 0),[n,o]=(0,m.useState)(!0),[p,q]=(0,m.useState)(void 0),[r,s]=(0,m.useState)(0);return(0,m.useEffect)(()=>{let i=!1;const k=async()=>{var k;if(await h.isAuthenticated()&&!d.loading&&!i){const{name:m,order:n}=JSON.parse(f||"{}"),p=(null==(k=j.fields)?void 0:k.map(a=>a.name).includes(m))?m:void 0;try{const r=await h.fetchCollection(b,c,(null==g?void 0:g.filterField)?"":d.fullyQualifiedName,e,p,n,g);l(r)}catch(s){a.alerts.error(`[${s.name}] GetCollection failed: ${s.message}`),console.error(s),l(void 0),q(s)}o(!1)}};if(!i)return o(!0),k(),()=>{i=!0}},[a,b,d.loading,d.fullyQualifiedName,r,e,f]),{collection:k,loading:n,error:p,reFetchCollection:()=>s(a=>a+1),collectionExtra:j}},Xd=({cms:a,collectionName:b,folder:c,includeDocuments:d=!0,startCursor:e,sortKey:f,children:g,filterArgs:h})=>{const i=(0,r.s0)(),{collection:j,loading:k,error:l,reFetchCollection:n,collectionExtra:o}=Wd(a,b,d,c,e||"",f,h)||{};return((0,m.useEffect)(()=>{var b,c,d,e,f,g,h,l,m,n,o;if(k)return;const p=a.api.tina.schema.getCollection(j.name),q=null==(d=null==(c=null==(b=null==p?void 0:p.ui)?void 0:b.allowedActions)?void 0:c.create)||d,r=null==(g=null==(f=null==(e=null==p?void 0:p.ui)?void 0:e.allowedActions)?void 0:f.delete)||g;if(!q&&!r&&(null==(l=null==(h=j.documents)?void 0:h.edges)?void 0:l.length)===1&&(null==(o=null==(n=null==(m=j.documents)?void 0:m.edges[0])?void 0:n.node)?void 0:o.__typename)!=="Folder"){const s=j.documents.edges[0].node;ce(i,a,j,p,s)}},[(null==j?void 0:j.name)||"",k]),l)?m.createElement(Vd,null):k?m.createElement(Ud,null):m.createElement(m.Fragment,null,g(j,k,n,o))},Yd=/^.*\/~\/*(.*)$/,Zd=a=>({...a,name:a.name.split("/").slice(0,-1).join("/"),fullyQualifiedName:a.fullyQualifiedName.split("/").slice(0,-1).join("/"),parentName:a.parentName.split("/").slice(0,-1).join("/")}),$d=()=>{const[a,b]=(0,m.useState)({loading:!0,name:"",fullyQualifiedName:"",parentName:""}),c=(0,r.TH)();return(0,m.useEffect)(()=>{const d=c.pathname.match(Yd),e=d?decodeURIComponent(d[1]):"",f={name:e,fullyQualifiedName:d?e?`~/${e}`:"~":"",loading:!1,parentName:""};if(f.fullyQualifiedName){const g=f.fullyQualifiedName.split("/");f.parentName=`/${g.slice(0,g.length-1).join("/")}`}b({...a,...f})},[c]),a},_d="tinacms.admin.collection.list.page",ae="undefined"==typeof window,be=({templates:a,folder:b,collectionName:c})=>m.createElement(t.v,{as:"div",className:"relative inline-block text-left"},()=>m.createElement("div",null,m.createElement("div",null,m.createElement(t.v.Button,{className:"icon-parent inline-flex items-center font-medium focus:outline-none focus:ring-2 focus:shadow-outline text-center rounded-full justify-center transition-all duration-150 ease-out  shadow text-white bg-blue-500 hover:bg-blue-600 focus:ring-blue-500 text-sm h-10 px-6"},"Create New ",m.createElement(xd,{className:"w-5 h-full ml-1 opacity-70"}))),m.createElement(s.u,{as:m.Fragment,enter:"transition ease-out duration-100",enterFrom:"transform opacity-0 scale-95",enterTo:"transform opacity-100 scale-100",leave:"transition ease-in duration-75",leaveFrom:"transform opacity-100 scale-100",leaveTo:"transform opacity-0 scale-95"},m.createElement(t.v.Items,{className:"origin-top-right absolute right-0 mt-2 z-menu w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none"},m.createElement("div",{className:"py-1"},a.map(a=>m.createElement(t.v.Item,{key:`${a.label}-${a.name}`},({active:d})=>m.createElement(q.Link,{to:`/${b.fullyQualifiedName?["collections","new",c,a.name,"~",b.name].join("/"):["collections","new",c,a.name].join("/")}`,className:`w-full text-md px-4 py-2 tracking-wide flex items-center transition ease-out duration-100 ${d?"text-blue-600 opacity-100 bg-gray-50":"opacity-80 text-gray-600"}`},a.label)))))))),ce=(a,b,c,d,e)=>{var f,g;const h=b.plugins.all("tina-admin"),i=h.find(({name:a})=>"route-mapping"===a),j=b.flags.get("tina-preview")||!1;let k=(null==(f=d.ui)?void 0:f.router)?null==(g=d.ui)?void 0:g.router({document:e,collection:d}):i?i.mapper(c,e):void 0;if(k)return k.startsWith("/")&&(k=k.slice(1)),j?a(`/~/${k}`):window.location.href=k,null;{const l=e._sys.breadcrumbs;a(`/${["collections","edit",c.name,...l].join("/")}`,{replace:!0})}},de=()=>{const a=(0,r.s0)(),{collectionName:b}=(0,r.UO)(),[c,d]=m.useState(!1),[f,g]=m.useState(!1),[h,i]=m.useState({collection:b,relativePath:"",newRelativePath:"",filterField:"",startsWith:"",endsWith:"",before:"",after:"",booleanEquals:null}),[j,k]=m.useState(!1),[l,n]=(0,m.useState)(""),[o,p]=(0,m.useState)([]),[s,t]=(0,m.useState)(ae?"":window.localStorage.getItem(`${_d}.${b}`)||JSON.stringify({order:"asc",name:""})),{order:u="asc",name:v}=JSON.parse(s||"{}"),[w,x]=(0,m.useState)(u),y=(0,r.TH)(),z=$d();return(0,m.useEffect)(()=>{t(window.localStorage.getItem(`${_d}.${b}`)||JSON.stringify({order:"asc",name:""})),n(""),p([])},[y]),(0,m.useEffect)(()=>{i(a=>({...a,collection:b,relativePath:"",newRelativePath:"",filterField:"",startsWith:"",endsWith:"",before:"",after:"",booleanEquals:null}))},[b]),m.createElement(Hd,null,r=>m.createElement(Od,null,m.createElement(Xd,{cms:r,collectionName:b,includeDocuments:!0,startCursor:l,sortKey:s,folder:z,filterArgs:b===h.collection?h:{collection:b,relativePath:"",newRelativePath:"",filterField:"",startsWith:"",endsWith:"",before:"",after:"",booleanEquals:null}},(u,y,A,B)=>{var C,D,E,F,G,H,I,J,K,L,M;u.documents.totalCount;const N=u.documents.edges,O=r.api.admin,P=u.documents.pageInfo,Q=null==(C=B.fields)?void 0:C.filter(a=>["string","number","datetime","boolean"].includes(a.type)),R=null==Q?void 0:Q.find(a=>a.name===v),S=null==(D=B.fields)?void 0:D.filter(a=>["string","datetime","boolean"].includes(a.type)&&!a.list),T=null==S?void 0:S.find(a=>a.name===h.filterField),U=(null==T?void 0:T.type)==="string"&&!T.list,V=(null==T?void 0:T.type)==="datetime",W=(null==T?void 0:T.type)==="boolean"&&!T.list,X=r.api.tina.schema.getCollection(u.name),Y=null==(G=null==(F=null==(E=null==X?void 0:X.ui)?void 0:E.allowedActions)?void 0:F.create)||G,Z=null==(J=null==(I=null==(H=null==X?void 0:X.ui)?void 0:H.allowedActions)?void 0:I.delete)||J,$=""!==z.fullyQualifiedName;return m.createElement(m.Fragment,null,c&&m.createElement(ge,{filename:h.relativePath,deleteFunc:async()=>{try{await O.deleteDocument(h),r.alerts.info("Document was successfully deleted"),A()}catch(a){throw r.alerts.warn("Document was not deleted, ask a developer for help or check the console for an error message"),console.error(a),a}},close:()=>d(!1)}),f&&m.createElement(he,{filename:h.relativePath,newRelativePath:h.newRelativePath,setNewRelativePath:a=>{i(b=>({...b,newRelativePath:a}))},renameFunc:async()=>{const a=`${h.newRelativePath}.${u.format}`;try{await O.renameDocument({collection:h.collection,relativePath:h.relativePath,newRelativePath:a}),r.alerts.info("Document was successfully renamed"),A()}catch(b){throw r.alerts.warn("Document was not renamed, ask a developer for help or check the console for an error message"),console.error(b),b}},close:()=>g(!1)}),m.createElement(Pd,{isLocalMode:null==(L=null==(K=null==r?void 0:r.api)?void 0:K.tina)?void 0:L.isLocalMode},m.createElement("div",{className:"w-full grid grid-flow-col items-end gap-4"},m.createElement("div",{className:"flex flex-col gap-4"},m.createElement("h3",{className:"font-sans text-2xl text-gray-700"},u.label?u.label:u.name),m.createElement("div",{className:"flex gap-4 items-end flex-wrap"},(null==Q?void 0:Q.length)>0&&m.createElement(m.Fragment,null,m.createElement("div",{className:"flex flex-col gap-2 items-start"},m.createElement("label",{htmlFor:"sort",className:"block font-sans text-xs font-semibold text-gray-500 whitespace-normal"},"Sort by"),m.createElement(e.PhF,{name:"sort",options:[{label:"Default",value:JSON.stringify({order:"asc",name:""})},...Q.map(a=>[{label:(a.label||a.name)+("datetime"===a.type?" (Oldest First)":" (Ascending)"),value:JSON.stringify({name:a.name,order:"asc"})},{label:(a.label||a.name)+("datetime"===a.type?" (Newest First)":" (Descending)"),value:JSON.stringify({name:a.name,order:"desc"})}]).flat()],input:{id:"sort",name:"sort",value:s,onChange:a=>{const c=JSON.parse(a.target.value);n(""),p([]),null==window||window.localStorage.setItem(`${_d}.${b}`,a.target.value),t(a.target.value),x(c.order)}}})),m.createElement("form",{className:"flex flex-wrap gap-4 items-end"},m.createElement("div",{className:"flex flex-shrink-0 flex-col gap-2 items-start"},m.createElement("label",{htmlFor:"filter",className:"block font-sans text-xs font-semibold text-gray-500 whitespace-normal"},"Filter by"),m.createElement(e.PhF,{name:"filter",options:[{label:"None",value:""},...S.map(a=>({label:"string"==typeof a.label&&a.label||a.name,value:a.name}))],input:{id:"filter",name:"filter",value:h.filterField,onChange:a=>{const b=a.target.value;n(""),p([]),i(a=>({...a,filterField:b})),b||A()}}})),U&&m.createElement(m.Fragment,null,m.createElement("div",{className:"flex flex-shrink-0 flex-col gap-2 items-start"},m.createElement("label",{htmlFor:"startsWith",className:"block font-sans text-xs font-semibold text-gray-500 whitespace-normal"},"Starts with"),m.createElement(e.IIB,{name:"startsWith",id:"startsWith",value:h.startsWith,onChange:a=>{const b=a.target.value;i(a=>({...a,startsWith:b,after:"",before:"",booleanEquals:null}))}}))),V&&m.createElement("div",{className:"flex flex-shrink-0 gap-4"},m.createElement("div",{className:"flex flex-col gap-2 items-start"},m.createElement("label",{htmlFor:"dateAfter",className:"block font-sans text-xs font-semibold text-gray-500 whitespace-normal"},"After"),m.createElement(e.qpW,{inputProps:{className:e.LsZ},value:h.after,onChange:a=>{i(b=>({...b,after:"function"==typeof a.format?a.format():"",booleanEquals:null,startsWith:""}))}})),m.createElement("div",{className:"flex flex-col gap-2 items-start"},m.createElement("label",{htmlFor:"dateBefore",className:"block font-sans text-xs font-semibold text-gray-500 whitespace-normal"},"Before"),m.createElement(e.qpW,{inputProps:{className:e.LsZ},value:h.before,onChange:a=>{i(b=>({...b,before:"function"==typeof a.format?a.format():"",booleanEquals:null,startsWith:""}))}}))),W&&m.createElement(m.Fragment,null,m.createElement("div",{className:"flex flex-col gap-2 items-start"},m.createElement("label",{htmlFor:"toggle",className:"block font-sans text-xs font-semibold text-gray-500 whitespace-normal"},T.label||T.name),m.createElement(e.ZDl,{field:T,input:{name:"toggle",value:null!=(M=h.booleanEquals)&&M,onChange:()=>{i(a=>({...a,booleanEquals:!a.booleanEquals,after:"",before:"",startsWith:""}))}},name:"toggle"}))),(U||V||W)&&m.createElement("div",{className:"flex gap-3"},m.createElement(e.zxk,{onClick:()=>{k(!0),n(""),p([]),A()},variant:"primary",type:"submit"},"Search"," ",m.createElement(zd,{className:"w-5 h-full ml-1.5 opacity-70"})),(h.startsWith||h.after||h.before||h.booleanEquals)&&m.createElement(e.zxk,{onClick:()=>{k(!1),i(a=>({...a,filterField:"",startsWith:"",after:"",before:"",booleanEquals:null})),n(""),p([]),A()},variant:"white"},"Clear"," ",m.createElement(Cd,{className:"w-5 h-full ml-1 opacity-70"}))))))),m.createElement("div",{className:"flex self-end\tjustify-self-end"},!u.templates&&Y&&m.createElement(q.Link,{to:`/${z.fullyQualifiedName?["collections","new",b,"~",z.name].join("/"):["collections","new",b].join("/")}`,className:"icon-parent inline-flex items-center font-medium focus:outline-none focus:ring-2 focus:shadow-outline text-center rounded-full justify-center transition-all duration-150 ease-out whitespace-nowrap shadow text-white bg-blue-500 hover:bg-blue-600 focus:ring-blue-500 text-sm h-10 px-6"},"Create New"," ",m.createElement(xd,{className:"w-5 h-full ml-1 opacity-70"})),u.templates&&Y&&m.createElement(be,{collectionName:b,templates:u.templates,folder:z})))),m.createElement(Qd,null,m.createElement("div",{className:"w-full mx-auto max-w-screen-xl"},R&&!R.required&&m.createElement("p",{className:"mb-4 text-gray-500"},m.createElement("em",null,"Sorting on a non-required field. Some documents may be excluded (if they don't have a value for"," ",v,")")),N.length>0?m.createElement("table",{className:"table-auto shadow bg-white border-b border-gray-200 w-full max-w-full rounded-lg"},m.createElement("tbody",{className:"divide-y divide-gray-150"},!j&&z.name&&m.createElement("tr",null,m.createElement("td",{colSpan:5},m.createElement(ee,{folder:z,navigate:a,collectionName:b}))),N.map(c=>{var f;if("Folder"===c.node.__typename)return m.createElement("tr",{key:`folder-${c.node.path}`},m.createElement("td",{className:"pl-5 pr-3 py-3 truncate max-w-0"},m.createElement("a",{className:"text-blue-600 hover:text-blue-400 flex items-center gap-3 cursor-pointer truncate",onClick:()=>{a(`/${["collections",b,c.node.path].join("/")}`,{replace:!0})}},m.createElement(td,{className:"inline-block h-6 w-auto flex-shrink-0 opacity-70"}),m.createElement("span",{className:"truncate block"},m.createElement("span",{className:"block text-xs text-gray-400 mb-1 uppercase"},"Name"),m.createElement("span",{className:"h-5 leading-5 block truncate"},m.createElement("span",null,c.node.name))))),m.createElement("td",{className:"px-3 py-3 truncate max-w-0",colSpan:4},m.createElement("span",{className:"block text-xs text-gray-400 mb-1 uppercase"},"Path"),m.createElement("span",{className:"leading-5 block text-sm font-medium text-gray-900 truncate"},c.node.path.substring(2).split("/").map(a=>m.createElement("span",{key:a},m.createElement("span",{className:"text-gray-300 pr-0.5"},"/"),m.createElement("span",{className:"pr-0.5"},a))))));const h=Boolean(c.node._sys.title),j=c.node._sys.breadcrumbs.slice(0,-1).join("/");return m.createElement("tr",{key:`document-${c.node._sys.relativePath}`,className:""},m.createElement("td",{className:"pl-5 pr-3 py-3 truncate max-w-0",colSpan:h?1:2},m.createElement("a",{className:"text-blue-600 hover:text-blue-400 flex items-center gap-3 cursor-pointer truncate",onClick:()=>{ce(a,r,u,X,c.node)}},m.createElement(sd,{className:"inline-block h-6 w-auto flex-shrink-0 opacity-70"}),m.createElement("span",{className:"truncate block"},m.createElement("span",{className:"block text-xs text-gray-400 mb-1 uppercase"},h?"Title":"Filename"),m.createElement("span",{className:"h-5 leading-5 block truncate"},!$&&!h&&j&&m.createElement("span",{className:"text-xs text-gray-400"},`${j}/`),m.createElement("span",null,h?null==(f=c.node._sys)?void 0:f.title:c.node._sys.filename))))),h&&m.createElement("td",{className:"px-3 py-3 truncate max-w-0"},m.createElement("span",{className:"block text-xs text-gray-400 mb-1 uppercase"},"Filename"),m.createElement("span",{className:"h-5 leading-5 block text-sm font-medium text-gray-900 truncate"},!$&&j&&m.createElement("span",{className:"text-xs text-gray-400"},`${j}/`),m.createElement("span",null,c.node._sys.filename))),m.createElement("td",{className:"px-3 py-3 truncate w-[15%]"},m.createElement("span",{className:"block text-xs text-gray-400 mb-1 uppercase"},"Extension"),m.createElement("span",{className:"h-5 leading-5 block text-sm font-medium text-gray-900"},c.node._sys.extension)),m.createElement("td",{className:"px-3 py-3 truncate w-[15%]"},m.createElement("span",{className:"block text-xs text-gray-400 mb-1 uppercase"},"Template"),m.createElement("span",{className:"h-5 leading-5 block text-sm font-medium text-gray-900"},c.node._sys.template)),m.createElement("td",{className:"w-0"},m.createElement(e.PQB,{toolbarItems:[{name:"edit",label:"Edit in Admin",Icon:m.createElement(qd,{size:"1.3rem"}),onMouseDown:()=>{const d=c.node._sys.breadcrumbs;z.fullyQualifiedName&&d.unshift("~"),a(`/${["collections","edit",b,...d].join("/")}`,{replace:!0})}},Y&&{name:"duplicate",label:"Duplicate",Icon:m.createElement(pd,{size:"1.3rem"}),onMouseDown:()=>{const d=c.node._sys.breadcrumbs;z.fullyQualifiedName&&d.unshift("~"),a(`/${["collections","duplicate",b,...d].join("/")}`,{replace:!0})}},Z&&{name:"delete",label:"Delete",Icon:m.createElement(Bd,{size:"1.3rem",className:"text-red-500"}),onMouseDown:()=>{i(a=>({...a,collection:b,relativePath:c.node._sys.breadcrumbs.join("/")+c.node._sys.extension,newRelativePath:""})),d(!0)}},Z&&{name:"rename",label:"Rename",Icon:m.createElement(yd,{size:"1.3rem",className:"text-red-500"}),onMouseDown:()=>{i(a=>({...a,collection:b,relativePath:c.node._sys.breadcrumbs.join("/")+c.node._sys.extension,newRelativePath:""})),g(!0)}}].filter(Boolean)})))}))):m.createElement(fe,null),m.createElement("div",{className:"pt-4"},m.createElement(e.r9b,{variant:"white",hasNext:"asc"===w?null==P?void 0:P.hasNextPage:P.hasPreviousPage,navigateNext:()=>{p([...o,l]),n(null==P?void 0:P.endCursor)},hasPrev:o.length>0,navigatePrev:()=>{const a=o[o.length-1];if("string"==typeof a){const b=o.slice(0,-1);p(b),n(a)}}})))))})))},ee=({folder:a,navigate:b,collectionName:c})=>{const d=a.name.split("/");return m.createElement("div",{className:"w-full bg-gray-50/30 flex items-stretch"},m.createElement("button",{onClick:()=>{const d=a.fullyQualifiedName.split("/");b(`/${["collections",c,...d.slice(0,d.length-1)].join("/")}`,{replace:!0})},className:"px-3 py-2 bg-white hover:bg-gray-50/50 transition ease-out duration-100 border-r border-gray-100 text-blue-500 hover:text-blue-600"},m.createElement(od,{className:"w-6 h-full opacity-70"})),m.createElement("span",{className:"px-3 py-2 text-gray-600 flex flex-wrap items-center justify-start gap-1"},m.createElement("button",{onClick:()=>{b(`/collections/${c}/~`,{replace:!0})},className:"shrink-0 bg-transparent p-0 border-0 text-blue-400 hover:text-blue-500 transition-all ease-out duration-100 opacity-70 hover:opacity-100"},m.createElement(Td,{className:"w-5 h-auto"})),d.map((e,f)=>m.createElement(m.Fragment,null,m.createElement("span",{className:"text-gray-200 shrink-0"},"/"),f<d.length-1?m.createElement("button",{className:"bg-transparent whitespace-nowrap truncate p-0 border-0 text-blue-500 hover:text-blue-600 transition-all ease-out duration-100 underline underline-offset-2 decoration-1\tdecoration-blue-200 hover:decoration-blue-400",onClick:()=>{const d=a.fullyQualifiedName.split("/");b(`/${["collections",c,...d.slice(0,d.length-(d.length-(f+2)))].join("/")}`,{replace:!0})}},e):m.createElement("span",{className:"whitespace-nowrap truncate"},e)))))},fe=()=>m.createElement("div",{className:"text-center px-5 py-3 flex flex-col items-center justify-center shadow border border-gray-100 bg-gray-50 border-b border-gray-200 w-full max-w-full rounded-lg"},m.createElement("p",{className:"text-base italic font-medium text-gray-300"},"No documents found.")),ge=({close:a,deleteFunc:b,filename:c})=>m.createElement(e.u_l,null,m.createElement(e.pdg,null,m.createElement(e.xBx,{close:a},"Delete ",c),m.createElement(e.fef,{padded:!0},m.createElement("p",null,`Are you sure you want to delete ${c}?`)),m.createElement(e.nK9,null,m.createElement(e.zxk,{style:{flexGrow:2},onClick:a},"Cancel"),m.createElement(e.zxk,{style:{flexGrow:3},variant:"danger",onClick:async()=>{await b(),a()}},"Delete")))),he=({close:a,renameFunc:b,filename:c,newRelativePath:d,setNewRelativePath:f})=>m.createElement(e.u_l,null,m.createElement(e.pdg,null,m.createElement(e.xBx,{close:a},"Rename ",c),m.createElement(e.fef,{padded:!0},m.createElement(m.Fragment,null,m.createElement("p",{className:"mb-4"},"Are you sure you want to rename ",m.createElement("strong",null,c),"? TinaCMS uses the filename as the ID; renaming this file could result in unresolved references."),m.createElement(e.QSS,{placeholder:"Enter a new name for the document's file",value:d,onChange:a=>f(a.target.value)}))),m.createElement(e.nK9,null,m.createElement(e.zxk,{style:{flexGrow:2},onClick:a},"Cancel"),m.createElement(e.zxk,{style:{flexGrow:3},variant:"primary",onClick:async()=>{await b(),a()}},"Rename"))));function ie(a){return jd({tag:"svg",attr:{viewBox:"0 0 20 20",fill:"currentColor"},child:[{tag:"path",attr:{fillRule:"evenodd",d:"M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z",clipRule:"evenodd"}}]})(a)}function je(a){return jd({tag:"svg",attr:{viewBox:"0 0 448 512"},child:[{tag:"path",attr:{d:"M400 224h-24v-72C376 68.2 307.8 0 224 0S72 68.2 72 152v72H48c-26.5 0-48 21.5-48 48v192c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V272c0-26.5-21.5-48-48-48zm-104 0H152v-72c0-39.7 32.3-72 72-72s72 32.3 72 72v72z"}}]})(a)}function ke(a){return jd({tag:"svg",attr:{viewBox:"0 0 448 512"},child:[{tag:"path",attr:{d:"M400 256H152V152.9c0-39.6 31.7-72.5 71.3-72.9 40-.4 72.7 32.1 72.7 72v16c0 13.3 10.7 24 24 24h32c13.3 0 24-10.7 24-24v-16C376 68 307.5-.3 223.5 0 139.5.3 72 69.5 72 153.5V256H48c-26.5 0-48 21.5-48 48v160c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V304c0-26.5-21.5-48-48-48z"}}]})(a)}const le=async(a,b,c,d,e,f)=>{const g=new Ub(a),{filename:h,...i}=f,j=`${e?`${e}/`:""}${h}.${b.format}`,k=g.schema.transformPayload(b.name,{_collection:b.name,...c&&{_template:c.name},...i});if(await g.isAuthenticated())await g.createDocument(b.name,j,k);else{const l="CreateDocument failed: User is no longer authenticated; please login and try again.";return a.alerts.error(l),console.error(l),!1}},me=()=>{const a=$d(),{collectionName:b,templateName:c}=(0,r.UO)();return m.createElement(Hd,null,d=>m.createElement(Xd,{cms:d,collectionName:b,folder:a,includeDocuments:!1},b=>{const e={includeCollection:!0,includeTemplate:!!b.templates};return m.createElement(oe,{cms:d,collection:b,templateName:c,mutationInfo:e,folder:a})}))},ne=a=>{const[b,c]=m.useState(!1);return m.createElement("div",{className:"group relative block cursor-pointer",onClick:()=>{c(!0)}},m.createElement("input",{type:"text",className:`shadow-inner focus:shadow-outline focus:border-blue-500 focus:outline-none block text-base pr-3 truncate py-2 w-full border transition-all ease-out duration-150 focus:text-gray-900 rounded-md ${a.readonly||!b?"bg-gray-50 text-gray-300  border-gray-150 pointer-events-none pl-8 group-hover:bg-white group-hover:text-gray-600  group-hover:border-gray-200":"bg-white text-gray-600  border-gray-200 pl-3"}`,...a,disabled:a.readonly||!b}),m.createElement(je,{className:`text-gray-400 absolute top-1/2 left-2 -translate-y-1/2 pointer-events-none h-5 w-auto transition-opacity duration-150 ease-out ${b||a.readonly?"opacity-0":"opacity-20 group-hover:opacity-0 group-active:opacity-0"}`}),m.createElement(ke,{className:`text-blue-500 absolute top-1/2 left-2 -translate-y-1/2 pointer-events-none h-5 w-auto transition-opacity duration-150 ease-out ${b||a.readonly?"opacity-0":"opacity-0 group-hover:opacity-80 group-active:opacity-80"}`}))},oe=({cms:a,collection:b,folder:c,templateName:d,mutationInfo:f,customDefaults:g})=>{var h,i,j,k,n,o;const p=(0,r.s0)(),[s,t]=(0,m.useState)(!0),v=a.api.tina.schema,w=v.getCollection(b.name),x=v.getTemplateForData({collection:w,data:{_template:d}}),y=(0,l.vR)({collection:w,basename:w.name,schema:v,template:x});let z=null==(i=null==(h=w.ui)?void 0:h.filename)?void 0:i.slugify;if(!z){const A=null==(j=null==x?void 0:x.fields.find(a=>a.required&&"string"===a.type&&a.isTitle))?void 0:j.name;A&&(z=a=>{var b;return null==(b=a[A])?void 0:b.replace(/ /g,"-").replace(/[^a-zA-Z0-9-]/g,"")})}const B=g||(null==(k=x.ui)?void 0:k.defaultItem)||(null==x?void 0:x.defaultItem),C=(0,m.useMemo)(()=>{var d,g;return new e.l09({initialValues:"function"==typeof B?B():B,extraSubscribeValues:{active:!0,submitting:!0,touched:!0},onChange:a=>{var b;if(z&&(null==a?void 0:a.active)!=="filename"&&!(null==a?void 0:a.submitting)&&!(null==(b=a.touched)?void 0:b.filename)){const c=z(null==a?void 0:a.values);C.finalForm.change("filename",c)}},id:"create-form",label:"form",fields:[...y.fields,{name:"filename",label:"Filename",component:z?(0,e.ZeD)(({field:a,input:b,meta:c})=>{var d,e;return m.createElement(ne,{readonly:null==(e=null==(d=null==w?void 0:w.ui)?void 0:d.filename)?void 0:e.readonly,...b})}):"text",disabled:null==(g=null==(d=null==w?void 0:w.ui)?void 0:d.filename)?void 0:g.readonly,description:m.createElement("span",null,"A unique filename for the content.",m.createElement("br",null),"Examples: ",m.createElement("code",null,"My_Document"),", ",m.createElement("code",null,"My_Document.en"),","," ",m.createElement("code",null,"sub-folder/My_Document")),placeholder:"My_Document",validate:(a,b,c)=>{var d,e;if(!a)return!c.dirty||"Required";const f=/^[_a-zA-Z0-9][\.\-_\/a-zA-Z0-9]*$/.test(a);if(a&&!f)return"Must begin with a-z, A-Z, 0-9, or _ and contain only a-z, A-Z, 0-9, -, _, ., or /.";if((null==(d=w.match)?void 0:d.exclude)||(null==(e=w.match)?void 0:e.include)){const g=`${(0,l.AH)(w.path)}/${a}.${w.format||"md"}`,h=v.matchFiles({files:[g],collection:w});if(0===h.length)return`The filename "${a}" is not allowed for this collection.`}}}],onSubmit:async d=>{try{const e=c.fullyQualifiedName?c.name:"";await le(a,b,x,f,e,d),a.alerts.success("Document created!"),setTimeout(()=>{p(`/collections/${b.name}${c.fullyQualifiedName?`/${c.fullyQualifiedName}`:""}`)},10)}catch(g){console.error(g);const h="There was a problem saving your document.";throw g.message.includes("already exists")?a.alerts.error(`${h} The "Filename" is alredy used for another document, please modify it.`):a.alerts.error(h),new Error(`[${g.name}] CreateDocument failed: ${g.message}`)}}})},[a,b,f]),D=(0,u.useWindowWidth)();if(m.useEffect(()=>(a.dispatch({type:"forms:add",value:C}),a.dispatch({type:"forms:set-active-form-id",value:C.id}),()=>{a.dispatch({type:"forms:remove",value:C.id}),a.dispatch({type:"forms:set-active-form-id",value:null})}),[JSON.stringify(y.fields)]),!a.state.activeFormId)return null;const E=a.state.forms.find(({tinaForm:a})=>a.id===C.id);return m.createElement(Od,null,m.createElement(m.Fragment,null,(null==(o=null==(n=null==a?void 0:a.api)?void 0:n.tina)?void 0:o.isLocalMode)?m.createElement(e.DrE,null):m.createElement(e.VaG,null),m.createElement("div",{className:`py-4 border-b border-gray-200 bg-white ${D<1001?"px-20":"px-6"}`},m.createElement("div",{className:"max-w-form mx-auto"},m.createElement("div",{className:"mb-2"},m.createElement("span",{className:"block text-sm leading-tight uppercase text-gray-400 mb-1"},m.createElement(q.Link,{to:`/collections/${b.name}${c.fullyQualifiedName?`/${c.fullyQualifiedName}`:""}`,className:"inline-block text-current hover:text-blue-400 focus:underline focus:outline-none focus:text-blue-400 font-medium transition-colors duration-150 ease-out"},b.label?b.label:b.name),m.createElement(ie,{className:"inline-block -mt-0.5 opacity-50"})),m.createElement("span",{className:"text-xl text-gray-700 font-medium leading-tight"},"Create New")),m.createElement(e.PXv,{pristine:s}))),E&&m.createElement(e.quP,{form:E,onPristineChange:t})))},pe=(a,b,c)=>{const d=new Ub(a),[e,f]=(0,m.useState)(void 0),[g,h]=(0,m.useState)(!0),[i,j]=(0,m.useState)(void 0);return(0,m.useEffect)(()=>{const e=async()=>{if(d.isAuthenticated()){try{const e=await d.fetchDocument(b,c);f(e.document)}catch(g){a.alerts.error(`[${g.name}] GetDocument failed: ${g.message}`),console.error(g),f(void 0),j(g)}h(!1)}};h(!0),e()},[a,b,c]),{document:e,loading:g,error:i}},qe=({cms:a,collectionName:b,relativePath:c,children:d})=>{const{document:e,loading:f,error:g}=pe(a,b,c);return g?m.createElement(Vd,null):f?m.createElement(Ud,null):m.createElement(m.Fragment,null,d(e,f))},re=()=>{const a=$d(),{collectionName:b,...c}=(0,r.UO)(),{"*":d}=c;return m.createElement(Hd,null,c=>m.createElement(Xd,{cms:c,collectionName:b,folder:a,includeDocuments:!1},b=>{const e=`${d.startsWith("~/")?d.substring(2):d}.${b.format}`,f={includeCollection:!0,includeTemplate:!!b.templates};return m.createElement(qe,{cms:c,collectionName:b.name,relativePath:e},d=>{var e;return m.createElement(oe,{cms:c,collection:b,templateName:null==(e=d._values)?void 0:e._template,folder:Zd(a),mutationInfo:f,customDefaults:d._values})})}))},se=async(a,b,c,d,e)=>{const f=new Ub(a),g=f.schema.transformPayload(c.name,e);if(await f.isAuthenticated())await f.updateDocument(c.name,b,g);else{const h="UpdateDocument failed: User is no longer authenticated; please login and try again.";return a.alerts.error(h),console.error(h),!1}},te=()=>{const{collectionName:a,...b}=(0,r.UO)(),c=$d(),{"*":d}=b,e=c.fullyQualifiedName?c.name:d;return m.createElement(Hd,null,b=>m.createElement(Xd,{cms:b,collectionName:a,folder:c,includeDocuments:!1},a=>{const c=`${e}.${a.format}`,d={includeCollection:!0,includeTemplate:!!a.templates};return m.createElement(Od,null,m.createElement(qe,{cms:b,collectionName:a.name,relativePath:c},f=>m.createElement(ue,{cms:b,document:f,filename:e,relativePath:c,collection:a,mutationInfo:d})))}))},ue=({cms:a,document:b,filename:c,relativePath:d,collection:f,mutationInfo:g})=>{var h,i;const[j,k]=(0,m.useState)(!0),n=a.api.tina.schema,o=d.split("/").slice(0,-1).join("/"),p=n.getCollection(f.name),r=n.getTemplateForData({collection:p,data:b._values}),s=(0,l.vR)({collection:p,basename:p.name,schema:n,template:r}),t=(0,m.useMemo)(()=>new e.l09({id:"update-form",label:"form",fields:s.fields,initialValues:b._values,onSubmit:async b=>{try{await se(a,d,f,g,b),a.alerts.success("Document updated!")}catch(c){throw console.error(c),new Error(`[${c.name}] UpdateDocument failed: ${c.message}`)}}}),[a,b,d,f,g]),v=(0,u.useWindowWidth)();if(m.useEffect(()=>(a.dispatch({type:"forms:add",value:t}),a.dispatch({type:"forms:set-active-form-id",value:t.id}),()=>{a.dispatch({type:"forms:remove",value:t.id}),a.dispatch({type:"forms:set-active-form-id",value:null})}),[JSON.stringify(b._values)]),!a.state.activeFormId)return null;const w=a.state.forms.find(({tinaForm:a})=>a.id===t.id);return m.createElement(m.Fragment,null,(null==(i=null==(h=null==a?void 0:a.api)?void 0:h.tina)?void 0:i.isLocalMode)?m.createElement(e.DrE,null):m.createElement(e.VaG,null),m.createElement("div",{className:`py-4 border-b border-gray-200 bg-white ${v<1001?"px-20":"px-6"}`},m.createElement("div",{className:"max-w-form mx-auto"},m.createElement("div",{className:"mb-2"},m.createElement("span",{className:"block text-sm leading-tight uppercase text-gray-400 mb-1"},m.createElement(q.Link,{to:`/collections/${f.name}/~${o}`,className:"inline-block text-current hover:text-blue-400 focus:underline focus:outline-none focus:text-blue-400 font-medium transition-colors duration-150 ease-out"},f.label?f.label:f.name),m.createElement(ie,{className:"inline-block -mt-0.5 opacity-50"})),m.createElement("span",{className:"text-xl text-gray-700 font-medium leading-tight"},"Edit ",`${c}.${f.format}`)),m.createElement(e.PXv,{pristine:j}))),w&&m.createElement(e.quP,{form:w,onPristineChange:k}))},ve=()=>{const{screenName:a}=(0,r.UO)(),b=(0,u.useWindowWidth)(),c=b<1001;return m.createElement(Hd,null,b=>{var d,f;const g=b.plugins.getType("screen").all(),h=g.find(({name:b})=>Dd(b)===a);return m.createElement("div",{className:"relative w-full h-full flex flex-col items-stretch justify-between"},(null==(f=null==(d=null==b?void 0:b.api)?void 0:d.tina)?void 0:f.isLocalMode)?m.createElement(e.DrE,null):m.createElement(e.VaG,null),c&&m.createElement("div",{className:"py-5 border-b border-gray-200 bg-white pl-18"},h.name),m.createElement("div",{className:"flex-1 overflow-y-auto relative flex flex-col items-stretch justify-between"},m.createElement(h.Component,{close:()=>{}})))})},we=()=>(m.useEffect(()=>{window&&window.location.assign("/")},[]),null),xe=({redirect:a,children:b})=>{const c=(0,r.s0)();return m.useEffect(()=>{a&&c("/~")},[a]),b},ye=({preview:a,cms:b})=>(m.useEffect(()=>{a&&b.flags.set("tina-iframe",!0)},[a]),null),ze=({preview:a,config:b})=>{const c=(0,r.UO)(),d=(0,r.s0)(),[e,f]=m.useState(`/${c["*"]}`),[g,h]=(0,m.useState)(null),i=m.useRef(null),j=`/${c["*"]}`;return m.useEffect(()=>{g!==j&&j&&f(j)},[j]),m.useEffect(()=>{(g!==e||g!==j)&&g&&d(`/~${g}`)},[g]),m.useEffect(()=>{setInterval(()=>{var a;if(i.current){const b=new URL((null==(a=i.current.contentWindow)?void 0:a.location.href)||"");if("null"===b.origin)return;const c=b.href.replace(b.origin,"");h(c)}},100)},[i.current]),m.createElement(a,{url:e,iframeRef:i,...b})},Ae=({schemaJson:a,children:b})=>{const c=(0,e.kNL)(),d=new Ub(c),f=d.api.contentApiUrl;return(0,m.useEffect)(()=>{a&&c&&d.checkGraphqlSchema({localSchema:a}).then(a=>{!1===a&&c.alerts.error("GraphQL Schema Mismatch. Editing may not work. If you just switched branches, try going back to the previous branch")})},[c,JSON.stringify(a||{}),f]),b},Be=({preview:a,Playground:b,config:c,schemaJson:d})=>{const{edit:e}=(0,o.i)();return"undefined"==typeof window?null:e?m.createElement(Hd,null,e=>{var f,g,h;const i=!1!==e.flags.get("tina-admin");if(!i)return m.createElement(dd,null,m.createElement(q.HashRouter,null,m.createElement(r.Z5,null,m.createElement(r.AW,{path:"logout",element:m.createElement(Nd,null)}),m.createElement(r.AW,{path:"/",element:m.createElement(we,null)}))));{const j=null==(f=e.api)?void 0:f.tina,k=null==(h=null==(g=null==j?void 0:j.schema)?void 0:g.config)?void 0:h.collections.find(a=>{var b;return"function"==typeof(null==(b=null==a?void 0:a.ui)?void 0:b.router)}),l=Boolean(k);return m.createElement(Ae,{schemaJson:d},m.createElement(q.HashRouter,null,m.createElement(ye,{preview:a,cms:e}),m.createElement(r.Z5,null,a&&m.createElement(r.AW,{path:"/~/*",element:m.createElement(ze,{config:c,preview:a})}),m.createElement(r.AW,{path:"graphql",element:m.createElement(De,null,m.createElement(b,null))}),m.createElement(r.AW,{path:"collections/new/:collectionName",element:m.createElement(Ce,{cms:e},m.createElement(me,null))}),m.createElement(r.AW,{path:"collections/duplicate/:collectionName/~/*",element:m.createElement(Ce,{cms:e},m.createElement(re,null))}),m.createElement(r.AW,{path:"collections/duplicate/:collectionName/*",element:m.createElement(Ce,{cms:e},m.createElement(re,null))}),m.createElement(r.AW,{path:"collections/new/:collectionName/:templateName",element:m.createElement(Ce,{cms:e},m.createElement(me,null))}),m.createElement(r.AW,{path:"collections/new/:collectionName/:templateName/~/*",element:m.createElement(Ce,{cms:e},m.createElement(me,null))}),m.createElement(r.AW,{path:"collections/new/:collectionName/~/*",element:m.createElement(Ce,{cms:e},m.createElement(me,null))}),m.createElement(r.AW,{path:"collections/edit/:collectionName/*",element:m.createElement(Ce,{cms:e},m.createElement(te,null))}),m.createElement(r.AW,{path:"collections/:collectionName/*",element:m.createElement(Ce,{cms:e},m.createElement(de,null))}),m.createElement(r.AW,{path:"screens/:screenName",element:m.createElement(Ce,{cms:e},m.createElement(ve,null))}),m.createElement(r.AW,{path:"logout",element:m.createElement(Ce,{cms:e},m.createElement(Ld,null))}),m.createElement(r.AW,{path:"/",element:m.createElement(xe,{redirect:!!a&&l},m.createElement(Ce,{cms:e},m.createElement(Sd,null)))}))))}}):m.createElement(dd,null,m.createElement(Kd,null))},Ce=({cms:a,children:b})=>m.createElement(dd,null,m.createElement("div",{className:"flex items-stretch h-screen overflow-hidden"},m.createElement(Ed,{cms:a}),m.createElement("div",{className:"flex-1 relative"},b))),De=({children:a})=>m.createElement("div",{style:{position:"fixed",top:0,left:0,width:"100%",height:"100%",overflow:"auto",background:"#F6F6F9",fontFamily:"'Inter', sans-serif",zIndex:9999}},a);class Ee{constructor(Fe){this.__type="tina-admin",this.name="route-mapping",this.mapper=Fe}}const Ge=a=>((0,l.Fv)({schema:a}),a),He=a=>((0,l.Fv)({schema:a.schema}),a),Ie=a=>{if(!a.schema)throw new Error("Static config must have a schema");return(0,l.Fv)({schema:a.schema}),a},Je=Ie}}])